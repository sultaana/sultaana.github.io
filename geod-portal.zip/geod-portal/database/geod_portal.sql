-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: db
-- Generation Time: Aug 24, 2025 at 05:33 PM
-- Server version: 8.0.43
-- PHP Version: 8.2.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `geod_portal`
--

-- --------------------------------------------------------

--
-- Table structure for table `applications`
--

CREATE TABLE `applications` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `jamb_reg_no` varchar(20) NOT NULL,
  `program` varchar(100) NOT NULL,
  `status` enum('pending','screening','approved','rejected') DEFAULT 'pending',
  `documents_path` text,
  `jamb_score` int NOT NULL,
  `waec_grade` text,
  `post_utme_score` int DEFAULT '0',
  `aggregate_score` decimal(5,2) DEFAULT '0.00',
  `admission_letter_path` varchar(255) DEFAULT NULL,
  `submitted_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `reviewed_at` timestamp NULL DEFAULT NULL,
  `reviewed_by` int DEFAULT NULL,
  `notes` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `applications`
--

INSERT INTO `applications` (`id`, `user_id`, `jamb_reg_no`, `program`, `status`, `documents_path`, `jamb_score`, `waec_grade`, `post_utme_score`, `aggregate_score`, `admission_letter_path`, `submitted_at`, `reviewed_at`, `reviewed_by`, `notes`) VALUES
(1, 6, 'JAM2024001234', 'Computer Science', 'approved', NULL, 280, 'A1-B2-B3-C4-C5', 75, 82.50, NULL, '2024-06-15 10:30:00', '2024-06-20 14:00:00', 1, NULL),
(2, 7, 'JAM2024005678', 'Business Administration', 'approved', NULL, 250, 'A1-A1-B2-B3-C4', 70, 78.00, NULL, '2024-06-20 14:20:00', '2024-06-22 09:15:00', 1, NULL),
(3, 8, 'JAM2022001122', 'Computer Engineering', 'approved', NULL, 295, 'A1-A1-B2-B2-B3', 80, 87.50, NULL, '2022-06-10 09:00:00', '2022-06-15 11:30:00', 1, NULL),
(4, 9, 'JAM2024009999', 'Computer Science', 'pending', NULL, 245, 'B2-B3-C4-C5-C6', 0, 0.00, NULL, '2024-08-20 09:15:00', NULL, NULL, NULL),
(5, 10, 'JAM2024008888', 'Business Administration', 'screening', NULL, 265, 'A1-B2-B2-C4-C5', 68, 0.00, NULL, '2024-08-18 15:45:00', NULL, NULL, NULL),
(6, 12, '1234567890AB', 'Economics', 'pending', '{\"olevel_certificate\":\"uploads\\/applications\\/68a9807c282fc_1755938940.jpeg\",\"jamb_result\":\"uploads\\/applications\\/68a9807c287f5_1755938940.jpeg\",\"birth_certificate\":\"uploads\\/applications\\/68a9807c28afc_1755938940.jpeg\",\"passport_photo\":\"uploads\\/applications\\/68a9807c28cab_1755938940.jpeg\"}', 230, '{\"year\":2023,\"subjects\":{\"English Language\":\"A1\",\"Mathematics\":\"B2\",\"Chemistry\":\"B2\",\"Physcis\":\"B3\",\"Biiology\":\"B2\"}}', 0, 28.75, NULL, '2025-08-23 08:49:00', NULL, NULL, NULL),
(7, 14, '1234567890AB', 'Computer Science', 'approved', '{\"olevel_certificate\":\"uploads\\/applications\\/68aa05c81b001_1755973064.jpg\",\"jamb_result\":\"uploads\\/applications\\/68aa05c81b6de_1755973064.jpg\",\"birth_certificate\":\"uploads\\/applications\\/68aa05c81b9c8_1755973064.jpg\",\"passport_photo\":\"uploads\\/applications\\/68aa05c81bc6b_1755973064.jpg\"}', 380, '{\"year\":2017,\"subjects\":{\"English Language\":\"A1\",\"Mathematics\":\"C6\",\"Chemistry\":\"C4\",\"Physics\":\"B2\",\"Biiology\":\"A1\"}}', 0, 47.50, NULL, '2025-08-23 18:17:44', '2025-08-23 19:33:08', 13, 'Failed Payment');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `id` int NOT NULL,
  `course_code` varchar(10) NOT NULL,
  `course_name` varchar(200) NOT NULL,
  `department_id` int NOT NULL,
  `faculty_id` int NOT NULL,
  `credits` int NOT NULL DEFAULT '3',
  `semester` enum('first','second','both') NOT NULL,
  `level` enum('100','200','300','400','500') NOT NULL,
  `max_students` int DEFAULT '100',
  `description` text,
  `prerequisites` text,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`id`, `course_code`, `course_name`, `department_id`, `faculty_id`, `credits`, `semester`, `level`, `max_students`, `description`, `prerequisites`, `status`, `created_at`) VALUES
(1, 'CSC101', 'Introduction to Computer Science', 5, 2, 3, 'first', '100', 100, 'Basic concepts in computer science and programming', NULL, 'active', '2025-08-22 13:12:16'),
(2, 'CSC102', 'Programming Fundamentals', 5, 2, 3, 'second', '100', 100, 'Introduction to programming using Python', NULL, 'active', '2025-08-22 13:12:16'),
(3, 'CSC201', 'Data Structures and Algorithms', 5, 2, 4, 'first', '200', 100, 'Fundamental data structures and algorithms', NULL, 'active', '2025-08-22 13:12:16'),
(4, 'CSC202', 'Object Oriented Programming', 5, 2, 3, 'second', '200', 100, 'OOP concepts using Java', NULL, 'active', '2025-08-22 13:12:16'),
(5, 'CSC301', 'Database Systems', 5, 2, 3, 'first', '300', 100, 'Database design and management systems', NULL, 'active', '2025-08-22 13:12:16'),
(6, 'CSC302', 'Software Engineering', 5, 2, 4, 'second', '300', 100, 'Software development methodologies and practices', NULL, 'active', '2025-08-22 13:12:16'),
(7, 'CSC401', 'Artificial Intelligence', 5, 2, 3, 'first', '400', 100, 'Introduction to AI and machine learning', NULL, 'active', '2025-08-22 13:12:16'),
(8, 'CSC402', 'Computer Graphics', 5, 2, 3, 'second', '400', 100, 'Computer graphics and visualization techniques', NULL, 'active', '2025-08-22 13:12:16'),
(9, 'CPE101', 'Engineering Mathematics I', 1, 1, 3, 'first', '100', 100, 'Mathematical foundations for engineering', NULL, 'active', '2025-08-22 13:12:16'),
(10, 'CPE102', 'Engineering Physics', 1, 1, 3, 'second', '100', 100, 'Physics principles for computer engineers', NULL, 'active', '2025-08-22 13:12:16'),
(11, 'CPE201', 'Digital Logic Design', 1, 1, 4, 'first', '200', 100, 'Digital circuits and logic design', NULL, 'active', '2025-08-22 13:12:16'),
(12, 'CPE202', 'Circuit Analysis', 1, 1, 3, 'second', '200', 100, 'Electrical circuit analysis and design', NULL, 'active', '2025-08-22 13:12:16'),
(13, 'BUS101', 'Introduction to Business', 19, 6, 3, 'first', '100', 100, 'Fundamentals of business organization and management', NULL, 'active', '2025-08-22 13:12:16'),
(14, 'BUS102', 'Business Mathematics', 19, 6, 3, 'second', '100', 100, 'Mathematical applications in business contexts', NULL, 'active', '2025-08-22 13:12:16'),
(15, 'ACC101', 'Principles of Accounting', 20, 6, 3, 'first', '100', 100, 'Basic accounting principles and practices', NULL, 'active', '2025-08-22 13:12:16'),
(16, 'ACC102', 'Financial Accounting', 20, 6, 3, 'second', '100', 100, 'Financial statement preparation and analysis', NULL, 'active', '2025-08-22 13:12:16'),
(17, 'ECO101', 'Principles of Economics I', 21, 6, 3, 'first', '100', 100, 'Introduction to microeconomic principles', NULL, 'active', '2025-08-22 13:12:16'),
(18, 'ECO102', 'Principles of Economics II', 21, 6, 3, 'second', '100', 100, 'Introduction to macroeconomic principles', NULL, 'active', '2025-08-22 13:12:16'),
(19, 'GST101', 'Communication in English I', 10, 3, 2, 'first', '100', 100, 'English language communication skills', NULL, 'active', '2025-08-22 13:12:16'),
(20, 'GST102', 'Communication in English II', 10, 3, 2, 'second', '100', 100, 'Advanced English communication', NULL, 'active', '2025-08-22 13:12:16'),
(21, 'GST111', 'Nigerian Peoples and Culture', 13, 3, 2, 'first', '100', 100, 'Nigerian history, culture and civilization', NULL, 'active', '2025-08-22 13:12:16'),
(22, 'GST201', 'Philosophy and Logic', 12, 3, 2, 'first', '200', 100, 'Introduction to philosophy and logical thinking', NULL, 'active', '2025-08-22 13:12:16'),
(23, 'GST202', 'Peace and Conflict Resolution', 13, 3, 2, 'second', '200', 100, 'Conflict management and peaceful resolution', NULL, 'active', '2025-08-22 13:12:16');

-- --------------------------------------------------------

--
-- Table structure for table `csrf_tokens`
--

CREATE TABLE `csrf_tokens` (
  `token` varchar(64) NOT NULL,
  `user_id` int NOT NULL,
  `expires_at` timestamp NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `id` int NOT NULL,
  `faculty_id` int NOT NULL,
  `name` varchar(100) NOT NULL,
  `code` varchar(10) NOT NULL,
  `hod_id` int DEFAULT NULL,
  `description` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`id`, `faculty_id`, `name`, `code`, `hod_id`, `description`, `created_at`) VALUES
(1, 1, 'Computer Engineering', 'CPE', 2, 'Computer Systems and Software Engineering', '2025-08-22 13:12:16'),
(2, 1, 'Electrical Engineering', 'EEE', NULL, 'Electrical and Electronics Engineering', '2025-08-22 13:12:16'),
(3, 1, 'Mechanical Engineering', 'MEE', NULL, 'Mechanical and Production Engineering', '2025-08-22 13:12:16'),
(4, 1, 'Civil Engineering', 'CVE', NULL, 'Civil and Environmental Engineering', '2025-08-22 13:12:16'),
(5, 2, 'Computer Science', 'CSC', 3, 'Computer Science and Information Technology', '2025-08-22 13:12:16'),
(6, 2, 'Mathematics', 'MTH', NULL, 'Mathematics and Statistics', '2025-08-22 13:12:16'),
(7, 2, 'Physics', 'PHY', NULL, 'Physics and Applied Physics', '2025-08-22 13:12:16'),
(8, 2, 'Chemistry', 'CHM', NULL, 'Chemistry and Biochemistry', '2025-08-22 13:12:16'),
(9, 2, 'Biology', 'BIO', NULL, 'Biology and Life Sciences', '2025-08-22 13:12:16'),
(10, 3, 'English Language', 'ENG', 4, 'English and Literary Studies', '2025-08-22 13:12:16'),
(11, 3, 'History', 'HIS', NULL, 'History and International Studies', '2025-08-22 13:12:16'),
(12, 3, 'Philosophy', 'PHL', NULL, 'Philosophy and Religious Studies', '2025-08-22 13:12:16'),
(13, 3, 'Political Science', 'POL', NULL, 'Political Science and Public Administration', '2025-08-22 13:12:16'),
(14, 4, 'Medicine and Surgery', 'MED', 5, 'Medical Doctor Program', '2025-08-22 13:12:16'),
(15, 4, 'Nursing', 'NUR', NULL, 'Nursing Sciences', '2025-08-22 13:12:16'),
(16, 4, 'Pharmacy', 'PHM', NULL, 'Pharmacy and Pharmaceutical Sciences', '2025-08-22 13:12:16'),
(17, 5, 'Private Law', 'PLW', NULL, 'Private and Commercial Law', '2025-08-22 13:12:16'),
(18, 5, 'Public Law', 'PUL', NULL, 'Public and Constitutional Law', '2025-08-22 13:12:16'),
(19, 6, 'Business Administration', 'BUS', NULL, 'Business Management and Administration', '2025-08-22 13:12:16'),
(20, 6, 'Accounting', 'ACC', NULL, 'Accounting and Finance', '2025-08-22 13:12:16'),
(21, 6, 'Economics', 'ECO', NULL, 'Economics and Development Studies', '2025-08-22 13:12:16'),
(22, 6, 'Marketing', 'MKT', NULL, 'Marketing and Sales Management', '2025-08-22 13:12:16');

-- --------------------------------------------------------

--
-- Table structure for table `enrollments`
--

CREATE TABLE `enrollments` (
  `id` int NOT NULL,
  `student_id` int NOT NULL,
  `course_id` int NOT NULL,
  `semester` enum('first','second') NOT NULL,
  `academic_year` varchar(9) NOT NULL,
  `grade` enum('A','B','C','D','E','F') DEFAULT NULL,
  `grade_point` decimal(3,2) DEFAULT NULL,
  `status` enum('enrolled','completed','dropped','failed') DEFAULT 'enrolled',
  `enrollment_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `enrollments`
--

INSERT INTO `enrollments` (`id`, `student_id`, `course_id`, `semester`, `academic_year`, `grade`, `grade_point`, `status`, `enrollment_date`) VALUES
(16, 7, 15, 'first', '2024/2025', NULL, NULL, 'enrolled', '2025-08-23 19:39:23'),
(17, 7, 16, 'second', '2024/2025', NULL, NULL, 'enrolled', '2025-08-23 19:39:29'),
(18, 7, 13, 'first', '2024/2025', NULL, NULL, 'enrolled', '2025-08-23 19:39:31'),
(19, 7, 19, 'first', '2024/2025', NULL, NULL, 'enrolled', '2025-08-23 19:39:34');

-- --------------------------------------------------------

--
-- Table structure for table `faculties`
--

CREATE TABLE `faculties` (
  `id` int NOT NULL,
  `name` varchar(100) NOT NULL,
  `code` varchar(10) NOT NULL,
  `dean_id` int DEFAULT NULL,
  `description` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `faculties`
--

INSERT INTO `faculties` (`id`, `name`, `code`, `dean_id`, `description`, `created_at`) VALUES
(1, 'Faculty of Engineering', 'ENG', 2, 'Engineering and Technology programs', '2025-08-22 13:12:16'),
(2, 'Faculty of Sciences', 'SCI', 3, 'Pure and Applied Sciences', '2025-08-22 13:12:16'),
(3, 'Faculty of Arts', 'ART', 4, 'Liberal Arts and Humanities', '2025-08-22 13:12:16'),
(4, 'Faculty of Medicine', 'MED', 5, 'Medicine and Health Sciences', '2025-08-22 13:12:16'),
(5, 'Faculty of Law', 'LAW', NULL, 'Legal Studies', '2025-08-22 13:12:16'),
(6, 'Faculty of Business Administration', 'BUS', NULL, 'Business and Management Studies', '2025-08-22 13:12:16');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int NOT NULL,
  `sender_id` int NOT NULL,
  `receiver_id` int NOT NULL,
  `subject` varchar(200) NOT NULL,
  `message` text NOT NULL,
  `read_status` tinyint(1) DEFAULT '0',
  `message_type` enum('personal','announcement','system') DEFAULT 'personal',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `sender_id`, `receiver_id`, `subject`, `message`, `read_status`, `message_type`, `created_at`) VALUES
(1, 13, 14, 'Hello World', 'Welcome to school!', 0, 'personal', '2025-08-23 18:35:50');

-- --------------------------------------------------------

--
-- Table structure for table `nigerian_lgas`
--

CREATE TABLE `nigerian_lgas` (
  `id` int NOT NULL,
  `state_id` int NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `nigerian_lgas`
--

INSERT INTO `nigerian_lgas` (`id`, `state_id`, `name`) VALUES
(1, 25, 'Alimosho'),
(2, 25, 'Amuwo-Odofin'),
(3, 25, 'Apapa'),
(4, 25, 'Badagry'),
(5, 25, 'Epe'),
(6, 25, 'Eti-Osa'),
(7, 25, 'Ibeju-Lekki'),
(8, 25, 'Ifako-Ijaiye'),
(9, 25, 'Ikeja'),
(10, 25, 'Ikorodu'),
(11, 25, 'Kosofe'),
(12, 25, 'Lagos Island'),
(13, 25, 'Lagos Mainland'),
(14, 25, 'Mushin'),
(15, 25, 'Ojo'),
(16, 25, 'Oshodi-Isolo'),
(17, 25, 'Shomolu'),
(18, 25, 'Surulere'),
(19, 20, 'Kano Municipal'),
(20, 20, 'Fagge'),
(21, 20, 'Dala'),
(22, 20, 'Gwale'),
(23, 20, 'Tarauni'),
(24, 33, 'Port Harcourt'),
(25, 33, 'Obio-Akpor'),
(26, 33, 'Eleme'),
(27, 33, 'Ikwerre'),
(28, 19, 'Kaduna North'),
(29, 19, 'Kaduna South'),
(30, 19, 'Chikun'),
(31, 19, 'Igabi'),
(32, 31, 'Ibadan North'),
(33, 31, 'Ibadan South-West'),
(34, 31, 'Ibadan North-East'),
(35, 31, 'Egbeda'),
(36, 15, 'Municipal Area Council'),
(37, 15, 'Gwagwalada'),
(38, 15, 'Kuje'),
(39, 15, 'Bwari'),
(40, 15, 'Abaji'),
(41, 15, 'Kwali');

-- --------------------------------------------------------

--
-- Table structure for table `nigerian_states`
--

CREATE TABLE `nigerian_states` (
  `id` int NOT NULL,
  `name` varchar(50) NOT NULL,
  `code` varchar(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `nigerian_states`
--

INSERT INTO `nigerian_states` (`id`, `name`, `code`) VALUES
(1, 'Abia', 'AB'),
(2, 'Adamawa', 'AD'),
(3, 'Akwa Ibom', 'AK'),
(4, 'Anambra', 'AN'),
(5, 'Bauchi', 'BA'),
(6, 'Bayelsa', 'BY'),
(7, 'Benue', 'BE'),
(8, 'Borno', 'BO'),
(9, 'Cross River', 'CR'),
(10, 'Delta', 'DE'),
(11, 'Ebonyi', 'EB'),
(12, 'Edo', 'ED'),
(13, 'Ekiti', 'EK'),
(14, 'Enugu', 'EN'),
(15, 'FCT', 'FC'),
(16, 'Gombe', 'GO'),
(17, 'Imo', 'IM'),
(18, 'Jigawa', 'JI'),
(19, 'Kaduna', 'KD'),
(20, 'Kano', 'KN'),
(21, 'Katsina', 'KT'),
(22, 'Kebbi', 'KE'),
(23, 'Kogi', 'KO'),
(24, 'Kwara', 'KW'),
(25, 'Lagos', 'LA'),
(26, 'Nasarawa', 'NA'),
(27, 'Niger', 'NI'),
(28, 'Ogun', 'OG'),
(29, 'Ondo', 'ON'),
(30, 'Osun', 'OS'),
(31, 'Oyo', 'OY'),
(32, 'Plateau', 'PL'),
(33, 'Rivers', 'RI'),
(34, 'Sokoto', 'SO'),
(35, 'Taraba', 'TA'),
(36, 'Yobe', 'YO'),
(37, 'Zamfara', 'ZA');

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `id` int NOT NULL,
  `email` varchar(100) NOT NULL,
  `token` varchar(64) NOT NULL,
  `expires_at` timestamp NOT NULL,
  `used` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `payment_type` enum('application_fee','acceptance_fee','school_fees','course_registration') NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `status` enum('pending','completed','failed','refunded') DEFAULT 'pending',
  `reference` varchar(100) NOT NULL,
  `payment_method` varchar(50) DEFAULT NULL,
  `paystack_reference` varchar(100) DEFAULT NULL,
  `gateway_response` text,
  `paid_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `user_id`, `payment_type`, `amount`, `status`, `reference`, `payment_method`, `paystack_reference`, `gateway_response`, `paid_at`, `created_at`) VALUES
(1, 12, 'application_fee', 3000.00, 'pending', 'PAY-68A9807C2EC0D-1755938940', NULL, NULL, NULL, NULL, '2025-08-23 08:49:00'),
(11, 12, 'application_fee', 3000.00, 'completed', 'GEO-APP-2025-012', 'card', 'GEO-APP-2025-012', '{\"id\":5265829118,\"domain\":\"test\",\"status\":\"success\",\"reference\":\"GEO-APP-2025-012\",\"receipt_number\":null,\"amount\":300000,\"message\":null,\"gateway_response\":\"Successful\",\"paid_at\":\"2025-08-23T09:05:32.000Z\",\"created_at\":\"2025-08-23T09:05:21.000Z\",\"channel\":\"card\",\"currency\":\"NGN\",\"ip_address\":\"105.112.190.27\",\"metadata\":{\"user_id\":\"12\",\"payment_type\":\"application_fee\",\"payment_id\":\"11\",\"username\":\"adebayomoses597\",\"referrer\":\"http:\\/\\/localhost:8080\\/\"},\"log\":{\"start_time\":1755939924,\"time_spent\":8,\"attempts\":1,\"errors\":0,\"success\":true,\"mobile\":false,\"input\":[],\"history\":[{\"type\":\"action\",\"message\":\"Attempted to pay with card\",\"time\":7},{\"type\":\"success\",\"message\":\"Successfully paid with card\",\"time\":8}]},\"fees\":14500,\"fees_split\":null,\"authorization\":{\"authorization_code\":\"AUTH_os5uqn4kfl\",\"bin\":\"408408\",\"last4\":\"4081\",\"exp_month\":\"12\",\"exp_year\":\"2030\",\"channel\":\"card\",\"card_type\":\"visa \",\"bank\":\"TEST BANK\",\"country_code\":\"NG\",\"brand\":\"visa\",\"reusable\":true,\"signature\":\"SIG_3QOI3425B47p7oUPwqHW\",\"account_name\":null,\"receiver_bank_account_number\":null,\"receiver_bank\":null},\"customer\":{\"id\":146471605,\"first_name\":\"\",\"last_name\":\"\",\"email\":\"adebayomoses597@gmail.com\",\"customer_code\":\"CUS_obc1yj1iki6lp85\",\"phone\":\"\",\"metadata\":null,\"risk_action\":\"default\",\"international_format_phone\":null},\"plan\":null,\"split\":[],\"order_id\":null,\"paidAt\":\"2025-08-23T09:05:32.000Z\",\"createdAt\":\"2025-08-23T09:05:21.000Z\",\"requested_amount\":300000,\"pos_transaction_data\":null,\"source\":null,\"fees_breakdown\":null,\"connect\":null,\"transaction_date\":\"2025-08-23T09:05:21.000Z\",\"plan_object\":[],\"subaccount\":[]}', '2025-08-23 10:05:32', '2025-08-23 10:05:20'),
(14, 12, 'application_fee', 3000.00, 'completed', 'GEO-APP-2025-012-1755940390-628', 'card', 'GEO-APP-2025-012-1755940390-628', '{\"id\":5265854248,\"domain\":\"test\",\"status\":\"success\",\"reference\":\"GEO-APP-2025-012-1755940390-628\",\"receipt_number\":null,\"amount\":300000,\"message\":null,\"gateway_response\":\"Successful\",\"paid_at\":\"2025-08-23T09:13:17.000Z\",\"created_at\":\"2025-08-23T09:13:11.000Z\",\"channel\":\"card\",\"currency\":\"NGN\",\"ip_address\":\"105.112.190.27\",\"metadata\":{\"user_id\":\"12\",\"payment_type\":\"application_fee\",\"payment_id\":\"14\",\"username\":\"adebayomoses597\",\"referrer\":\"http:\\/\\/localhost:8080\\/\"},\"log\":{\"start_time\":1755940394,\"time_spent\":4,\"attempts\":1,\"errors\":0,\"success\":true,\"mobile\":false,\"input\":[],\"history\":[{\"type\":\"action\",\"message\":\"Attempted to pay with card\",\"time\":3},{\"type\":\"success\",\"message\":\"Successfully paid with card\",\"time\":4}]},\"fees\":14500,\"fees_split\":null,\"authorization\":{\"authorization_code\":\"AUTH_lfy3zlmgxt\",\"bin\":\"408408\",\"last4\":\"4081\",\"exp_month\":\"12\",\"exp_year\":\"2030\",\"channel\":\"card\",\"card_type\":\"visa \",\"bank\":\"TEST BANK\",\"country_code\":\"NG\",\"brand\":\"visa\",\"reusable\":true,\"signature\":\"SIG_3QOI3425B47p7oUPwqHW\",\"account_name\":null,\"receiver_bank_account_number\":null,\"receiver_bank\":null},\"customer\":{\"id\":146471605,\"first_name\":\"\",\"last_name\":\"\",\"email\":\"adebayomoses597@gmail.com\",\"customer_code\":\"CUS_obc1yj1iki6lp85\",\"phone\":\"\",\"metadata\":null,\"risk_action\":\"default\",\"international_format_phone\":null},\"plan\":null,\"split\":[],\"order_id\":null,\"paidAt\":\"2025-08-23T09:13:17.000Z\",\"createdAt\":\"2025-08-23T09:13:11.000Z\",\"requested_amount\":300000,\"pos_transaction_data\":null,\"source\":null,\"fees_breakdown\":null,\"connect\":null,\"transaction_date\":\"2025-08-23T09:13:11.000Z\",\"plan_object\":[],\"subaccount\":[]}', '2025-08-23 10:13:17', '2025-08-23 10:13:10'),
(15, 12, 'application_fee', 3000.00, 'completed', 'GEO-APP-2025-012-1755971711-199', 'card', 'GEO-APP-2025-012-1755971711-199', '{\"id\":5267478512,\"domain\":\"test\",\"status\":\"success\",\"reference\":\"GEO-APP-2025-012-1755971711-199\",\"receipt_number\":null,\"amount\":300000,\"message\":null,\"gateway_response\":\"Successful\",\"paid_at\":\"2025-08-23T17:55:20.000Z\",\"created_at\":\"2025-08-23T17:55:12.000Z\",\"channel\":\"card\",\"currency\":\"NGN\",\"ip_address\":\"105.117.1.70\",\"metadata\":{\"user_id\":\"12\",\"payment_type\":\"application_fee\",\"payment_id\":\"15\",\"username\":\"adebayomoses597\",\"referrer\":\"http:\\/\\/localhost:8080\\/\"},\"log\":{\"start_time\":1755971715,\"time_spent\":6,\"attempts\":1,\"errors\":0,\"success\":true,\"mobile\":false,\"input\":[],\"history\":[{\"type\":\"action\",\"message\":\"Attempted to pay with card\",\"time\":4},{\"type\":\"success\",\"message\":\"Successfully paid with card\",\"time\":6}]},\"fees\":14500,\"fees_split\":null,\"authorization\":{\"authorization_code\":\"AUTH_b3f79sezuh\",\"bin\":\"408408\",\"last4\":\"4081\",\"exp_month\":\"12\",\"exp_year\":\"2030\",\"channel\":\"card\",\"card_type\":\"visa \",\"bank\":\"TEST BANK\",\"country_code\":\"NG\",\"brand\":\"visa\",\"reusable\":true,\"signature\":\"SIG_3QOI3425B47p7oUPwqHW\",\"account_name\":null,\"receiver_bank_account_number\":null,\"receiver_bank\":null},\"customer\":{\"id\":146471605,\"first_name\":\"\",\"last_name\":\"\",\"email\":\"adebayomoses597@gmail.com\",\"customer_code\":\"CUS_obc1yj1iki6lp85\",\"phone\":\"\",\"metadata\":null,\"risk_action\":\"default\",\"international_format_phone\":null},\"plan\":null,\"split\":[],\"order_id\":null,\"paidAt\":\"2025-08-23T17:55:20.000Z\",\"createdAt\":\"2025-08-23T17:55:12.000Z\",\"requested_amount\":300000,\"pos_transaction_data\":null,\"source\":null,\"fees_breakdown\":null,\"connect\":null,\"transaction_date\":\"2025-08-23T17:55:12.000Z\",\"plan_object\":[],\"subaccount\":[]}', '2025-08-23 18:55:20', '2025-08-23 18:55:11'),
(16, 14, 'application_fee', 3000.00, 'failed', 'PAY-68AA05C81F33E-1755973064', NULL, NULL, NULL, NULL, '2025-08-23 18:17:44'),
(17, 14, 'application_fee', 3000.00, 'failed', 'GEO-APP-2025-014-1755973279-595', NULL, NULL, '{\"success\":true,\"data\":{\"id\":5267522406,\"domain\":\"test\",\"status\":\"failed\",\"reference\":\"GEO-APP-2025-014-1755973279-595\",\"receipt_number\":null,\"amount\":300000,\"message\":null,\"gateway_response\":\"Declined\",\"paid_at\":null,\"created_at\":\"2025-08-23T18:21:20.000Z\",\"channel\":\"card\",\"currency\":\"NGN\",\"ip_address\":\"105.112.122.87\",\"metadata\":{\"user_id\":\"14\",\"payment_type\":\"application_fee\",\"payment_id\":\"17\",\"username\":\"sl\",\"referrer\":\"http:\\/\\/localhost:8080\\/\"},\"log\":{\"start_time\":1755973283,\"time_spent\":30,\"attempts\":1,\"errors\":1,\"success\":false,\"mobile\":false,\"input\":[],\"history\":[{\"type\":\"action\",\"message\":\"Attempted to pay with card\",\"time\":29},{\"type\":\"error\",\"message\":\"Error: Declined\",\"time\":30}]},\"fees\":null,\"fees_split\":null,\"authorization\":{\"authorization_code\":\"AUTH_xzijwswx2x\",\"bin\":\"408408\",\"last4\":\"5408\",\"exp_month\":\"12\",\"exp_year\":\"2030\",\"channel\":\"card\",\"card_type\":\"visa \",\"bank\":\"TEST BANK\",\"country_code\":\"NG\",\"brand\":\"visa\",\"reusable\":true,\"signature\":\"SIG_2qo4ekdMKZ5swfD6W7Oi\",\"account_name\":null,\"receiver_bank_account_number\":null,\"receiver_bank\":null},\"customer\":{\"id\":301278659,\"first_name\":null,\"last_name\":null,\"email\":\"sl@gmail.com\",\"customer_code\":\"CUS_27czdqs289ltmyb\",\"phone\":null,\"metadata\":null,\"risk_action\":\"default\",\"international_format_phone\":null},\"plan\":null,\"split\":[],\"order_id\":null,\"paidAt\":null,\"createdAt\":\"2025-08-23T18:21:20.000Z\",\"requested_amount\":300000,\"pos_transaction_data\":null,\"source\":null,\"fees_breakdown\":null,\"connect\":null,\"transaction_date\":\"2025-08-23T18:21:20.000Z\",\"plan_object\":[],\"subaccount\":[]},\"status\":\"failed\",\"amount\":3000,\"reference\":\"GEO-APP-2025-014-1755973279-595\",\"paid_at\":null,\"gateway_response\":\"Declined\"}', NULL, '2025-08-23 19:21:19'),
(18, 14, 'application_fee', 3000.00, 'completed', 'GEO-APP-2025-014-1755973547-429', 'card', 'GEO-APP-2025-014-1755973547-429', '{\"id\":5267529413,\"domain\":\"test\",\"status\":\"success\",\"reference\":\"GEO-APP-2025-014-1755973547-429\",\"receipt_number\":null,\"amount\":300000,\"message\":null,\"gateway_response\":\"Successful\",\"paid_at\":\"2025-08-23T18:25:59.000Z\",\"created_at\":\"2025-08-23T18:25:48.000Z\",\"channel\":\"card\",\"currency\":\"NGN\",\"ip_address\":\"105.112.122.87\",\"metadata\":{\"user_id\":\"14\",\"payment_type\":\"application_fee\",\"payment_id\":\"18\",\"username\":\"sl\",\"referrer\":\"http:\\/\\/localhost:8080\\/\"},\"log\":{\"start_time\":1755973550,\"time_spent\":9,\"attempts\":1,\"errors\":0,\"success\":true,\"mobile\":false,\"input\":[],\"history\":[{\"type\":\"action\",\"message\":\"Attempted to pay with card\",\"time\":9},{\"type\":\"success\",\"message\":\"Successfully paid with card\",\"time\":9}]},\"fees\":14500,\"fees_split\":null,\"authorization\":{\"authorization_code\":\"AUTH_c2lg5cc92b\",\"bin\":\"408408\",\"last4\":\"4081\",\"exp_month\":\"12\",\"exp_year\":\"2030\",\"channel\":\"card\",\"card_type\":\"visa \",\"bank\":\"TEST BANK\",\"country_code\":\"NG\",\"brand\":\"visa\",\"reusable\":true,\"signature\":\"SIG_3QOI3425B47p7oUPwqHW\",\"account_name\":null,\"receiver_bank_account_number\":null,\"receiver_bank\":null},\"customer\":{\"id\":301278659,\"first_name\":null,\"last_name\":null,\"email\":\"sl@gmail.com\",\"customer_code\":\"CUS_27czdqs289ltmyb\",\"phone\":null,\"metadata\":null,\"risk_action\":\"default\",\"international_format_phone\":null},\"plan\":null,\"split\":[],\"order_id\":null,\"paidAt\":\"2025-08-23T18:25:59.000Z\",\"createdAt\":\"2025-08-23T18:25:48.000Z\",\"requested_amount\":300000,\"pos_transaction_data\":null,\"source\":null,\"fees_breakdown\":null,\"connect\":null,\"transaction_date\":\"2025-08-23T18:25:48.000Z\",\"plan_object\":[],\"subaccount\":[]}', '2025-08-23 19:25:59', '2025-08-23 19:25:47'),
(19, 14, 'acceptance_fee', 25000.00, 'completed', 'GEO-ACC-2025-014-1755975000-287', 'card', 'GEO-ACC-2025-014-1755975000-287', '{\"id\":5267570888,\"domain\":\"test\",\"status\":\"success\",\"reference\":\"GEO-ACC-2025-014-1755975000-287\",\"receipt_number\":null,\"amount\":2500000,\"message\":null,\"gateway_response\":\"Successful\",\"paid_at\":\"2025-08-23T18:50:27.000Z\",\"created_at\":\"2025-08-23T18:50:02.000Z\",\"channel\":\"card\",\"currency\":\"NGN\",\"ip_address\":\"105.112.122.87\",\"metadata\":{\"user_id\":\"14\",\"payment_type\":\"acceptance_fee\",\"payment_id\":\"19\",\"username\":\"sl\",\"referrer\":\"http:\\/\\/localhost:8080\\/\"},\"log\":{\"start_time\":1755975005,\"time_spent\":22,\"attempts\":1,\"errors\":0,\"success\":true,\"mobile\":false,\"input\":[],\"history\":[{\"type\":\"action\",\"message\":\"Attempted to pay with card\",\"time\":21},{\"type\":\"success\",\"message\":\"Successfully paid with card\",\"time\":22}]},\"fees\":47500,\"fees_split\":null,\"authorization\":{\"authorization_code\":\"AUTH_fwo3auuluy\",\"bin\":\"408408\",\"last4\":\"4081\",\"exp_month\":\"12\",\"exp_year\":\"2030\",\"channel\":\"card\",\"card_type\":\"visa \",\"bank\":\"TEST BANK\",\"country_code\":\"NG\",\"brand\":\"visa\",\"reusable\":true,\"signature\":\"SIG_3QOI3425B47p7oUPwqHW\",\"account_name\":null,\"receiver_bank_account_number\":null,\"receiver_bank\":null},\"customer\":{\"id\":301278659,\"first_name\":null,\"last_name\":null,\"email\":\"sl@gmail.com\",\"customer_code\":\"CUS_27czdqs289ltmyb\",\"phone\":null,\"metadata\":null,\"risk_action\":\"default\",\"international_format_phone\":null},\"plan\":null,\"split\":[],\"order_id\":null,\"paidAt\":\"2025-08-23T18:50:27.000Z\",\"createdAt\":\"2025-08-23T18:50:02.000Z\",\"requested_amount\":2500000,\"pos_transaction_data\":null,\"source\":null,\"fees_breakdown\":null,\"connect\":null,\"transaction_date\":\"2025-08-23T18:50:02.000Z\",\"plan_object\":[],\"subaccount\":[]}', '2025-08-23 19:50:27', '2025-08-23 19:50:00');

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(128) NOT NULL,
  `user_id` int NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text,
  `last_activity` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `expires_at` timestamp NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `student_id` varchar(20) DEFAULT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `middle_name` varchar(50) DEFAULT NULL,
  `phone` varchar(15) NOT NULL,
  `program` varchar(100) DEFAULT NULL,
  `level` enum('100','200','300','400','500') DEFAULT '100',
  `state_of_origin` varchar(50) NOT NULL,
  `lga` varchar(100) NOT NULL,
  `address` text NOT NULL,
  `date_of_birth` date DEFAULT NULL,
  `gender` enum('Male','Female') NOT NULL,
  `admission_year` year DEFAULT NULL,
  `graduation_year` year DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `user_id`, `student_id`, `first_name`, `last_name`, `middle_name`, `phone`, `program`, `level`, `state_of_origin`, `lga`, `address`, `date_of_birth`, `gender`, `admission_year`, `graduation_year`, `created_at`) VALUES
(1, 6, 'CSC/2024/001', 'John', 'Doe', NULL, '08012345678', 'Computer Science', '200', 'Lagos', 'Ikeja', '123 University Road, Ikeja, Lagos State', '2005-03-15', 'Male', '2024', NULL, '2025-08-22 13:12:16'),
(2, 7, 'BUS/2024/001', 'Mary', 'Smith', NULL, '08087654321', 'Business Administration', '100', 'Oyo', 'Ibadan North', '456 Student Avenue, Ibadan, Oyo State', '2006-07-22', 'Female', '2024', NULL, '2025-08-22 13:12:16'),
(3, 8, 'CPE/2024/001', 'James', 'Wilson', NULL, '08123456789', 'Computer Engineering', '300', 'Rivers', 'Port Harcourt', '789 Tech Close, Port Harcourt, Rivers State', '2003-11-10', 'Male', '2022', NULL, '2025-08-22 13:12:16'),
(4, 11, NULL, 'John', 'Doe', NULL, '08012345678', NULL, '100', 'Lagos', 'Ikeja', 'To be updated during application', NULL, 'Male', NULL, NULL, '2025-08-22 21:32:10'),
(5, 12, NULL, 'Moses', 'Adebayo', NULL, '08120673365', 'Economics', '100', 'Lagos', 'Badagry', 'No. 1, Ahmed Olaoshebikan Street, Ibeshe, Ikorodu Lagos', '2025-07-29', 'Male', NULL, NULL, '2025-08-22 21:41:22'),
(6, 13, NULL, 'Moses', 'Admin', NULL, '08120673365', NULL, '100', 'Lagos', 'Amuwo-Odofin', 'To be updated during application', NULL, 'Male', NULL, NULL, '2025-08-23 09:15:49'),
(7, 14, NULL, 'Sultanaa', 'Lawal', NULL, '08090909090', 'Computer Science', '100', 'Lagos', 'Lagos Island', 'No. 1, Ahmed Olaoshebikan Street, Ibeshe, Ikorodu Lagos', '2024-11-25', 'Female', NULL, NULL, '2025-08-23 18:09:05');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('applicant','student','faculty','admin') NOT NULL DEFAULT 'applicant',
  `status` enum('active','inactive','suspended') NOT NULL DEFAULT 'active',
  `email_verified` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password_hash`, `role`, `status`, `email_verified`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'admin@geoduniversity.edu.ng', '482c811da5d5b4bc6d497ffa98491e38', 'admin', 'active', 1, '2025-08-22 13:12:16', '2025-08-23 09:11:42'),
(2, 'prof.adebayo', 'adebayo@geoduniversity.edu.ng', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'faculty', 'active', 1, '2025-08-22 13:12:16', '2025-08-22 13:12:16'),
(3, 'dr.ibrahim', 'ibrahim@geoduniversity.edu.ng', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'faculty', 'active', 1, '2025-08-22 13:12:16', '2025-08-22 13:12:16'),
(4, 'prof.okafor', 'okafor@geoduniversity.edu.ng', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'faculty', 'active', 1, '2025-08-22 13:12:16', '2025-08-22 13:12:16'),
(5, 'dr.williams', 'williams@geoduniversity.edu.ng', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'faculty', 'active', 1, '2025-08-22 13:12:16', '2025-08-22 13:12:16'),
(6, 'john.doe', 'john.doe@student.geoduniversity.edu.ng', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'student', 'active', 1, '2025-08-22 13:12:16', '2025-08-22 13:12:16'),
(7, 'mary.smith', 'mary.smith@student.geoduniversity.edu.ng', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'student', 'active', 1, '2025-08-22 13:12:16', '2025-08-22 13:12:16'),
(8, 'james.wilson', 'james.wilson@student.geoduniversity.edu.ng', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'student', 'active', 1, '2025-08-22 13:12:16', '2025-08-22 13:12:16'),
(9, 'applicant.test', 'applicant@test.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'applicant', 'active', 1, '2025-08-22 13:12:16', '2025-08-22 13:12:16'),
(10, 'sarah.johnson', 'sarah@test.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'applicant', 'active', 1, '2025-08-22 13:12:16', '2025-08-22 13:12:16'),
(11, 'testuser2', 'testuser2@example.com', '$2y$12$L.XJ6p9vxNEPFKaZkmtAk.rim9I8d78DC0sBeSySS9im7If.2weBm', 'applicant', 'active', 0, '2025-08-22 21:32:10', '2025-08-22 22:37:45'),
(12, 'adebayomoses597', 'adebayomoses597@gmail.com', '$2y$12$omifxKzBNtjlWWyUpm.aIeXkSqV1bYv0/MTQb/LcdPE6/pUOrLlA6', 'applicant', 'active', 0, '2025-08-22 21:41:22', '2025-08-23 19:43:31'),
(13, 'hey', 'hey@mosesadebayo.com', '$2y$12$iT3c2ydQoanaQVxsZMnSAO6P11DTtgUSI4nNPMdCmOjywfzNYZ0Fe', 'admin', 'active', 0, '2025-08-23 09:15:49', '2025-08-23 19:28:54'),
(14, 'sl', 'sl@gmail.com', '$2y$12$9mLKaUhU3.0GJ0xUb36aeOddE9JsTKXRhpALX9MsTeYOyEA3/Q7t2', 'student', 'active', 0, '2025-08-23 18:09:05', '2025-08-23 19:50:37');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `applications`
--
ALTER TABLE `applications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `reviewed_by` (`reviewed_by`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `course_code` (`course_code`),
  ADD KEY `department_id` (`department_id`),
  ADD KEY `faculty_id` (`faculty_id`);

--
-- Indexes for table `csrf_tokens`
--
ALTER TABLE `csrf_tokens`
  ADD PRIMARY KEY (`token`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`),
  ADD KEY `faculty_id` (`faculty_id`),
  ADD KEY `hod_id` (`hod_id`);

--
-- Indexes for table `enrollments`
--
ALTER TABLE `enrollments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_enrollment` (`student_id`,`course_id`,`semester`,`academic_year`),
  ADD KEY `course_id` (`course_id`);

--
-- Indexes for table `faculties`
--
ALTER TABLE `faculties`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`),
  ADD KEY `dean_id` (`dean_id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sender_id` (`sender_id`),
  ADD KEY `receiver_id` (`receiver_id`);

--
-- Indexes for table `nigerian_lgas`
--
ALTER TABLE `nigerian_lgas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `state_id` (`state_id`);

--
-- Indexes for table `nigerian_states`
--
ALTER TABLE `nigerian_states`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `token` (`token`),
  ADD KEY `idx_email` (`email`),
  ADD KEY `idx_token` (`token`),
  ADD KEY `idx_expires` (`expires_at`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `reference` (`reference`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `student_id` (`student_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `applications`
--
ALTER TABLE `applications`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `enrollments`
--
ALTER TABLE `enrollments`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `faculties`
--
ALTER TABLE `faculties`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `nigerian_lgas`
--
ALTER TABLE `nigerian_lgas`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `nigerian_states`
--
ALTER TABLE `nigerian_states`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `applications`
--
ALTER TABLE `applications`
  ADD CONSTRAINT `applications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `applications_ibfk_2` FOREIGN KEY (`reviewed_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `courses`
--
ALTER TABLE `courses`
  ADD CONSTRAINT `courses_ibfk_1` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `courses_ibfk_2` FOREIGN KEY (`faculty_id`) REFERENCES `faculties` (`id`);

--
-- Constraints for table `csrf_tokens`
--
ALTER TABLE `csrf_tokens`
  ADD CONSTRAINT `csrf_tokens_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `departments`
--
ALTER TABLE `departments`
  ADD CONSTRAINT `departments_ibfk_1` FOREIGN KEY (`faculty_id`) REFERENCES `faculties` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `departments_ibfk_2` FOREIGN KEY (`hod_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `enrollments`
--
ALTER TABLE `enrollments`
  ADD CONSTRAINT `enrollments_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `enrollments_ibfk_2` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `faculties`
--
ALTER TABLE `faculties`
  ADD CONSTRAINT `faculties_ibfk_1` FOREIGN KEY (`dean_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `messages`
--
ALTER TABLE `messages`
  ADD CONSTRAINT `messages_ibfk_1` FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `messages_ibfk_2` FOREIGN KEY (`receiver_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `nigerian_lgas`
--
ALTER TABLE `nigerian_lgas`
  ADD CONSTRAINT `nigerian_lgas_ibfk_1` FOREIGN KEY (`state_id`) REFERENCES `nigerian_states` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `sessions`
--
ALTER TABLE `sessions`
  ADD CONSTRAINT `sessions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `students`
--
ALTER TABLE `students`
  ADD CONSTRAINT `students_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
