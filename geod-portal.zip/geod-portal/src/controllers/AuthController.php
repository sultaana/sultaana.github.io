<?php
class AuthController extends Controller {
    
    private $userModel;
    private $emailService;
    
    public function __construct() {
        parent::__construct();
        $this->userModel = new User();
        $this->emailService = new EmailService();
    }
    
    // Show login form
    public function showLogin() {
        $this->view('auth/login', [
            'title' => 'Login - GEOD University Portal',
            'csrf_token' => CSRF::getToken()
        ]);
    }
    
    // Handle login submission
    public function login() {
        $this->validateCSRF();
        
        $loginField = Validator::sanitizeInput($_POST['login'] ?? '');
        $password = $_POST['password'] ?? '';
        
        // Validate input
        $validator = new Validator($_POST);
        $validator->validate('login', 'required')
                 ->validate('password', 'required|min:6');
        
        if ($validator->fails()) {
            Session::flash('error', 'Please check your input and try again.');
            Session::flash('errors', $validator->getErrors());
            $this->redirect('/auth/login');
        }
        
        // Determine if login field is email or student ID
        $user = $this->authenticateUser($loginField, $password);
        
        if ($user) {
            // Check if user is active
            if ($user['status'] !== 'active') {
                Session::flash('error', 'Your account has been suspended. Please contact administration.');
                $this->redirect('/auth/login');
            }
            
            // Set session variables
            Session::set('user_id', $user['id']);
            Session::set('user_role', $user['role']);
            Session::set('user_email', $user['email']);
            Session::set('username', $user['username']);
            
            // Regenerate session ID for security
            session_regenerate_id(true);
            
            // Check for redirect URL from payment verification
            $redirectUrl = Session::get('redirect_after_login');
            if ($redirectUrl) {
                Session::delete('redirect_after_login');
                Session::flash('success', 'Login successful! Completing payment verification...');
                $this->redirect($redirectUrl);
            } else {
                // Redirect based on role
                $redirectUrl = $this->getRedirectUrl($user['role']);
                Session::flash('success', 'Login successful! Welcome back.');
                $this->redirect($redirectUrl);
            }
            
        } else {
            Session::flash('error', 'Invalid email/student ID or password. Please try again.');
            $this->redirect('/auth/login');
        }
    }
    
    // Show registration form
    public function showRegister() {
        // Get Nigerian states for the form
        $db = Database::getInstance();
        $states = $db->fetchAll("SELECT * FROM nigerian_states ORDER BY name");
        
        $this->view('auth/register', [
            'title' => 'Apply to GEOD University',
            'csrf_token' => CSRF::getToken(),
            'states' => $states
        ]);
    }
    
    // Handle registration submission
    public function register() {
        $this->validateCSRF();
        
        // Sanitize inputs
        $data = [
            'email' => Validator::sanitizeInput($_POST['email'] ?? ''),
            'password' => $_POST['password'] ?? '',
            'password_confirmation' => $_POST['password_confirmation'] ?? '',
            'first_name' => Validator::sanitizeInput($_POST['first_name'] ?? ''),
            'last_name' => Validator::sanitizeInput($_POST['last_name'] ?? ''),
            'phone' => Validator::sanitizeInput($_POST['phone'] ?? ''),
            'state_of_origin' => Validator::sanitizeInput($_POST['state_of_origin'] ?? ''),
            'lga' => Validator::sanitizeInput($_POST['lga'] ?? ''),
            'gender' => $_POST['gender'] ?? ''
        ];
        
        // Auto-generate username from email
        $data['username'] = $this->generateUsername($data['email']);
        
        // Validate input
        $validator = new Validator($data);
        $validator->validate('email', 'required|email|unique:users,email')
                 ->validate('password', 'required|min:6|confirmed')
                 ->validate('first_name', 'required|min:2|max:50|alpha')
                 ->validate('last_name', 'required|min:2|max:50|alpha')
                 ->validate('phone', 'required|phone')
                 ->validate('state_of_origin', 'required')
                 ->validate('lga', 'required')
                 ->validate('gender', 'required|in:Male,Female');
        
        if ($validator->fails()) {
            error_log('Registration validation failed: ' . json_encode($validator->getErrors()));
            Session::flash('error', 'Please correct the errors below and try again.');
            Session::flash('errors', $validator->getErrors());
            Session::flash('old_input', $data);
            $this->redirect('/auth/register');
        }
        
        try {
            $this->db->beginTransaction();
            
            // Create user account with auto-generated username
            $userId = $this->userModel->createUser([
                'username' => $data['username'],
                'email' => $data['email'],
                'password' => $data['password'],
                'role' => 'applicant',
                'status' => 'active',
                'email_verified' => false
            ]);
            
            // Create basic profile (will be used in application)
            $profileData = [
                'user_id' => $userId,
                'first_name' => $data['first_name'],
                'last_name' => $data['last_name'],
                'phone' => $data['phone'],
                'state_of_origin' => $data['state_of_origin'],
                'lga' => $data['lga'],
                'gender' => $data['gender'],
                'address' => 'To be updated during application'
            ];
            
            // Store basic profile info
            $studentModel = new Student();
            $studentModel->create($profileData);
            
            $this->db->commit();
            
            // Send welcome email
            $this->emailService->sendWelcomeEmail(
                $data['email'],
                $data['first_name'] . ' ' . $data['last_name'],
                $data['username']
            );
            
            // Auto-login the user
            Session::set('user_id', $userId);
            Session::set('user_role', 'applicant');
            Session::set('user_email', $data['email']);
            Session::set('username', $data['username']);
            
            Session::flash('success', 'Account created successfully! Welcome email sent. You can now submit your university application.');
            $this->redirect('/dashboard');
            
        } catch (Exception $e) {
            $this->db->rollback();
            error_log("Registration error: " . $e->getMessage());
            Session::flash('error', 'Registration failed. Please try again.');
            $this->redirect('/auth/register');
        }
    }
    
    // Handle logout
    public function logout() {
        // Clear all session data
        Session::destroy();
        
        Session::flash('success', 'You have been logged out successfully.');
        $this->redirect('/');
    }
    
    // Show forgot password form
    public function showForgotPassword() {
        $this->view('auth/forgot-password', [
            'title' => 'Reset Password - GEOD University',
            'csrf_token' => CSRF::getToken()
        ]);
    }
    
    // Handle forgot password submission
    public function forgotPassword() {
        $this->validateCSRF();
        
        $email = Validator::sanitizeInput($_POST['email'] ?? '');
        
        $validator = new Validator($_POST);
        $validator->validate('email', 'required|email');
        
        if ($validator->fails()) {
            Session::flash('error', 'Please enter a valid email address.');
            $this->redirect('/auth/forgot-password');
        }
        
        // Check if user exists
        $user = $this->userModel->findBy('email', $email);
        
        if ($user) {
            try {
                // Create password reset token
                $passwordReset = new PasswordReset();
                $resetToken = $passwordReset->createResetToken($email);
                
                // Send reset email
                $emailService = new EmailService();
                $emailSent = $emailService->sendPasswordResetEmail($email, $resetToken);
                
                if ($emailSent) {
                    Session::flash('success', 'Password reset link has been sent to your email address.');
                } else {
                    Session::flash('error', 'Failed to send reset email. Please try again later.');
                }
                
            } catch (Exception $e) {
                error_log("Password reset error: " . $e->getMessage());
                Session::flash('error', 'An error occurred. Please try again later.');
            }
        } else {
            Session::flash('success', 'If an account with that email exists, a password reset link has been sent.');
        }
        
        $this->redirect('/auth/login');
    }
    
    public function showResetPassword() {
        $token = $_GET['token'] ?? '';
        
        if (!$token) {
            Session::flash('error', 'Invalid reset link.');
            $this->redirect('/auth/forgot-password');
        }
        
        // Validate token
        $passwordReset = new PasswordReset();
        $resetRecord = $passwordReset->validateToken($token);
        
        if (!$resetRecord) {
            Session::flash('error', 'Invalid or expired reset link. Please request a new one.');
            $this->redirect('/auth/forgot-password');
        }
        
        $this->view('auth/reset-password', [
            'title' => 'Reset Password - GEOD University',
            'token' => $token,
            'email' => $resetRecord['email'],
            'csrf_token' => CSRF::getToken()
        ]);
    }
    
    // Handle password reset
    public function resetPassword() {
        $this->validateCSRF();
        
        $token = $_POST['token'] ?? '';
        $password = $_POST['password'] ?? '';
        $passwordConfirmation = $_POST['password_confirmation'] ?? '';
        
        // Validate input
        $validator = new Validator($_POST);
        $validator->validate('password', 'required|min:6|confirmed');
        
        if ($validator->fails()) {
            Session::flash('error', 'Please check your password and try again.');
            Session::flash('errors', $validator->getErrors());
            $this->redirect('/auth/reset-password?token=' . $token);
        }
        
        // Validate token
        $passwordReset = new PasswordReset();
        $resetRecord = $passwordReset->validateToken($token);
        
        if (!$resetRecord) {
            Session::flash('error', 'Invalid or expired reset link.');
            $this->redirect('/auth/forgot-password');
        }
        
        try {
            $this->db->beginTransaction();
            
            // Update user password
            $this->userModel->updatePassword(
                $this->userModel->findBy('email', $resetRecord['email'])['id'],
                $password
            );
            
            // Mark token as used
            $passwordReset->markTokenAsUsed($token);
            
            // Clean up expired tokens
            $passwordReset->cleanExpiredTokens();
            
            $this->db->commit();
            
            Session::flash('success', 'Password reset successfully! Please login with your new password.');
            $this->redirect('/auth/login');
            
        } catch (Exception $e) {
            $this->db->rollback();
            error_log("Password reset error: " . $e->getMessage());
            Session::flash('error', 'Failed to reset password. Please try again.');
            $this->redirect('/auth/reset-password?token=' . $token);
        }
    }
    
    // Get redirect URL based on user role
    private function getRedirectUrl($role) {
        switch ($role) {
            case 'admin':
                return '/admin';
            case 'faculty':
                return '/faculty/courses';
            case 'student':
                return '/dashboard';
            case 'applicant':
            default:
                return '/dashboard';
        }
    }
    
    // Generate username from email
    private function generateUsername($email) {
        $baseUsername = explode('@', $email)[0];
        $username = $baseUsername;
        $counter = 1;
        
        // Check if username exists and increment if needed
        while ($this->userModel->usernameExists($username)) {
            $username = $baseUsername . $counter;
            $counter++;
        }
        
        return $username;
    }
    
    // Authenticate user with email or student ID
    private function authenticateUser($loginField, $password) {
        // Check if it's an email format
        if (filter_var($loginField, FILTER_VALIDATE_EMAIL)) {
            return $this->userModel->authenticate($loginField, $password);
        }
        
        // Check if it's a student ID format (e.g., CSC/2024/001)
        if (preg_match('/^[A-Z]{3}\/[0-9]{4}\/[0-9]{3}$/', $loginField)) {
            // Find user by student ID
            $student = $this->db->fetch(
                "SELECT u.* FROM users u 
                 JOIN students s ON u.id = s.user_id 
                 WHERE s.student_id = ?",
                [$loginField]
            );
            
            if ($student && Validator::verifyPassword($password, $student['password_hash'])) {
                return $student;
            }
        }
        
        // Try as regular email/username if other methods fail
        $user = $this->userModel->findBy('email', $loginField) 
                ?: $this->userModel->findBy('username', $loginField);
        
        if ($user && Validator::verifyPassword($password, $user['password_hash'])) {
            return $user;
        }
        
        return false;
    }
}