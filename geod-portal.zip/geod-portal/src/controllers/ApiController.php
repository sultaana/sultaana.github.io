<?php

class ApiController extends Controller {
    
    public function __construct() {
        parent::__construct();
    }
    
    /**
     * Get all Nigerian states
     */
    public function states() {
        try {
            $states = $this->db->fetchAll("SELECT * FROM nigerian_states ORDER BY name");
            $this->json(['success' => true, 'states' => $states]);
        } catch (Exception $e) {
            error_log("API states error: " . $e->getMessage());
            $this->json(['success' => false, 'message' => 'Failed to fetch states'], 500);
        }
    }
    
    /**
     * Get LGAs for a specific state
     */
    public function lgas($params) {
        $stateId = $params['state_id'] ?? null;
        
        if (!$stateId || !is_numeric($stateId)) {
            $this->json(['success' => false, 'message' => 'Invalid state ID'], 400);
        }
        
        try {
            $lgas = $this->db->fetchAll(
                "SELECT * FROM nigerian_lgas WHERE state_id = ? ORDER BY name",
                [$stateId]
            );
            
            $this->json(['success' => true, 'lgas' => $lgas]);
        } catch (Exception $e) {
            error_log("API LGAs error: " . $e->getMessage());
            $this->json(['success' => false, 'message' => 'Failed to fetch LGAs'], 500);
        }
    }
    
    /**
     * Get departments for a faculty
     */
    public function departments($params) {
        $facultyId = $params['faculty_id'] ?? null;
        
        if (!$facultyId || !is_numeric($facultyId)) {
            $this->json(['success' => false, 'message' => 'Invalid faculty ID'], 400);
        }
        
        try {
            $departments = $this->db->fetchAll(
                "SELECT * FROM departments WHERE faculty_id = ? ORDER BY name",
                [$facultyId]
            );
            
            $this->json(['success' => true, 'departments' => $departments]);
        } catch (Exception $e) {
            error_log("API departments error: " . $e->getMessage());
            $this->json(['success' => false, 'message' => 'Failed to fetch departments'], 500);
        }
    }
    
    /**
     * Get all programs/courses
     */
    public function programs() {
        try {
            $programs = $this->db->fetchAll(
                "SELECT d.name as program, f.name as faculty, d.description
                 FROM departments d
                 JOIN faculties f ON d.faculty_id = f.id
                 ORDER BY f.name, d.name"
            );
            
            $this->json(['success' => true, 'programs' => $programs]);
        } catch (Exception $e) {
            error_log("API programs error: " . $e->getMessage());
            $this->json(['success' => false, 'message' => 'Failed to fetch programs'], 500);
        }
    }
    
    /**
     * Search courses
     */
    public function searchCourses() {
        $query = $_GET['q'] ?? '';
        $level = $_GET['level'] ?? '';
        $faculty = $_GET['faculty'] ?? '';
        
        if (strlen($query) < 2) {
            $this->json(['success' => false, 'message' => 'Query too short'], 400);
        }
        
        try {
            $whereClause = "WHERE (c.course_code LIKE ? OR c.course_name LIKE ?) AND c.status = 'active'";
            $params = ["%$query%", "%$query%"];
            
            if ($level) {
                $whereClause .= " AND c.level = ?";
                $params[] = $level;
            }
            
            if ($faculty) {
                $whereClause .= " AND f.name = ?";
                $params[] = $faculty;
            }
            
            $courses = $this->db->fetchAll(
                "SELECT c.*, d.name as department_name, f.name as faculty_name
                 FROM courses c
                 JOIN departments d ON c.department_id = d.id
                 JOIN faculties f ON d.faculty_id = f.id
                 $whereClause
                 ORDER BY c.course_code
                 LIMIT 20",
                $params
            );
            
            $this->json(['success' => true, 'courses' => $courses]);
        } catch (Exception $e) {
            error_log("API course search error: " . $e->getMessage());
            $this->json(['success' => false, 'message' => 'Search failed'], 500);
        }
    }
    
    /**
     * Get student statistics
     */
    public function studentStats() {
        $this->requireAuth();
        
        $userId = Session::getUserId();
        $userRole = Session::getUserRole();
        
        // Only allow students and admin to access stats
        if (!in_array($userRole, ['student', 'admin'])) {
            $this->json(['success' => false, 'message' => 'Access denied'], 403);
        }
        
        try {
            if ($userRole === 'student') {
                // Get stats for specific student
                $student = $this->db->fetch("SELECT * FROM students WHERE user_id = ?", [$userId]);
                
                if (!$student) {
                    $this->json(['success' => false, 'message' => 'Student not found'], 404);
                }
                
                $stats = [
                    'enrolled_courses' => $this->db->fetch(
                        "SELECT COUNT(*) as count FROM enrollments WHERE student_id = ? AND status = 'enrolled'",
                        [$student['id']]
                    )['count'],
                    'completed_courses' => $this->db->fetch(
                        "SELECT COUNT(*) as count FROM enrollments WHERE student_id = ? AND status = 'completed'",
                        [$student['id']]
                    )['count'],
                    'total_credits' => $this->db->fetch(
                        "SELECT SUM(c.credits) as credits FROM enrollments e 
                         JOIN courses c ON e.course_id = c.id
                         WHERE e.student_id = ? AND e.status = 'completed'",
                        [$student['id']]
                    )['credits'] ?? 0,
                    'gpa' => $this->calculateStudentGPA($student['id'])
                ];
                
            } else {
                // Admin - get overall statistics
                $stats = [
                    'total_students' => $this->db->fetch("SELECT COUNT(*) as count FROM users WHERE role = 'student'")['count'],
                    'total_enrollments' => $this->db->fetch("SELECT COUNT(*) as count FROM enrollments WHERE status = 'enrolled'")['count'],
                    'total_courses' => $this->db->fetch("SELECT COUNT(*) as count FROM courses WHERE status = 'active'")['count'],
                    'average_enrollment' => $this->db->fetch("SELECT AVG(enrollment_count) as avg FROM (SELECT COUNT(*) as enrollment_count FROM enrollments WHERE status = 'enrolled' GROUP BY course_id) as subquery")['avg'] ?? 0
                ];
            }
            
            $this->json(['success' => true, 'stats' => $stats]);
        } catch (Exception $e) {
            error_log("API student stats error: " . $e->getMessage());
            $this->json(['success' => false, 'message' => 'Failed to fetch statistics'], 500);
        }
    }
    
    /**
     * Get payment summary
     */
    public function paymentSummary() {
        $this->requireAuth();
        
        $userId = Session::getUserId();
        $userRole = Session::getUserRole();
        
        try {
            if ($userRole === 'admin') {
                // Admin - get overall payment statistics
                $summary = $this->db->fetch(
                    "SELECT 
                        COUNT(*) as total_payments,
                        SUM(CASE WHEN status = 'completed' THEN amount ELSE 0 END) as total_revenue,
                        COUNT(CASE WHEN status = 'completed' THEN 1 END) as completed_payments,
                        COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending_payments,
                        COUNT(CASE WHEN status = 'failed' THEN 1 END) as failed_payments
                     FROM payments"
                );
                
                // Monthly revenue
                $monthlyRevenue = $this->db->fetchAll(
                    "SELECT 
                        DATE_FORMAT(created_at, '%Y-%m') as month,
                        SUM(CASE WHEN status = 'completed' THEN amount ELSE 0 END) as revenue
                     FROM payments 
                     WHERE created_at >= DATE_SUB(NOW(), INTERVAL 12 MONTH)
                     GROUP BY DATE_FORMAT(created_at, '%Y-%m')
                     ORDER BY month"
                );
                
                $summary['monthly_revenue'] = $monthlyRevenue;
                
            } else {
                // User - get personal payment summary
                $summary = $this->db->fetch(
                    "SELECT 
                        COUNT(*) as total_payments,
                        SUM(CASE WHEN status = 'completed' THEN amount ELSE 0 END) as total_paid,
                        COUNT(CASE WHEN status = 'completed' THEN 1 END) as completed_payments,
                        COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending_payments
                     FROM payments 
                     WHERE user_id = ?",
                    [$userId]
                );
            }
            
            $this->json(['success' => true, 'summary' => $summary]);
        } catch (Exception $e) {
            error_log("API payment summary error: " . $e->getMessage());
            $this->json(['success' => false, 'message' => 'Failed to fetch payment summary'], 500);
        }
    }
    
    /**
     * Get application statistics
     */
    public function applicationStats() {
        $this->requireAuth();
        $this->requireRole('admin');
        
        try {
            $stats = [
                'total' => $this->db->fetch("SELECT COUNT(*) as count FROM applications")['count'],
                'pending' => $this->db->fetch("SELECT COUNT(*) as count FROM applications WHERE status = 'pending'")['count'],
                'approved' => $this->db->fetch("SELECT COUNT(*) as count FROM applications WHERE status = 'approved'")['count'],
                'rejected' => $this->db->fetch("SELECT COUNT(*) as count FROM applications WHERE status = 'rejected'")['count'],
                'screening' => $this->db->fetch("SELECT COUNT(*) as count FROM applications WHERE status = 'screening'")['count']
            ];
            
            // Program-wise breakdown
            $programStats = $this->db->fetchAll(
                "SELECT program, COUNT(*) as count, 
                        COUNT(CASE WHEN status = 'approved' THEN 1 END) as approved,
                        AVG(jamb_score) as avg_jamb_score
                 FROM applications 
                 GROUP BY program 
                 ORDER BY count DESC"
            );
            
            $stats['by_program'] = $programStats;
            
            // Monthly trends
            $monthlyTrends = $this->db->fetchAll(
                "SELECT 
                    DATE_FORMAT(submitted_at, '%Y-%m') as month,
                    COUNT(*) as applications,
                    COUNT(CASE WHEN status = 'approved' THEN 1 END) as approved
                 FROM applications 
                 WHERE submitted_at >= DATE_SUB(NOW(), INTERVAL 12 MONTH)
                 GROUP BY DATE_FORMAT(submitted_at, '%Y-%m')
                 ORDER BY month"
            );
            
            $stats['monthly_trends'] = $monthlyTrends;
            
            $this->json(['success' => true, 'stats' => $stats]);
        } catch (Exception $e) {
            error_log("API application stats error: " . $e->getMessage());
            $this->json(['success' => false, 'message' => 'Failed to fetch application statistics'], 500);
        }
    }
    
    /**
     * Check system status
     */
    public function systemStatus() {
        $this->requireAuth();
        $this->requireRole('admin');
        
        try {
            $status = [
                'database' => $this->checkDatabaseConnection(),
                'email' => $this->checkEmailService(),
                'paystack' => $this->checkPaystackService(),
                'storage' => $this->checkStorageSpace(),
                'uptime' => $this->getSystemUptime()
            ];
            
            $this->json(['success' => true, 'status' => $status]);
        } catch (Exception $e) {
            error_log("API system status error: " . $e->getMessage());
            $this->json(['success' => false, 'message' => 'Failed to check system status'], 500);
        }
    }
    
    // Helper methods
    
    private function calculateStudentGPA($studentId) {
        $result = $this->db->fetch(
            "SELECT 
                SUM(c.credits * COALESCE(e.grade_point, 0)) / NULLIF(SUM(c.credits), 0) as gpa
             FROM enrollments e
             JOIN courses c ON e.course_id = c.id
             WHERE e.student_id = ? AND e.status = 'completed' AND e.grade_point IS NOT NULL",
            [$studentId]
        );
        
        return round($result['gpa'] ?? 0, 2);
    }
    
    private function checkDatabaseConnection() {
        try {
            $this->db->fetch("SELECT 1");
            return ['status' => 'healthy', 'message' => 'Database connection OK'];
        } catch (Exception $e) {
            return ['status' => 'error', 'message' => 'Database connection failed'];
        }
    }
    
    private function checkEmailService() {
        // Simple check - in production, you might want to send a test email
        try {
            $emailService = new EmailService();
            return ['status' => 'healthy', 'message' => 'Email service initialized'];
        } catch (Exception $e) {
            return ['status' => 'error', 'message' => 'Email service error'];
        }
    }
    
    private function checkPaystackService() {
        try {
            $paystackService = new PaystackService();
            // You could make a test API call here
            return ['status' => 'healthy', 'message' => 'Paystack service ready'];
        } catch (Exception $e) {
            return ['status' => 'error', 'message' => 'Paystack service error'];
        }
    }
    
    private function checkStorageSpace() {
        try {
            $uploadPath = __DIR__ . '/../storage/uploads';
            $freeSpace = disk_free_space($uploadPath);
            $totalSpace = disk_total_space($uploadPath);
            
            $percentUsed = (($totalSpace - $freeSpace) / $totalSpace) * 100;
            
            return [
                'status' => $percentUsed < 90 ? 'healthy' : 'warning',
                'free_space' => number_format($freeSpace / 1024 / 1024, 2) . ' MB',
                'percent_used' => round($percentUsed, 2) . '%'
            ];
        } catch (Exception $e) {
            return ['status' => 'error', 'message' => 'Cannot check storage space'];
        }
    }
    
    private function getSystemUptime() {
        // Simple uptime check - in production, you might track this differently
        return [
            'status' => 'healthy',
            'message' => 'System operational'
        ];
    }
}