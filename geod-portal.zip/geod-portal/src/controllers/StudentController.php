<?php

class StudentController extends Controller {
    
    private $studentModel;
    private $courseModel;
    
    public function __construct() {
        parent::__construct();
        $this->studentModel = new Student();
        $this->courseModel = new Course();
    }
    
    /**
     * Display available courses for enrollment
     */
    public function courses() {
        $this->requireAuth();
        $this->requireRole('student');
        
        $userId = Session::getUserId();
        
        // Get student information
        $student = $this->studentModel->findBy('user_id', $userId);
        if (!$student) {
            Session::flash('error', 'Student profile not found');
            $this->redirect('/dashboard');
        }
        
        // Get available courses for student's level
        $level = $student['level'] ?? '100';
        $courses = $this->db->fetchAll(
            "SELECT c.*, d.name as department_name, f.name as faculty_name,
                    (SELECT COUNT(*) FROM enrollments e WHERE e.course_id = c.id AND e.status = 'enrolled') as enrolled_count
             FROM courses c
             JOIN departments d ON c.department_id = d.id
             JOIN faculties f ON d.faculty_id = f.id
             WHERE c.level = ? AND c.status = 'active'
             ORDER BY c.course_code",
            [$level]
        );
        
        // Get student's current enrollments
        $enrolledCourses = $this->db->fetchAll(
            "SELECT course_id FROM enrollments WHERE student_id = ? AND status = 'enrolled'",
            [$student['id']]
        );
        $enrolledIds = array_column($enrolledCourses, 'course_id');
        
        $this->view('courses/index', [
            'title' => 'Available Courses - GEOD University',
            'courses' => $courses,
            'student' => $student,
            'enrolled_ids' => $enrolledIds
        ]);
    }
    
    /**
     * Show course details
     */
    public function courseDetails($params) {
        $this->requireAuth();
        $this->requireRole('student');
        
        $courseId = $params['id'] ?? null;
        if (!$courseId) {
            Session::flash('error', 'Course not found');
            $this->redirect('/courses');
        }
        
        // Get course details
        $course = $this->db->fetch(
            "SELECT c.*, d.name as department_name, f.name as faculty_name
             FROM courses c
             JOIN departments d ON c.department_id = d.id
             JOIN faculties f ON d.faculty_id = f.id
             WHERE c.id = ?",
            [$courseId]
        );
        
        if (!$course) {
            Session::flash('error', 'Course not found');
            $this->redirect('/courses');
        }
        
        // Check if student is enrolled
        $userId = Session::getUserId();
        $student = $this->studentModel->findBy('user_id', $userId);
        $isEnrolled = false;
        
        if ($student) {
            $enrollment = $this->db->fetch(
                "SELECT * FROM enrollments WHERE student_id = ? AND course_id = ?",
                [$student['id'], $courseId]
            );
            $isEnrolled = !empty($enrollment);
        }
        
        // Get enrollment statistics
        $enrollmentStats = $this->db->fetch(
            "SELECT COUNT(*) as total_enrolled FROM enrollments WHERE course_id = ? AND status = 'enrolled'",
            [$courseId]
        );
        
        $this->view('courses/details', [
            'title' => $course['course_name'] . ' - GEOD University',
            'course' => $course,
            'is_enrolled' => $isEnrolled,
            'enrollment_stats' => $enrollmentStats
        ]);
    }
    
    /**
     * Enroll in a course
     */
    public function enrollCourse($params) {
        $this->requireAuth();
        $this->requireRole('student');
        $this->validateCSRF();
        
        $courseId = $params['id'] ?? null;
        $userId = Session::getUserId();
        
        if (!$courseId) {
            $this->json(['error' => 'Invalid course'], 400);
        }
        
        $student = $this->studentModel->findBy('user_id', $userId);
        if (!$student) {
            $this->json(['error' => 'Student profile not found'], 400);
        }
        
        try {
            // Check if course exists and is available
            $course = $this->db->fetch(
                "SELECT * FROM courses WHERE id = ? AND status = 'active'",
                [$courseId]
            );
            
            if (!$course) {
                $this->json(['error' => 'Course not available'], 400);
            }
            
            // Check if already enrolled
            $existing = $this->db->fetch(
                "SELECT * FROM enrollments WHERE student_id = ? AND course_id = ?",
                [$student['id'], $courseId]
            );
            
            if ($existing) {
                $this->json(['error' => 'Already enrolled in this course'], 400);
            }
            
            // Check course capacity
            $enrolledCount = $this->db->fetch(
                "SELECT COUNT(*) as count FROM enrollments WHERE course_id = ? AND status = 'enrolled'",
                [$courseId]
            )['count'];
            
            if ($enrolledCount >= $course['max_students']) {
                $this->json(['error' => 'Course is full'], 400);
            }
            
            // Check if student's level matches course level
            if ($student['level'] !== $course['level']) {
                $this->json(['error' => 'Course level mismatch'], 400);
            }
            
            // Enroll student
            $this->db->insert('enrollments', [
                'student_id' => $student['id'],
                'course_id' => $courseId,
                'semester' => $course['semester'] === 'both' ? 'first' : $course['semester'],
                'academic_year' => '2024/2025',
                'status' => 'enrolled',
                'enrollment_date' => date('Y-m-d H:i:s')
            ]);
            
            $this->json(['success' => true, 'message' => 'Successfully enrolled in course']);
            
        } catch (Exception $e) {
            error_log("Course enrollment error: " . $e->getMessage());
            $this->json(['error' => 'Enrollment failed'], 500);
        }
    }
    
    /**
     * Display student's enrolled courses
     */
    public function myCourses() {
        $this->requireAuth();
        $this->requireRole('student');
        
        $userId = Session::getUserId();
        $student = $this->studentModel->findBy('user_id', $userId);
        
        if (!$student) {
            Session::flash('error', 'Student profile not found');
            $this->redirect('/dashboard');
        }
        
        // Get enrolled courses
        $courses = $this->db->fetchAll(
            "SELECT c.*, d.name as department_name, f.name as faculty_name,
                    e.semester, e.academic_year, e.status as enrollment_status, e.grade, e.grade_point
             FROM enrollments e
             JOIN courses c ON e.course_id = c.id
             JOIN departments d ON c.department_id = d.id
             JOIN faculties f ON d.faculty_id = f.id
             WHERE e.student_id = ?
             ORDER BY e.academic_year DESC, e.semester, c.course_code",
            [$student['id']]
        );
        
        // Group courses by semester
        $groupedCourses = [];
        foreach ($courses as $course) {
            $key = $course['academic_year'] . ' - ' . ucfirst($course['semester']) . ' Semester';
            $groupedCourses[$key][] = $course;
        }
        
        // Calculate GPA
        $totalPoints = 0;
        $totalCredits = 0;
        foreach ($courses as $course) {
            if ($course['grade_point'] && $course['enrollment_status'] === 'completed') {
                $totalPoints += $course['grade_point'] * $course['credits'];
                $totalCredits += $course['credits'];
            }
        }
        $gpa = $totalCredits > 0 ? $totalPoints / $totalCredits : 0;
        
        $this->view('students/my-courses', [
            'title' => 'My Courses - GEOD University',
            'grouped_courses' => $groupedCourses,
            'student' => $student,
            'gpa' => round($gpa, 2)
        ]);
    }
    
    /**
     * Display grades
     */
    public function grades() {
        $this->requireAuth();
        $this->requireRole('student');
        
        $userId = Session::getUserId();
        $student = $this->studentModel->findBy('user_id', $userId);
        
        if (!$student) {
            Session::flash('error', 'Student profile not found');
            $this->redirect('/dashboard');
        }
        
        // Get graded courses
        $grades = $this->db->fetchAll(
            "SELECT c.course_code, c.course_name, c.credits,
                    e.semester, e.academic_year, e.grade, e.grade_point
             FROM enrollments e
             JOIN courses c ON e.course_id = c.id
             WHERE e.student_id = ? AND e.grade IS NOT NULL
             ORDER BY e.academic_year DESC, e.semester, c.course_code",
            [$student['id']]
        );
        
        // Calculate semester GPAs
        $semesterStats = [];
        foreach ($grades as $grade) {
            $key = $grade['academic_year'] . '_' . $grade['semester'];
            if (!isset($semesterStats[$key])) {
                $semesterStats[$key] = [
                    'year' => $grade['academic_year'],
                    'semester' => $grade['semester'],
                    'total_points' => 0,
                    'total_credits' => 0,
                    'courses' => 0
                ];
            }
            
            $semesterStats[$key]['total_points'] += $grade['grade_point'] * $grade['credits'];
            $semesterStats[$key]['total_credits'] += $grade['credits'];
            $semesterStats[$key]['courses']++;
        }
        
        // Calculate GPAs
        foreach ($semesterStats as &$stats) {
            $stats['gpa'] = $stats['total_credits'] > 0 ? 
                round($stats['total_points'] / $stats['total_credits'], 2) : 0;
        }
        
        // Calculate CGPA
        $totalPoints = array_sum(array_column($semesterStats, 'total_points'));
        $totalCredits = array_sum(array_column($semesterStats, 'total_credits'));
        $cgpa = $totalCredits > 0 ? round($totalPoints / $totalCredits, 2) : 0;
        
        $this->view('students/grades', [
            'title' => 'Academic Records - GEOD University',
            'grades' => $grades,
            'semester_stats' => $semesterStats,
            'cgpa' => $cgpa,
            'student' => $student
        ]);
    }
    
    /**
     * Generate transcript
     */
    public function transcript() {
        $this->requireAuth();
        $this->requireRole('student');
        
        $userId = Session::getUserId();
        $student = $this->studentModel->findBy('user_id', $userId);
        
        if (!$student) {
            Session::flash('error', 'Student profile not found');
            $this->redirect('/dashboard');
        }
        
        // Get complete academic record
        $academicRecord = $this->db->fetchAll(
            "SELECT c.course_code, c.course_name, c.credits,
                    e.semester, e.academic_year, e.grade, e.grade_point
             FROM enrollments e
             JOIN courses c ON e.course_id = c.id
             WHERE e.student_id = ? AND e.status IN ('completed', 'enrolled')
             ORDER BY e.academic_year, e.semester, c.course_code",
            [$student['id']]
        );
        
        // Get user information
        $user = $this->db->fetch("SELECT * FROM users WHERE id = ?", [$userId]);
        
        // Calculate statistics
        $completedCourses = array_filter($academicRecord, function($record) {
            return !empty($record['grade']);
        });
        
        $totalCredits = array_sum(array_column($completedCourses, 'credits'));
        $totalPoints = array_sum(array_map(function($record) {
            return $record['grade_point'] * $record['credits'];
        }, $completedCourses));
        
        $cgpa = $totalCredits > 0 ? round($totalPoints / $totalCredits, 2) : 0;
        
        $this->view('students/transcript', [
            'title' => 'Official Transcript - GEOD University',
            'student' => $student,
            'user' => $user,
            'academic_record' => $academicRecord,
            'total_credits' => $totalCredits,
            'cgpa' => $cgpa
        ]);
    }
}