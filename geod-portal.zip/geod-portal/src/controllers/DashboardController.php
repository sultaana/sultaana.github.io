<?php

class DashboardController extends Controller {
    
    public function __construct() {
        parent::__construct();
    }
    
    public function index() {
        $this->requireAuth();
        
        $userId = Session::getUserId();
        $userRole = Session::getUserRole();
        $userEmail = Session::get('user_email');
        $username = Session::get('username');
        
        $dashboardData = [
            'user_id' => $userId,
            'user_role' => $userRole,
            'user_email' => $userEmail,
            'username' => $username
        ];
        
        switch ($userRole) {
            case 'applicant':
                $dashboardData = array_merge($dashboardData, $this->getApplicantData($userId));
                break;
            case 'student':
                $dashboardData = array_merge($dashboardData, $this->getStudentData($userId));
                break;
            case 'faculty':
                $dashboardData = array_merge($dashboardData, $this->getFacultyData($userId));
                break;
            case 'admin':
                $dashboardData = array_merge($dashboardData, $this->getAdminData($userId));
                break;
        }
        
        $this->view('dashboard/index', array_merge($dashboardData, [
            'title' => 'Dashboard - GEOD University Portal'
        ]));
    }
    
    private function getApplicantData($userId) {
        $application = $this->db->fetch(
            "SELECT * FROM applications WHERE user_id = ? ORDER BY submitted_at DESC LIMIT 1",
            [$userId]
        );
        
        $payment = null;
        if ($application) {
            $payment = $this->db->fetch(
                "SELECT * FROM payments WHERE user_id = ? AND payment_type = 'application_fee' ORDER BY created_at DESC LIMIT 1",
                [$userId]
            );
        }
        
        return [
            'application' => $application,
            'payment' => $payment,
            'has_application' => !empty($application)
        ];
    }
    
    private function getStudentData($userId) {
        $student = $this->db->fetch(
            "SELECT * FROM students WHERE user_id = ?",
            [$userId]
        );
        
        $enrollments = $this->db->fetchAll(
            "SELECT e.*, c.course_name, c.course_code, c.credits 
             FROM enrollments e 
             JOIN courses c ON e.course_id = c.id 
             WHERE e.student_id = ? AND e.status = 'enrolled' 
             ORDER BY c.course_code",
            [$student['id'] ?? 0]
        );
        
        $payments = $this->db->fetchAll(
            "SELECT * FROM payments WHERE user_id = ? ORDER BY created_at DESC LIMIT 5",
            [$userId]
        );
        
        return [
            'student' => $student,
            'enrollments' => $enrollments,
            'payments' => $payments
        ];
    }
    
    private function getFacultyData($userId) {
        $courses = $this->db->fetchAll(
            "SELECT c.*, d.name as department_name, f.name as faculty_name
             FROM courses c
             JOIN departments d ON c.department_id = d.id
             JOIN faculties f ON d.faculty_id = f.id
             WHERE d.hod_id = ? OR f.dean_id = ?
             ORDER BY c.course_code",
            [$userId, $userId]
        );
        
        $messages = $this->db->fetchAll(
            "SELECT m.*, u.username as sender_name
             FROM messages m
             JOIN users u ON m.sender_id = u.id
             WHERE m.receiver_id = ? AND m.read_status = FALSE
             ORDER BY m.created_at DESC LIMIT 5",
            [$userId]
        );
        
        return [
            'courses' => $courses,
            'messages' => $messages
        ];
    }
    
    private function getAdminData($userId) {
        $pendingApplications = $this->db->fetchAll(
            "SELECT a.*, u.email, u.username
             FROM applications a
             JOIN users u ON a.user_id = u.id
             WHERE a.status = 'pending'
             ORDER BY a.submitted_at DESC
             LIMIT 10"
        );
        
        $stats = [
            'total_students' => $this->db->fetch("SELECT COUNT(*) as count FROM users WHERE role = 'student'")['count'],
            'total_applications' => $this->db->fetch("SELECT COUNT(*) as count FROM applications")['count'],
            'pending_applications' => $this->db->fetch("SELECT COUNT(*) as count FROM applications WHERE status = 'pending'")['count'],
            'total_payments' => $this->db->fetch("SELECT SUM(amount) as total FROM payments WHERE status = 'completed'")['total'] ?? 0
        ];
        
        return [
            'pending_applications' => $pendingApplications,
            'stats' => $stats
        ];
    }
}