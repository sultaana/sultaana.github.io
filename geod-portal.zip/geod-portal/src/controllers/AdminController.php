<?php

class AdminController extends Controller {
    
    private $applicationModel;
    private $studentModel;
    private $emailService;
    
    public function __construct() {
        parent::__construct();
        $this->applicationModel = new Application();
        $this->studentModel = new Student();
        $this->emailService = new EmailService();
    }
    
    public function dashboard() {
        $this->requireAuth();
        $this->requireRole('admin');
        
        $stats = [
            'total_applications' => $this->db->fetch("SELECT COUNT(*) as count FROM applications")['count'],
            'pending_applications' => $this->db->fetch("SELECT COUNT(*) as count FROM applications WHERE status = 'pending'")['count'],
            'approved_applications' => $this->db->fetch("SELECT COUNT(*) as count FROM applications WHERE status = 'approved'")['count'],
            'total_students' => $this->db->fetch("SELECT COUNT(*) as count FROM users WHERE role = 'student'")['count'],
            'total_revenue' => $this->db->fetch("SELECT SUM(amount) as total FROM payments WHERE status = 'completed'")['total'] ?? 0,
            'pending_payments' => $this->db->fetch("SELECT COUNT(*) as count FROM payments WHERE status = 'pending'")['count']
        ];
        
        $recentApplications = $this->db->fetchAll(
            "SELECT a.*, u.email, u.username, d.name as department_name 
             FROM applications a
             JOIN users u ON a.user_id = u.id
             LEFT JOIN departments d ON a.program = d.name
             ORDER BY a.submitted_at DESC
             LIMIT 10"
        );
        
        $monthlyTrends = $this->db->fetchAll(
            "SELECT 
                DATE_FORMAT(submitted_at, '%Y-%m') as month,
                COUNT(*) as applications,
                SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) as approved
             FROM applications 
             WHERE submitted_at >= DATE_SUB(NOW(), INTERVAL 12 MONTH)
             GROUP BY DATE_FORMAT(submitted_at, '%Y-%m')
             ORDER BY month"
        );
        
        $this->view('admin/dashboard', [
            'title' => 'Admin Dashboard - GEOD University',
            'stats' => $stats,
            'recent_applications' => $recentApplications,
            'monthly_trends' => $monthlyTrends
        ]);
    }
    
    public function applications() {
        $this->requireAuth();
        $this->requireRole('admin');
        
        $status = $_GET['status'] ?? 'all';
        $search = $_GET['search'] ?? '';
        $page = max(1, (int)($_GET['page'] ?? 1));
        $perPage = 20;
        $offset = ($page - 1) * $perPage;
        
        $whereClause = "WHERE 1=1";
        $params = [];
        
        if ($status !== 'all') {
            $whereClause .= " AND a.status = ?";
            $params[] = $status;
        }
        
        if ($search) {
            $whereClause .= " AND (u.email LIKE ? OR u.username LIKE ? OR a.jamb_reg_no LIKE ? OR a.program LIKE ?)";
            $searchTerm = "%$search%";
            $params = array_merge($params, [$searchTerm, $searchTerm, $searchTerm, $searchTerm]);
        }
        
        $applications = $this->db->fetchAll(
            "SELECT a.*, u.email, u.username, 
                    p.status as payment_status, p.amount as payment_amount
             FROM applications a
             JOIN users u ON a.user_id = u.id
             LEFT JOIN payments p ON a.user_id = p.user_id AND p.payment_type = 'application_fee'
             $whereClause
             ORDER BY a.submitted_at DESC
             LIMIT $perPage OFFSET $offset",
            $params
        );
        
        $totalCount = $this->db->fetch(
            "SELECT COUNT(*) as count FROM applications a
             JOIN users u ON a.user_id = u.id 
             $whereClause",
            $params
        )['count'];
        
        $totalPages = ceil($totalCount / $perPage);
        
        $this->view('admin/applications', [
            'title' => 'Manage Applications - GEOD University',
            'applications' => $applications,
            'status' => $status,
            'search' => $search,
            'page' => $page,
            'total_pages' => $totalPages,
            'total_count' => $totalCount
        ]);
    }
    
    public function applicationDetails($params) {
        $this->requireAuth();
        $this->requireRole('admin');
        
        $applicationId = $params['id'] ?? null;
        if (!$applicationId) {
            Session::flash('error', 'Application not found');
            $this->redirect('/admin/applications');
        }
        
        $application = $this->db->fetch(
            "SELECT a.*, u.email, u.username, u.created_at as account_created,
                    s.first_name, s.last_name, s.phone, s.address, s.date_of_birth, s.gender,
                    p.amount as payment_amount, p.status as payment_status, p.paid_at
             FROM applications a
             JOIN users u ON a.user_id = u.id
             JOIN students s ON u.id = s.user_id
             LEFT JOIN payments p ON a.user_id = p.user_id AND p.payment_type = 'application_fee'
             WHERE a.id = ?",
            [$applicationId]
        );
        
        if (!$application) {
            Session::flash('error', 'Application not found');
            $this->redirect('/admin/applications');
        }
        
        $documents = [];
        if ($application['documents_path']) {
            $documents = json_decode($application['documents_path'], true) ?: [];
        }
        
        $reviewHistory = $this->db->fetchAll(
            "SELECT 'Application Submitted' as action, a.submitted_at as action_date, 'System' as action_by
             FROM applications a WHERE a.id = ?
             UNION ALL
             SELECT CONCAT('Status changed to ', a.status) as action, a.reviewed_at as action_date, 
                    COALESCE(u.username, 'System') as action_by
             FROM applications a
             LEFT JOIN users u ON a.reviewed_by = u.id
             WHERE a.id = ? AND a.reviewed_at IS NOT NULL
             ORDER BY action_date",
            [$applicationId, $applicationId]
        );
        
        $this->view('admin/application-details', [
            'title' => 'Application Details - GEOD University',
            'application' => $application,
            'documents' => $documents,
            'review_history' => $reviewHistory
        ]);
    }
    
    public function approveApplication($params) {
        $this->requireAuth();
        $this->requireRole('admin');
        $this->validateCSRF();
        
        $applicationId = $params['id'] ?? null;
        if (!$applicationId) {
            Session::flash('error', 'Application not found');
            $this->redirect('/admin/applications');
        }
        
        try {
            $this->db->beginTransaction();
            
            $application = $this->db->fetch(
                "SELECT a.*, u.email, s.first_name, s.last_name 
                 FROM applications a
                 JOIN users u ON a.user_id = u.id
                 JOIN students s ON u.id = s.user_id
                 WHERE a.id = ?",
                [$applicationId]
            );
            
            if (!$application) {
                throw new Exception('Application not found');
            }
            
            // Generate unique student ID based on program and year
            $programCode = $this->getProgramCode($application['program']);
            $year = date('Y');
            $sequence = $this->getNextStudentSequence($programCode, $year);
            $studentId = "{$programCode}/{$year}/" . str_pad($sequence, 3, '0', STR_PAD_LEFT);
            
            $result = $this->db->query(
                "UPDATE applications SET status = ?, reviewed_at = ?, reviewed_by = ?, notes = ? WHERE id = ?",
                ['approved', date('Y-m-d H:i:s'), Session::getUserId(), $_POST['notes'] ?? 'Application approved', $applicationId]
            );
            
            $this->db->update('students', [
                'student_id' => $studentId,
                'program' => $application['program'],
                'admission_year' => date('Y')
            ], 'user_id = ?', [$application['user_id']]);
            
            $this->db->update('users', [
                'role' => 'student'
            ], 'id = ?', [$application['user_id']]);
            
            $this->db->commit();
            
            $this->emailService->sendAdmissionNotificationEmail(
                $application['email'],
                $application['first_name'] . ' ' . $application['last_name'],
                'approved',
                $application['program'],
                $studentId
            );
            
            Session::flash('success', 'Application approved successfully! Student ID: ' . $studentId);
            $this->redirect('/admin/applications/' . $applicationId);
            
        } catch (Exception $e) {
            $this->db->rollback();
            error_log("Application approval error: " . $e->getMessage());
            Session::flash('error', 'Failed to approve application: ' . $e->getMessage());
            $this->redirect('/admin/applications/' . $applicationId);
        }
    }
    
    public function rejectApplication($params) {
        $this->requireAuth();
        $this->requireRole('admin');
        $this->validateCSRF();
        
        $applicationId = $params['id'] ?? null;
        $reason = $_POST['reason'] ?? 'Application does not meet admission requirements';
        
        if (!$applicationId) {
            Session::flash('error', 'Application not found');
            $this->redirect('/admin/applications');
        }
        
        try {
            $application = $this->db->fetch(
                "SELECT a.*, u.email, s.first_name, s.last_name 
                 FROM applications a
                 JOIN users u ON a.user_id = u.id
                 JOIN students s ON u.id = s.user_id
                 WHERE a.id = ?",
                [$applicationId]
            );
            
            if (!$application) {
                throw new Exception('Application not found');
            }
            
            $result = $this->db->query(
                "UPDATE applications SET status = ?, reviewed_at = ?, reviewed_by = ?, notes = ? WHERE id = ?",
                ['rejected', date('Y-m-d H:i:s'), Session::getUserId(), $reason, $applicationId]
            );
            
            // Send rejection notification email
            $this->emailService->sendAdmissionNotificationEmail(
                $application['email'],
                $application['first_name'] . ' ' . $application['last_name'],
                'rejected',
                $application['program']
            );
            
            Session::flash('success', 'Application rejected. Notification email sent.');
            $this->redirect('/admin/applications/' . $applicationId);
            
        } catch (Exception $e) {
            error_log("Application rejection error: " . $e->getMessage());
            Session::flash('error', 'Failed to reject application: ' . $e->getMessage());
            $this->redirect('/admin/applications/' . $applicationId);
        }
    }
    
    public function students() {
        $this->requireAuth();
        $this->requireRole('admin');
        
        $search = $_GET['search'] ?? '';
        $program = $_GET['program'] ?? '';
        $level = $_GET['level'] ?? '';
        $page = max(1, (int)($_GET['page'] ?? 1));
        $perPage = 20;
        $offset = ($page - 1) * $perPage;
        
        $whereClause = "WHERE u.role IN ('student', 'applicant')";
        $params = [];
        
        if ($search) {
            $whereClause .= " AND (u.email LIKE ? OR u.username LIKE ? OR s.first_name LIKE ? OR s.last_name LIKE ? OR s.student_id LIKE ?)";
            $searchTerm = "%$search%";
            $params = array_merge($params, array_fill(0, 5, $searchTerm));
        }
        
        if ($program) {
            $whereClause .= " AND s.program = ?";
            $params[] = $program;
        }
        
        if ($level) {
            $whereClause .= " AND s.level = ?";
            $params[] = $level;
        }
        
        $students = $this->db->fetchAll(
            "SELECT u.*, s.student_id, s.first_name, s.last_name, s.program, s.level, s.admission_year,
                    (SELECT COUNT(*) FROM enrollments e WHERE e.student_id = s.id AND e.status = 'enrolled') as enrolled_courses
             FROM users u
             LEFT JOIN students s ON u.id = s.user_id
             $whereClause
             ORDER BY s.admission_year DESC, s.student_id
             LIMIT $perPage OFFSET $offset",
            $params
        );
        
        $totalCount = $this->db->fetch(
            "SELECT COUNT(*) as count FROM users u
             LEFT JOIN students s ON u.id = s.user_id
             $whereClause",
            $params
        )['count'];
        
        $totalPages = ceil($totalCount / $perPage);
        
        $programs = $this->db->fetchAll("SELECT DISTINCT program FROM students WHERE program IS NOT NULL ORDER BY program");
        $levels = ['100', '200', '300', '400', '500'];
        
        $this->view('admin/students', [
            'title' => 'Manage Students - GEOD University',
            'students' => $students,
            'programs' => $programs,
            'levels' => $levels,
            'search' => $search,
            'program' => $program,
            'level' => $level,
            'page' => $page,
            'total_pages' => $totalPages,
            'total_count' => $totalCount
        ]);
    }
    
    public function payments() {
        $this->requireAuth();
        $this->requireRole('admin');
        
        $status = $_GET['status'] ?? 'all';
        $type = $_GET['type'] ?? 'all';
        $page = max(1, (int)($_GET['page'] ?? 1));
        $perPage = 20;
        $offset = ($page - 1) * $perPage;
        
        $whereClause = "WHERE 1=1";
        $params = [];
        
        if ($status !== 'all') {
            $whereClause .= " AND p.status = ?";
            $params[] = $status;
        }
        
        if ($type !== 'all') {
            $whereClause .= " AND p.payment_type = ?";
            $params[] = $type;
        }
        
        $payments = $this->db->fetchAll(
            "SELECT p.*, u.email, u.username
             FROM payments p
             JOIN users u ON p.user_id = u.id
             $whereClause
             ORDER BY p.created_at DESC
             LIMIT $perPage OFFSET $offset",
            $params
        );
        
        $summary = $this->db->fetch(
            "SELECT 
                COUNT(*) as total_payments,
                SUM(CASE WHEN status = 'completed' THEN amount ELSE 0 END) as total_revenue,
                SUM(CASE WHEN status = 'pending' THEN amount ELSE 0 END) as pending_amount,
                COUNT(CASE WHEN status = 'completed' THEN 1 END) as completed_payments,
                COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending_payments
             FROM payments p
             $whereClause",
            $params
        );
        
        $this->view('admin/payments', [
            'title' => 'Payment Reports - GEOD University',
            'payments' => $payments,
            'summary' => $summary,
            'status' => $status,
            'type' => $type
        ]);
    }
    
    public function reports() {
        $this->requireAuth();
        $this->requireRole('admin');
        
        $reportType = $_GET['type'] ?? 'applications';
        $startDate = $_GET['start_date'] ?? date('Y-m-01');
        $endDate = $_GET['end_date'] ?? date('Y-m-t');
        
        $data = [];
        
        switch ($reportType) {
            case 'applications':
                $data = $this->getApplicationsReport($startDate, $endDate);
                break;
            case 'payments':
                $data = $this->getPaymentsReport($startDate, $endDate);
                break;
            case 'enrollment':
                $data = $this->getEnrollmentReport($startDate, $endDate);
                break;
        }
        
        $this->view('admin/reports', [
            'title' => 'Reports - GEOD University',
            'report_type' => $reportType,
            'start_date' => $startDate,
            'end_date' => $endDate,
            'data' => $data
        ]);
    }
    
    
    private function getProgramCode($program) {
        $codes = [
            'Computer Science' => 'CSC',
            'Computer Engineering' => 'CPE',
            'Business Administration' => 'BUS',
            'Electrical Engineering' => 'EEE',
            'Mechanical Engineering' => 'MEE',
            'Civil Engineering' => 'CVE',
            'Mathematics' => 'MTH',
            'Physics' => 'PHY',
            'Chemistry' => 'CHM',
            'Medicine and Surgery' => 'MED'
        ];
        
        return $codes[$program] ?? 'GEN';
    }
    
    private function getNextStudentSequence($programCode, $year) {
        $lastStudent = $this->db->fetch(
            "SELECT student_id FROM students 
             WHERE student_id LIKE ? 
             ORDER BY student_id DESC LIMIT 1",
            ["{$programCode}/{$year}/%"]
        );
        
        if ($lastStudent) {
            $parts = explode('/', $lastStudent['student_id']);
            return (int)end($parts) + 1;
        }
        
        return 1;
    }
    
    private function getApplicationsReport($startDate, $endDate) {
        return $this->db->fetchAll(
            "SELECT 
                DATE(submitted_at) as date,
                COUNT(*) as total,
                COUNT(CASE WHEN status = 'approved' THEN 1 END) as approved,
                COUNT(CASE WHEN status = 'rejected' THEN 1 END) as rejected,
                COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending
             FROM applications 
             WHERE DATE(submitted_at) BETWEEN ? AND ?
             GROUP BY DATE(submitted_at)
             ORDER BY date",
            [$startDate, $endDate]
        );
    }
    
    private function getPaymentsReport($startDate, $endDate) {
        return $this->db->fetchAll(
            "SELECT 
                DATE(created_at) as date,
                payment_type,
                COUNT(*) as count,
                SUM(amount) as total_amount,
                COUNT(CASE WHEN status = 'completed' THEN 1 END) as completed
             FROM payments 
             WHERE DATE(created_at) BETWEEN ? AND ?
             GROUP BY DATE(created_at), payment_type
             ORDER BY date, payment_type",
            [$startDate, $endDate]
        );
    }
    
    private function getEnrollmentReport($startDate, $endDate) {
        return $this->db->fetchAll(
            "SELECT 
                DATE(e.enrollment_date) as date,
                c.course_code,
                c.course_name,
                COUNT(*) as enrollments
             FROM enrollments e
             JOIN courses c ON e.course_id = c.id
             WHERE DATE(e.enrollment_date) BETWEEN ? AND ?
             GROUP BY DATE(e.enrollment_date), c.id
             ORDER BY date, c.course_code",
            [$startDate, $endDate]
        );
    }
}