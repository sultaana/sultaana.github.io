<?php

class MessageController extends Controller {
    
    private $messageModel;
    
    public function __construct() {
        parent::__construct();
        $this->messageModel = new Message();
    }
    
    /**
     * Display message inbox
     */
    public function index() {
        $this->requireAuth();
        
        $userId = Session::getUserId();
        $type = $_GET['type'] ?? null;
        
        // Get user's messages
        $messages = $this->messageModel->getUserMessages($userId, $type);
        
        // Get unread count
        $unreadCount = $this->messageModel->getUnreadCount($userId);
        
        // Get message type counts
        $personalCount = count($this->messageModel->getUserMessages($userId, 'personal'));
        $announcementCount = count($this->messageModel->getUserMessages($userId, 'announcement'));
        $systemCount = count($this->messageModel->getUserMessages($userId, 'system'));
        
        $this->view('messages/index', [
            'title' => 'Messages - GEOD University',
            'messages' => $messages,
            'unread_count' => $unreadCount,
            'current_type' => $type,
            'personal_count' => $personalCount,
            'announcement_count' => $announcementCount,
            'system_count' => $systemCount
        ]);
    }
    
    /**
     * Show compose message form
     */
    public function compose() {
        $this->requireAuth();
        
        $userRole = Session::getUserRole();
        $recipients = [];
        
        // Get available recipients based on user role
        if ($userRole === 'admin') {
            // Admin can message anyone
            $recipients = $this->db->fetchAll(
                "SELECT id, username, role FROM users WHERE id != ? ORDER BY role, username",
                [Session::getUserId()]
            );
        } elseif ($userRole === 'faculty') {
            // Faculty can message students and admin
            $recipients = $this->db->fetchAll(
                "SELECT id, username, role FROM users WHERE role IN ('student', 'admin') ORDER BY role, username"
            );
        } else {
            // Students can message admin and faculty
            $recipients = $this->db->fetchAll(
                "SELECT id, username, role FROM users WHERE role IN ('admin', 'faculty') ORDER BY role, username"
            );
        }
        
        $this->view('messages/compose', [
            'title' => 'Compose Message - GEOD University',
            'recipients' => $recipients,
            'reply_to' => $_GET['reply_to'] ?? null
        ]);
    }
    
    /**
     * Send a message
     */
    public function send() {
        $this->requireAuth();
        $this->validateCSRF();
        
        $senderId = Session::getUserId();
        $receiverId = $_POST['receiver_id'] ?? null;
        $subject = $_POST['subject'] ?? '';
        $message = $_POST['message'] ?? '';
        $messageType = $_POST['message_type'] ?? 'personal';
        
        // Validate input
        if (!$receiverId || !$subject || !$message) {
            Session::flash('error', 'All fields are required');
            $this->redirect('/messages/compose');
        }
        
        // Check if receiver exists
        $receiver = $this->db->fetch("SELECT id, role FROM users WHERE id = ?", [$receiverId]);
        if (!$receiver) {
            Session::flash('error', 'Invalid recipient');
            $this->redirect('/messages/compose');
        }
        
        // Check if user can message this recipient
        if (!$this->canMessageUser($receiver['role'])) {
            Session::flash('error', 'You are not authorized to message this user');
            $this->redirect('/messages/compose');
        }
        
        try {
            $this->messageModel->sendMessage($senderId, $receiverId, $subject, $message, $messageType);
            Session::flash('success', 'Message sent successfully');
            $this->redirect('/messages');
        } catch (Exception $e) {
            error_log("Message send error: " . $e->getMessage());
            Session::flash('error', 'Failed to send message');
            $this->redirect('/messages/compose');
        }
    }
    
    /**
     * View a specific message
     */
    public function viewMessage($params) {
        $this->requireAuth();
        
        $messageId = $params['id'] ?? null;
        $userId = Session::getUserId();
        
        if (!$messageId) {
            Session::flash('error', 'Message not found');
            $this->redirect('/messages');
        }
        
        // Get message details
        $message = $this->db->fetch(
            "SELECT m.*, 
                    sender.username as sender_name, sender.role as sender_role,
                    receiver.username as receiver_name, receiver.role as receiver_role
             FROM messages m
             JOIN users sender ON m.sender_id = sender.id
             JOIN users receiver ON m.receiver_id = receiver.id
             WHERE m.id = ? AND (m.sender_id = ? OR m.receiver_id = ?)",
            [$messageId, $userId, $userId]
        );
        
        if (!$message) {
            Session::flash('error', 'Message not found or access denied');
            $this->redirect('/messages');
        }
        
        // Mark as read if user is the receiver
        if ($message['receiver_id'] == $userId && !$message['read_status']) {
            $this->messageModel->markAsRead($messageId, $userId);
        }
        
        $this->view('messages/view', [
            'title' => $message['subject'] . ' - Messages',
            'message' => $message
        ]);
    }
    
    /**
     * Reply to a message
     */
    public function reply($params) {
        $this->requireAuth();
        
        $messageId = $params['id'] ?? null;
        $userId = Session::getUserId();
        
        if (!$messageId) {
            Session::flash('error', 'Message not found');
            $this->redirect('/messages');
        }
        
        // Get original message
        $originalMessage = $this->db->fetch(
            "SELECT m.*, u.username as sender_name
             FROM messages m
             JOIN users u ON m.sender_id = u.id
             WHERE m.id = ? AND m.receiver_id = ?",
            [$messageId, $userId]
        );
        
        if (!$originalMessage) {
            Session::flash('error', 'Message not found or access denied');
            $this->redirect('/messages');
        }
        
        $this->view('messages/reply', [
            'title' => 'Reply to Message - GEOD University',
            'original_message' => $originalMessage
        ]);
    }
    
    /**
     * Send reply to a message
     */
    public function sendReply() {
        $this->requireAuth();
        $this->validateCSRF();
        
        $originalMessageId = $_POST['original_message_id'] ?? null;
        $message = $_POST['message'] ?? '';
        $userId = Session::getUserId();
        
        if (!$originalMessageId || !$message) {
            Session::flash('error', 'All fields are required');
            $this->redirect('/messages');
        }
        
        // Get original message
        $originalMessage = $this->db->fetch(
            "SELECT * FROM messages WHERE id = ? AND receiver_id = ?",
            [$originalMessageId, $userId]
        );
        
        if (!$originalMessage) {
            Session::flash('error', 'Original message not found');
            $this->redirect('/messages');
        }
        
        try {
            $subject = 'Re: ' . $originalMessage['subject'];
            $this->messageModel->sendMessage(
                $userId, 
                $originalMessage['sender_id'], 
                $subject, 
                $message, 
                'personal'
            );
            
            Session::flash('success', 'Reply sent successfully');
            $this->redirect('/messages/' . $originalMessageId);
        } catch (Exception $e) {
            error_log("Reply send error: " . $e->getMessage());
            Session::flash('error', 'Failed to send reply');
            $this->redirect('/messages/' . $originalMessageId);
        }
    }
    
    /**
     * Delete a message
     */
    public function delete($params) {
        $this->requireAuth();
        $this->validateCSRF();
        
        $messageId = $params['id'] ?? null;
        $userId = Session::getUserId();
        
        if (!$messageId) {
            Session::flash('error', 'Message not found');
            $this->redirect('/messages');
        }
        
        try {
            $deleted = $this->messageModel->deleteMessage($messageId, $userId);
            if ($deleted) {
                Session::flash('success', 'Message deleted successfully');
            } else {
                Session::flash('error', 'Message not found or access denied');
            }
        } catch (Exception $e) {
            error_log("Message delete error: " . $e->getMessage());
            Session::flash('error', 'Failed to delete message');
        }
        
        $this->redirect('/messages');
    }
    
    /**
     * Send announcement (admin only)
     */
    public function announcement() {
        $this->requireAuth();
        $this->requireRole('admin');
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->validateCSRF();
            
            $subject = $_POST['subject'] ?? '';
            $message = $_POST['message'] ?? '';
            $recipients = $_POST['recipients'] ?? [];
            
            if (!$subject || !$message || empty($recipients)) {
                Session::flash('error', 'All fields are required');
                $this->redirect('/messages/announcement');
            }
            
            try {
                $this->messageModel->sendAnnouncement(Session::getUserId(), $recipients, $subject, $message);
                Session::flash('success', 'Announcement sent to ' . count($recipients) . ' users');
                $this->redirect('/messages');
            } catch (Exception $e) {
                error_log("Announcement send error: " . $e->getMessage());
                Session::flash('error', 'Failed to send announcement');
                $this->redirect('/messages/announcement');
            }
        }
        
        // Get all users for announcement recipients
        $users = $this->db->fetchAll(
            "SELECT id, username, role FROM users WHERE id != ? ORDER BY role, username",
            [Session::getUserId()]
        );
        
        $this->view('messages/announcement', [
            'title' => 'Send Announcement - GEOD University',
            'users' => $users
        ]);
    }
    
    /**
     * Get unread message count (AJAX)
     */
    public function unreadCount() {
        $this->requireAuth();
        
        $userId = Session::getUserId();
        $count = $this->messageModel->getUnreadCount($userId);
        
        $this->json(['success' => true, 'count' => $count]);
    }
    
    /**
     * Mark message as read (AJAX)
     */
    public function markRead($params) {
        $this->requireAuth();
        
        $messageId = $params['id'] ?? null;
        $userId = Session::getUserId();
        
        if (!$messageId) {
            $this->json(['success' => false, 'message' => 'Invalid message ID'], 400);
        }
        
        try {
            $this->messageModel->markAsRead($messageId, $userId);
            $this->json(['success' => true]);
        } catch (Exception $e) {
            error_log("Mark read error: " . $e->getMessage());
            $this->json(['success' => false, 'message' => 'Failed to mark as read'], 500);
        }
    }
    
    /**
     * Search messages
     */
    public function search() {
        $this->requireAuth();
        
        $query = $_GET['q'] ?? '';
        $userId = Session::getUserId();
        
        if (strlen($query) < 2) {
            $this->json(['success' => false, 'message' => 'Query too short'], 400);
        }
        
        try {
            $messages = $this->db->fetchAll(
                "SELECT m.*, u.username as sender_name
                 FROM messages m
                 JOIN users u ON m.sender_id = u.id
                 WHERE (m.receiver_id = ? OR m.sender_id = ?)
                   AND (m.subject LIKE ? OR m.message LIKE ?)
                 ORDER BY m.created_at DESC
                 LIMIT 20",
                [$userId, $userId, "%$query%", "%$query%"]
            );
            
            $this->json(['success' => true, 'messages' => $messages]);
        } catch (Exception $e) {
            error_log("Message search error: " . $e->getMessage());
            $this->json(['success' => false, 'message' => 'Search failed'], 500);
        }
    }
    
    // Helper methods
    
    private function canMessageUser($receiverRole) {
        $userRole = Session::getUserRole();
        
        // Admin can message anyone
        if ($userRole === 'admin') {
            return true;
        }
        
        // Faculty can message students and admin
        if ($userRole === 'faculty') {
            return in_array($receiverRole, ['student', 'admin']);
        }
        
        // Students can message admin and faculty
        if ($userRole === 'student') {
            return in_array($receiverRole, ['admin', 'faculty']);
        }
        
        return false;
    }
}