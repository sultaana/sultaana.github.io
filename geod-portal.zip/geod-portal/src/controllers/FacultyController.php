<?php

class FacultyController extends Controller {
    
    private $courseModel;
    private $studentModel;
    
    public function __construct() {
        parent::__construct();
        $this->courseModel = new Course();
        $this->studentModel = new Student();
    }
    
    public function dashboard() {
        $this->requireAuth();
        $this->requireRole('faculty');
        
        $facultyId = Session::getUserId();
        $assignedCourses = $this->db->fetchAll(
            "SELECT c.*, 
                    (SELECT COUNT(*) FROM enrollments e WHERE e.course_id = c.id AND e.status = 'enrolled') as enrolled_count
             FROM courses c
             WHERE c.faculty_id = ? AND c.status = 'active'
             ORDER BY c.course_code",
            [$facultyId]
        );
        
        $stats = [
            'total_courses' => count($assignedCourses),
            'total_students' => $this->db->fetch(
                "SELECT COUNT(DISTINCT e.student_id) as count 
                 FROM enrollments e 
                 JOIN courses c ON e.course_id = c.id 
                 WHERE c.faculty_id = ? AND e.status = 'enrolled'",
                [$facultyId]
            )['count'],
            'pending_grades' => $this->db->fetch(
                "SELECT COUNT(*) as count 
                 FROM enrollments e 
                 JOIN courses c ON e.course_id = c.id 
                 WHERE c.faculty_id = ? AND e.grade IS NULL AND e.status = 'enrolled'",
                [$facultyId]
            )['count'],
            'completed_courses' => $this->db->fetch(
                "SELECT COUNT(*) as count 
                 FROM enrollments e 
                 JOIN courses c ON e.course_id = c.id 
                 WHERE c.faculty_id = ? AND e.status = 'completed'",
                [$facultyId]
            )['count']
        ];
        
        $recentEnrollments = $this->db->fetchAll(
            "SELECT e.*, c.course_code, c.course_name, s.student_id, u.username,
                    s.first_name, s.last_name
             FROM enrollments e
             JOIN courses c ON e.course_id = c.id
             JOIN students s ON e.student_id = s.id
             JOIN users u ON s.user_id = u.id
             WHERE c.faculty_id = ? AND e.status = 'enrolled'
             ORDER BY e.enrolled_at DESC
             LIMIT 10",
            [$facultyId]
        );
        
        $this->view('faculty/dashboard', [
            'title' => 'Faculty Dashboard - GEOD University',
            'assigned_courses' => $assignedCourses,
            'stats' => $stats,
            'recent_enrollments' => $recentEnrollments
        ]);
    }
    
    public function courses() {
        $this->requireAuth();
        $this->requireRole('faculty');
        
        $facultyId = Session::getUserId();
        
        $courses = $this->db->fetchAll(
            "SELECT c.*, d.name as department_name, f.name as faculty_name,
                    (SELECT COUNT(*) FROM enrollments e WHERE e.course_id = c.id AND e.status = 'enrolled') as enrolled_count,
                    (SELECT COUNT(*) FROM enrollments e WHERE e.course_id = c.id AND e.grade IS NULL AND e.status = 'enrolled') as pending_grades
             FROM courses c
             JOIN departments d ON c.department_id = d.id
             JOIN faculties f ON d.faculty_id = f.id
             WHERE c.faculty_id = ?
             ORDER BY c.course_code",
            [$facultyId]
        );
        
        $this->view('faculty/courses', [
            'title' => 'My Courses - GEOD University',
            'courses' => $courses
        ]);
    }
    
    public function courseDetails($params) {
        $this->requireAuth();
        $this->requireRole('faculty');
        
        $courseId = $params['id'] ?? null;
        $facultyId = Session::getUserId();
        
        if (!$courseId) {
            Session::flash('error', 'Course not found');
            $this->redirect('/faculty/courses');
        }
        
        $course = $this->db->fetch(
            "SELECT c.*, d.name as department_name, f.name as faculty_name
             FROM courses c
             JOIN departments d ON c.department_id = d.id
             JOIN faculties f ON d.faculty_id = f.id
             WHERE c.id = ? AND c.faculty_id = ?",
            [$courseId, $facultyId]
        );
        
        if (!$course) {
            Session::flash('error', 'Course not found or access denied');
            $this->redirect('/faculty/courses');
        }
        
        $students = $this->db->fetchAll(
            "SELECT e.*, s.student_id, s.first_name, s.last_name, s.level, u.email,
                    e.grade, e.grade_point, e.status as enrollment_status
             FROM enrollments e
             JOIN students s ON e.student_id = s.id
             JOIN users u ON s.user_id = u.id
             WHERE e.course_id = ?
             ORDER BY s.student_id",
            [$courseId]
        );
        
        $this->view('faculty/course-details', [
            'title' => $course['course_name'] . ' - GEOD University',
            'course' => $course,
            'students' => $students
        ]);
    }
    
    public function courseStudents($params) {
        $this->requireAuth();
        $this->requireRole('faculty');
        
        $courseId = $params['id'] ?? null;
        $facultyId = Session::getUserId();
        
        if (!$courseId) {
            $this->json(['error' => 'Course not found'], 404);
        }
        
        $course = $this->db->fetch(
            "SELECT * FROM courses WHERE id = ? AND faculty_id = ?",
            [$courseId, $facultyId]
        );
        
        if (!$course) {
            $this->json(['error' => 'Course not found or access denied'], 403);
        }
        
        $students = $this->db->fetchAll(
            "SELECT e.*, s.student_id, s.first_name, s.last_name, s.level, u.email
             FROM enrollments e
             JOIN students s ON e.student_id = s.id
             JOIN users u ON s.user_id = u.id
             WHERE e.course_id = ? AND e.status = 'enrolled'
             ORDER BY s.student_id",
            [$courseId]
        );
        
        $this->json(['success' => true, 'students' => $students]);
    }
    
    public function submitGrades($params) {
        $this->requireAuth();
        $this->requireRole('faculty');
        $this->validateCSRF();
        
        $courseId = $params['id'] ?? null;
        $facultyId = Session::getUserId();
        $grades = $_POST['grades'] ?? [];
        
        if (!$courseId || empty($grades)) {
            $this->json(['error' => 'Invalid data provided'], 400);
        }
        
        $course = $this->db->fetch(
            "SELECT * FROM courses WHERE id = ? AND faculty_id = ?",
            [$courseId, $facultyId]
        );
        
        if (!$course) {
            $this->json(['error' => 'Course not found or access denied'], 403);
        }
        
        try {
            $this->db->beginTransaction();
            
            $updated = 0;
            foreach ($grades as $enrollmentId => $gradeData) {
                $grade = $gradeData['grade'] ?? '';
                $gradePoint = $this->calculateGradePoint($grade);
                
                if (!empty($grade)) {
                    $result = $this->db->query(
                        "UPDATE enrollments SET grade = ?, grade_point = ?, status = 'completed', graded_at = NOW() 
                         WHERE id = ? AND course_id = ?",
                        [$grade, $gradePoint, $enrollmentId, $courseId]
                    );
                    
                    if ($result) {
                        $updated++;
                    }
                }
            }
            
            $this->db->commit();
            
            $this->json([
                'success' => true, 
                'message' => "Successfully updated {$updated} grade(s)",
                'updated_count' => $updated
            ]);
            
        } catch (Exception $e) {
            $this->db->rollback();
            error_log("Grade submission error: " . $e->getMessage());
            $this->json(['error' => 'Failed to submit grades'], 500);
        }
    }
    
    private function calculateGradePoint($grade) {
        $gradePoints = [
            'A' => 5.0,
            'B' => 4.0,
            'C' => 3.0,
            'D' => 2.0,
            'E' => 1.0,
            'F' => 0.0
        ];
        
        return $gradePoints[strtoupper($grade)] ?? 0.0;
    }
    
    public function students() {
        $this->requireAuth();
        $this->requireRole('faculty');
        
        $facultyId = Session::getUserId();
        
        $students = $this->db->fetchAll(
            "SELECT DISTINCT s.*, u.email, u.username,
                    GROUP_CONCAT(DISTINCT c.course_code ORDER BY c.course_code) as enrolled_courses,
                    COUNT(DISTINCT e.id) as total_enrollments,
                    AVG(e.grade_point) as avg_gpa
             FROM students s
             JOIN users u ON s.user_id = u.id
             JOIN enrollments e ON s.id = e.student_id
             JOIN courses c ON e.course_id = c.id
             WHERE c.faculty_id = ? AND e.status IN ('enrolled', 'completed')
             GROUP BY s.id
             ORDER BY s.student_id",
            [$facultyId]
        );
        
        $this->view('faculty/students', [
            'title' => 'My Students - GEOD University',
            'students' => $students
        ]);
    }
}