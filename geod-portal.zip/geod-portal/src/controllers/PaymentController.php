<?php

class PaymentController extends Controller {
    
    private $paymentModel;
    private $paystackService;
    private $emailService;
    
    public function __construct() {
        parent::__construct();
        $this->paymentModel = new Payment();
        $this->paystackService = new PaystackService();
        $this->emailService = new EmailService();
    }
    
    public function index() {
        $this->requireAuth();
        
        $userId = Session::getUserId();
        
        $payments = $this->db->fetchAll(
            "SELECT * FROM payments WHERE user_id = ? ORDER BY created_at DESC",
            [$userId]
        );
        
        $totalPaid = $this->db->fetch(
            "SELECT SUM(amount) as total FROM payments WHERE user_id = ? AND status = 'completed'",
            [$userId]
        )['total'] ?? 0;
        
        $pendingPayments = $this->db->fetch(
            "SELECT COUNT(*) as count FROM payments WHERE user_id = ? AND status = 'pending'",
            [$userId]
        )['count'] ?? 0;
        
        $this->view('payments/index', [
            'title' => 'Payment History - GEOD University',
            'payments' => $payments,
            'total_paid' => $totalPaid,
            'pending_payments' => $pendingPayments
        ]);
    }
    
    public function fees() {
        $this->requireAuth();
        
        $userRole = Session::getUserRole();
        $userId = Session::getUserId();
        
        $feeStructure = [
            'application_fee' => 3000.00,
            'acceptance_fee' => 25000.00,
            'school_fees' => $this->getSchoolFees($userId),
            'course_registration' => 2000.00
        ];
        
        $paidFees = $this->db->fetchAll(
            "SELECT payment_type, amount, status FROM payments WHERE user_id = ? AND status = 'completed'",
            [$userId]
        );
        
        $this->view('payments/fees', [
            'title' => 'Fee Structure - GEOD University',
            'fee_structure' => $feeStructure,
            'paid_fees' => $paidFees,
            'user_role' => $userRole
        ]);
    }
    
    public function initiate() {
        $this->requireAuth();
        $this->validateCSRF();
        
        $userId = Session::getUserId();
        $userEmail = Session::get('user_email');
        $username = Session::get('username');
        
        $paymentType = $_POST['payment_type'] ?? '';
        $amount = (float)($_POST['amount'] ?? 0);
        
        $allowedTypes = ['application_fee', 'acceptance_fee', 'school_fees', 'course_registration'];
        if (!in_array($paymentType, $allowedTypes)) {
            $this->json(['error' => 'Invalid payment type'], 400);
        }
        
        if ($amount <= 0) {
            $this->json(['error' => 'Invalid amount'], 400);
        }
        
        // Prevent duplicate payments for same type
        $existingPayment = $this->db->fetch(
            "SELECT * FROM payments WHERE user_id = ? AND payment_type = ? AND status = 'completed'",
            [$userId, $paymentType]
        );
        
        if ($existingPayment) {
            $this->json(['error' => 'Payment already completed for this type'], 400);
        }
        
        // Handle pending payments - verify actual status before blocking
        $pendingPayment = $this->db->fetch(
            "SELECT * FROM payments WHERE user_id = ? AND payment_type = ? AND status = 'pending' ORDER BY created_at DESC LIMIT 1",
            [$userId, $paymentType]
        );
        
        if ($pendingPayment) {
            $verification = $this->paystackService->verifyPayment($pendingPayment['reference']);
            
            if ($verification['success'] && $verification['status'] === 'success') {
                $result = $this->db->query(
                    "UPDATE payments SET status = ?, paystack_reference = ?, payment_method = ?, gateway_response = ?, paid_at = ? WHERE reference = ?",
                    ['completed', $verification['reference'], 'card', json_encode($verification['data']), date('Y-m-d H:i:s', strtotime($verification['paid_at'])), $pendingPayment['reference']]
                );
                
                $this->json(['error' => 'Payment already completed for this type'], 400);
                
            } elseif ($verification['success'] && in_array($verification['status'], ['failed', 'cancelled', 'abandoned'])) {
                $this->db->query(
                    "UPDATE payments SET status = ?, gateway_response = ? WHERE reference = ?",
                    ['failed', json_encode($verification), $pendingPayment['reference']]
                );
                
            } else {
                // Still pending - check if recent enough to block retry
                $paymentTime = strtotime($pendingPayment['created_at']);
                if (time() - $paymentTime < 600) {
                    $this->json([
                        'error' => 'You have a recent pending payment. Please wait a few minutes or check its status first.',
                        'pending_reference' => $pendingPayment['reference']
                    ], 400);
                } else {
                    $this->db->query(
                        "UPDATE payments SET status = ? WHERE reference = ?",
                        ['abandoned', $pendingPayment['reference']]
                    );
                }
            }
        }
        
        try {
            $reference = 'GEO-' . strtoupper(substr($paymentType, 0, 3)) . '-' . date('Y') . '-' . str_pad($userId, 3, '0', STR_PAD_LEFT) . '-' . time() . '-' . rand(100, 999);
            
            $paymentId = $this->db->insert('payments', [
                'user_id' => $userId,
                'payment_type' => $paymentType,
                'amount' => $amount,
                'status' => 'pending',
                'reference' => $reference,
                'created_at' => date('Y-m-d H:i:s')
            ]);
            
            $paymentData = $this->paystackService->initializePayment(
                $userEmail,
                $amount,
                $reference,
                [
                    'user_id' => $userId,
                    'payment_type' => $paymentType,
                    'payment_id' => $paymentId,
                    'username' => $username
                ]
            );
            
            if ($paymentData['success']) {
                $this->json([
                    'success' => true,
                    'authorization_url' => $paymentData['authorization_url'],
                    'reference' => $reference
                ]);
            } else {
                $this->db->delete('payments', 'id = ?', [$paymentId]);
                $this->json(['error' => $paymentData['message']], 400);
            }
            
        } catch (Exception $e) {
            error_log("Payment initiation error: " . $e->getMessage());
            $this->json(['error' => 'Payment initiation failed'], 500);
        }
    }
    
    public function verify($params) {
        $reference = $params['reference'] ?? null;
        if (!$reference) {
            Session::flash('error', 'Invalid payment reference');
            $this->redirect('/auth/login');
        }
        
        // Redirect unauthenticated users to login with return URL
        if (!Session::isLoggedIn()) {
            Session::set('redirect_after_login', '/payments/verify/' . $reference);
            Session::flash('info', 'Please log in to complete payment verification.');
            $this->redirect('/auth/login');
        }
        
        try {
            $verification = $this->paystackService->verifyPayment($reference);
            
            if ($verification['success'] && $verification['status'] === 'success') {
                // Update payment record
                $result = $this->db->query(
                    "UPDATE payments SET status = ?, paystack_reference = ?, payment_method = ?, gateway_response = ?, paid_at = ? WHERE reference = ?",
                    ['completed', $verification['reference'], 'card', json_encode($verification['data']), date('Y-m-d H:i:s', strtotime($verification['paid_at'])), $reference]
                );
                
                // Get payment details
                $payment = $this->db->fetch(
                    "SELECT p.*, u.username FROM payments p JOIN users u ON p.user_id = u.id WHERE p.reference = ?",
                    [$reference]
                );
                
                if ($payment) {
                    // Send confirmation email
                    $this->emailService->sendPaymentConfirmationEmail(
                        Session::get('user_email'),
                        $payment['username'],
                        $payment['amount'],
                        $payment['payment_type'],
                        $reference
                    );
                    
                    // Update user role if necessary
                    $this->updateUserRoleAfterPayment($payment);
                }
                
                Session::flash('success', 'Payment verified successfully! Payment confirmation email sent.');
                $this->redirect('/payments');
                
            } else {
                // Update payment as failed
                $this->db->update('payments', [
                    'status' => 'failed',
                    'gateway_response' => json_encode($verification)
                ], 'reference = ?', [$reference]);
                
                Session::flash('error', 'Payment verification failed. Please try again or contact support.');
                $this->redirect('/payments');
            }
            
        } catch (Exception $e) {
            error_log("Payment verification error: " . $e->getMessage());
            Session::flash('error', 'Payment verification error. Please contact support.');
            $this->redirect('/payments');
        }
    }
    
    public function checkStatus($params) {
        $this->requireAuth();
        
        $reference = $params['reference'] ?? null;
        if (!$reference) {
            $this->json(['error' => 'Invalid payment reference'], 400);
        }
        
        try {
            $payment = $this->db->fetch(
                "SELECT * FROM payments WHERE reference = ? AND user_id = ?",
                [$reference, Session::getUserId()]
            );
            
            if (!$payment) {
                $this->json(['error' => 'Payment not found'], 404);
            }
            
            if ($payment['status'] === 'completed') {
                $this->json(['success' => true, 'status' => 'completed', 'message' => 'Payment already verified']);
            }
            
            // Check with Paystack
            $verification = $this->paystackService->verifyPayment($reference);
            error_log("Payment verification result: " . json_encode($verification));
            
            if ($verification['success'] && $verification['status'] === 'success') {
                // Update payment record
                $result = $this->db->query(
                    "UPDATE payments SET status = ?, paystack_reference = ?, payment_method = ?, gateway_response = ?, paid_at = ? WHERE reference = ?",
                    ['completed', $verification['reference'], 'card', json_encode($verification['data']), date('Y-m-d H:i:s', strtotime($verification['paid_at'])), $reference]
                );
                
                // Get updated payment details
                $payment = $this->db->fetch(
                    "SELECT p.*, u.username FROM payments p JOIN users u ON p.user_id = u.id WHERE p.reference = ?",
                    [$reference]
                );
                
                if ($payment) {
                    // Send confirmation email
                    $this->emailService->sendPaymentConfirmationEmail(
                        Session::get('user_email'),
                        $payment['username'],
                        $payment['amount'],
                        $payment['payment_type'],
                        $reference
                    );
                    
                    // Update user role if necessary
                    $this->updateUserRoleAfterPayment($payment);
                }
                
                $this->json(['success' => true, 'status' => 'completed', 'message' => 'Payment verified successfully!']);
                
            } else {
                // Update payment as failed if Paystack says it failed
                if ($verification['success'] === false) {
                    $this->db->update('payments', [
                        'status' => 'failed',
                        'gateway_response' => json_encode($verification)
                    ], 'reference = ?', [$reference]);
                }
                
                $this->json(['success' => false, 'status' => $payment['status'], 'message' => 'Payment not completed on Paystack']);
            }
            
        } catch (Exception $e) {
            error_log("Payment status check error: " . $e->getMessage());
            $this->json(['error' => 'Payment status check failed'], 500);
        }
    }
    
    public function receipt($params) {
        $this->requireAuth();
        
        $paymentId = $params['id'] ?? null;
        $userId = Session::getUserId();
        
        $payment = $this->db->fetch(
            "SELECT p.*, u.username, u.email FROM payments p 
             JOIN users u ON p.user_id = u.id 
             WHERE p.id = ? AND p.user_id = ? AND p.status = 'completed'",
            [$paymentId, $userId]
        );
        
        if (!$payment) {
            Session::flash('error', 'Payment receipt not found');
            $this->redirect('/payments');
        }
        
        $this->view('payments/receipt', [
            'title' => 'Payment Receipt - GEOD University',
            'payment' => $payment
        ]);
    }
    
    public function webhook() {
        $payload = file_get_contents('php://input');
        $signature = $_SERVER['HTTP_X_PAYSTACK_SIGNATURE'] ?? '';
        
        if (!$this->paystackService->verifyWebhookSignature($payload, $signature)) {
            http_response_code(400);
            echo json_encode(['error' => 'Invalid signature']);
            exit;
        }
        
        $result = $this->paystackService->handleWebhook($payload);
        
        if ($result['success']) {
            http_response_code(200);
            echo json_encode(['message' => 'Webhook processed']);
        } else {
            http_response_code(400);
            echo json_encode(['error' => $result['message']]);
        }
    }
    
    private function getSchoolFees($userId) {
        $student = $this->db->fetch(
            "SELECT program FROM students WHERE user_id = ?",
            [$userId]
        );
        
        $feeStructure = [
            'Medicine' => 150000,
            'Engineering' => 120000,
            'Computer Science' => 100000,
            'Business Administration' => 85000,
            'Law' => 95000,
            'Arts' => 75000
        ];
        
        if ($student) {
            foreach ($feeStructure as $program => $fee) {
                if (stripos($student['program'], $program) !== false) {
                    return $fee;
                }
            }
        }
        
        return 80000;
    }
    
    private function updateUserRoleAfterPayment($payment) {
        if ($payment['payment_type'] === 'application_fee') {
            return;
        }
        
        if ($payment['payment_type'] === 'acceptance_fee') {
            $this->db->update('users', [
                'role' => 'student'
            ], 'id = ?', [$payment['user_id']]);
            
            if (Session::getUserId() == $payment['user_id']) {
                Session::set('user_role', 'student');
            }
        }
    }
}