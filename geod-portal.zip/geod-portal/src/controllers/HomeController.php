<?php

class HomeController extends Controller {
    
    public function index() {
        $data = [];
        
        // pass data to view 
        $this->view('home/index', $data);
    }
    
    public function about() {
        $this->view('home/about');
    }
    
    public function contact() {
        $this->view('home/contact');
    }
    
    public function programmes() {
        $this->view('home/program');
    }
    
    public function admissionRequirements() {
        $this->view('home/admission-requirements');
    }
}
