<?php

class ApplicationController extends Controller {
    
    private $applicationModel;
    private $studentModel;
    private $emailService;
    
    public function __construct() {
        parent::__construct();
        $this->applicationModel = new Application();
        $this->studentModel = new Student();
        $this->emailService = new EmailService();
    }
    
    public function showForm() {
        $this->requireAuth();
        $this->requireRole('applicant');
        
        $userId = Session::getUserId();
        
        $existingApplication = $this->db->fetch(
            "SELECT * FROM applications WHERE user_id = ? ORDER BY submitted_at DESC LIMIT 1",
            [$userId]
        );
        
        if ($existingApplication) {
            $this->redirect('/application/status');
        }
        
        $userModel = new User();
        $profile = $userModel->getProfile($userId);
        $faculties = $this->db->fetchAll("SELECT * FROM faculties ORDER BY name");
        $states = $this->db->fetchAll("SELECT * FROM nigerian_states ORDER BY name");
        
        $this->view('application/form', compact('profile', 'faculties', 'states') + [
            'title' => 'University Application - GEOD University',
            'csrf_token' => CSRF::getToken()
        ]);
    }

    // application submission
    public function submit() {
        $this->requireAuth();
        $this->requireRole('applicant');
        $this->validateCSRFForm();
        
        $userId = Session::getUserId();
        
        $existingApplication = $this->db->fetch(
            "SELECT * FROM applications WHERE user_id = ?",
            [$userId]
        );
        
        if ($existingApplication) {
            Session::flash('error', 'You have already submitted an application.');
            $this->redirect('/application/status');
        }
        
        $data = [
            'full_name' => Validator::sanitizeInput($_POST['full_name'] ?? ''),
            'phone' => Validator::sanitizeInput($_POST['phone'] ?? ''),
            'email' => Validator::sanitizeInput($_POST['email'] ?? ''),
            'faculty_id' => (int)($_POST['faculty_id'] ?? 0),
            'department_id' => (int)($_POST['department_id'] ?? 0),
            'nationality' => Validator::sanitizeInput($_POST['nationality'] ?? 'Nigerian'),
            'address' => Validator::sanitizeInput($_POST['address'] ?? ''),
            'state_of_origin' => Validator::sanitizeInput($_POST['state_of_origin'] ?? ''),
            'lga' => Validator::sanitizeInput($_POST['lga'] ?? ''),
            'date_of_birth' => $_POST['date_of_birth'] ?? '',
            'gender' => $_POST['gender'] ?? '',
            'jamb_reg_no' => Validator::sanitizeInput($_POST['jamb_reg_no'] ?? ''),
            'jamb_score' => (int)($_POST['jamb_score'] ?? 0),
            'waec_year' => (int)($_POST['waec_year'] ?? 0),
            // WAEC subjects and grades
            'waec_english' => $_POST['waec_english'] ?? '',
            'waec_mathematics' => $_POST['waec_mathematics'] ?? '',
            'waec_subject3' => Validator::sanitizeInput($_POST['waec_subject3'] ?? ''),
            'waec_grade3' => $_POST['waec_grade3'] ?? '',
            'waec_subject4' => Validator::sanitizeInput($_POST['waec_subject4'] ?? ''),
            'waec_grade4' => $_POST['waec_grade4'] ?? '',
            'waec_subject5' => Validator::sanitizeInput($_POST['waec_subject5'] ?? ''),
            'waec_grade5' => $_POST['waec_grade5'] ?? '',
            'waec_subject6' => Validator::sanitizeInput($_POST['waec_subject6'] ?? ''),
            'waec_grade6' => $_POST['waec_grade6'] ?? ''
        ];
        
        // Validate required fields
        $validator = new Validator($data);
        $validator->validate('full_name', 'required|min:3|max:100')
                 ->validate('phone', 'required|phone')
                 ->validate('email', 'required|email')
                 ->validate('faculty_id', 'required|numeric')
                 ->validate('department_id', 'required|numeric')
                 ->validate('address', 'required|min:10')
                 ->validate('state_of_origin', 'required')
                 ->validate('lga', 'required')
                 ->validate('date_of_birth', 'required')
                 ->validate('gender', 'required|in:Male,Female')
                 ->validate('jamb_reg_no', 'required|jamb_reg')
                 ->validate('jamb_score', 'required|numeric')
                 ->validate('waec_year', 'required|numeric')
                 ->validate('waec_english', 'required')
                 ->validate('waec_mathematics', 'required')
                 ->validate('waec_subject3', 'required')
                 ->validate('waec_grade3', 'required')
                 ->validate('waec_subject4', 'required')
                 ->validate('waec_grade4', 'required')
                 ->validate('waec_subject5', 'required')
                 ->validate('waec_grade5', 'required');
        
        if ($data['jamb_score'] < 160 || $data['jamb_score'] > 400) {
            $validator->addError('jamb_score', 'JAMB score must be between 160 and 400');
        }
        
        $currentYear = date('Y');
        if ($data['waec_year'] < ($currentYear - 10) || $data['waec_year'] > $currentYear) {
            $validator->addError('waec_year', 'Invalid WAEC year');
        }
        
        // Validate WAEC grades
        $creditGrades = ['A1', 'B2', 'B3', 'C4', 'C5', 'C6'];
        $englishGrade = $data['waec_english'];
        $mathGrade = $data['waec_mathematics'];
        
        if (!in_array($englishGrade, $creditGrades)) {
            $validator->addError('waec_english', 'English Language must be a credit grade (A1-C6)');
        }
        
        if (!in_array($mathGrade, $creditGrades)) {
            $validator->addError('waec_mathematics', 'Mathematics must be a credit grade (A1-C6)');
        }
        
        // Count total credits (including English and Math)
        $totalCredits = 0;
        if (in_array($englishGrade, $creditGrades)) $totalCredits++;
        if (in_array($mathGrade, $creditGrades)) $totalCredits++;
        if (in_array($data['waec_grade3'], $creditGrades)) $totalCredits++;
        if (in_array($data['waec_grade4'], $creditGrades)) $totalCredits++;
        if (in_array($data['waec_grade5'], $creditGrades)) $totalCredits++;
        if (!empty($data['waec_grade6']) && in_array($data['waec_grade6'], $creditGrades)) $totalCredits++;
        
        if ($totalCredits < 5) {
            $validator->addError('waec_results', 'You need at least 5 credit grades including English and Mathematics');
        }
        
        $department = $this->db->fetch(
            "SELECT * FROM departments WHERE id = ? AND faculty_id = ?",
            [$data['department_id'], $data['faculty_id']]
        );
        
        if (!$department) {
            $validator->addError('department_id', 'Invalid department for selected faculty');
        }
        
        $uploadedDocuments = $this->handleDocumentUploads();
        if (isset($uploadedDocuments['error'])) {
            $validator->addError('documents', $uploadedDocuments['error']);
        }
        
        if ($validator->fails()) {
            Session::flash('error', 'Please correct the errors below and try again.');
            Session::flash('errors', $validator->getErrors());
            Session::flash('old_input', $data);
            $this->redirect('/application');
        }
        
        try {
            $this->db->beginTransaction();
            // Prepare WAEC results for storage
            $waecResults = [
                'year' => $data['waec_year'],
                'subjects' => [
                    'English Language' => $data['waec_english'],
                    'Mathematics' => $data['waec_mathematics'],
                    $data['waec_subject3'] => $data['waec_grade3'],
                    $data['waec_subject4'] => $data['waec_grade4'],
                    $data['waec_subject5'] => $data['waec_grade5']
                ]
            ];
            
            // Add optional 6th subject if provided
            if (!empty($data['waec_subject6']) && !empty($data['waec_grade6'])) {
                $waecResults['subjects'][$data['waec_subject6']] = $data['waec_grade6'];
            }
            
            $applicationData = [
                'user_id' => $userId,
                'jamb_reg_no' => $data['jamb_reg_no'],
                'program' => $department['name'],
                'jamb_score' => $data['jamb_score'],
                'waec_grade' => json_encode($waecResults),
                'documents_path' => json_encode($uploadedDocuments['files'] ?? []),
                'status' => 'pending'
            ];
            
            $applicationId = $this->applicationModel->createApplication($applicationData);
            
            $profileData = [
                'first_name' => explode(' ', $data['full_name'])[0],
                'last_name' => substr($data['full_name'], strpos($data['full_name'], ' ') + 1),
                'phone' => $data['phone'],
                'address' => $data['address'],
                'state_of_origin' => $data['state_of_origin'],
                'lga' => $data['lga'],
                'date_of_birth' => $data['date_of_birth'],
                'gender' => $data['gender'],
                'program' => $department['name']
            ];
            
            $student = $this->studentModel->findBy('user_id', $userId);
            if ($student) {
                $this->studentModel->update($student['id'], $profileData);
            }
            
            $paymentModel = new Payment();
            $paymentModel->createPayment([
                'user_id' => $userId,
                'payment_type' => 'application_fee',
                'amount' => 3000.00,
                'status' => 'pending'
            ]);
            
            $this->db->commit();
            
            // Send application confirmation email
            $user = $this->db->fetch("SELECT * FROM users WHERE id = ?", [$userId]);
            $this->emailService->sendApplicationConfirmationEmail(
                $user['email'],
                $data['full_name'],
                $applicationId,
                $department['name'],
                $data['jamb_reg_no']
            );
            
            Session::flash('success', 'Application submitted successfully! Confirmation email sent. Please proceed to payment.');
            $this->redirect('/application/status');
            
        } catch (Exception $e) {
            $this->db->rollback();
            error_log("Application submission error: " . $e->getMessage());
            Session::flash('error', 'Application submission failed. Please try again.');
            $this->redirect('/application');
        }
    }
    
    public function status() {
        $this->requireAuth();
        
        $userId = Session::getUserId();
        
        $application = $this->db->fetch("
            SELECT a.*, d.name as department_name, f.name as faculty_name,
                   u.email, u.username
            FROM applications a
            LEFT JOIN departments d ON a.program = d.name
            LEFT JOIN faculties f ON d.faculty_id = f.id
            JOIN users u ON a.user_id = u.id
            WHERE a.user_id = ?
            ORDER BY a.submitted_at DESC
            LIMIT 1
        ", [$userId]);
        
        if (!$application) {
            Session::flash('error', 'No application found. Please submit your application first.');
            $this->redirect('/application');
        }
        
        // Get payment status
        $payment = $this->db->fetch(
            "SELECT * FROM payments WHERE user_id = ? AND payment_type = 'application_fee' ORDER BY created_at DESC LIMIT 1",
            [$userId]
        );
        
        $this->view('application/status', compact('application', 'payment') + [
            'title' => 'Application Status - GEOD University'
        ]);
    }
    
    // View specific application (admin use)
    public function viewApplication($params) {
        $this->requireAuth();
        $this->requireRole('admin');
        
        $applicationId = $params['id'] ?? null;
        
        if (!$applicationId) {
            Session::flash('error', 'Invalid application ID.');
            $this->redirect('/admin/applications');
        }
        
        $application = $this->applicationModel->getWithUserDetails($applicationId);
        
        if (!$application) {
            Session::flash('error', 'Application not found.');
            $this->redirect('/admin/applications');
        }
        
        $this->view('admin/application-details', [
            'title' => 'Application Details - GEOD University',
            'application' => $application
        ]);
    }
    
    private function handleDocumentUploads() {
        $uploadedFiles = [];
        $errors = [];
        
        $requiredDocs = [
            'olevel_certificate' => 'O-Level Certificate (WAEC/NECO)',
            'jamb_result' => 'JAMB Result Slip',
            'birth_certificate' => 'Birth Certificate',
            'passport_photo' => 'Passport Photograph'
        ];
        
        foreach ($requiredDocs as $key => $label) {
            if (isset($_FILES[$key]) && $_FILES[$key]['error'] === UPLOAD_ERR_OK) {
                // Validate file
                $validationErrors = Validator::validateFile(
                    $_FILES[$key],
                    ['pdf', 'jpg', 'jpeg', 'png'],
                    5242880 // 5MB
                );
                
                if (!empty($validationErrors)) {
                    $errors[] = "$label: " . implode(', ', $validationErrors);
                    continue;
                }
                
                // Upload file
                $uploadPath = $this->upload($_FILES[$key], 'uploads/applications');
                if ($uploadPath) {
                    $uploadedFiles[$key] = $uploadPath;
                } else {
                    $errors[] = "Failed to upload $label";
                }
            } else {
                $errors[] = "$label is required";
            }
        }
        
        if (!empty($errors)) {
            return ['error' => implode(', ', $errors)];
        }
        
        return ['files' => $uploadedFiles];
    }
    
    // Send application confirmation email
    private function sendApplicationConfirmationEmail($userId, $applicationId) {
        try {
            $user = $this->db->fetch("SELECT * FROM users WHERE id = ?", [$userId]);
            $application = $this->db->fetch("SELECT * FROM applications WHERE id = ?", [$applicationId]);
            
            $subject = "Application Confirmation - GEOD University";
            $message = "
                <h2>Application Received Successfully</h2>
                <p>Dear {$user['username']},</p>
                <p>Thank you for submitting your application to GEOD University.</p>
                <p><strong>Application Details:</strong></p>
                <ul>
                    <li>Application ID: GU-APP-{$applicationId}</li>
                    <li>Program: {$application['program']}</li>
                    <li>JAMB Registration: {$application['jamb_reg_no']}</li>
                    <li>Status: Under Review</li>
                </ul>
                <p>Please complete your application fee payment to proceed with the admission process.</p>
                <p>You can check your application status anytime by logging into your portal.</p>
                <p>Best regards,<br>GEOD University Admissions Office</p>
            ";
            
            // Send email using mail service
            $this->sendEmail($user['email'], $subject, $message);
            
        } catch (Exception $e) {
            error_log("Email sending failed: " . $e->getMessage());
            // Don't fail the application process if email fails
        }
    }
    
    // Get departments for a faculty (AJAX endpoint)
    public function getDepartments($params) {
        $facultyId = $params['faculty_id'] ?? null;
        
        if (!$facultyId || !is_numeric($facultyId)) {
            $this->json(['error' => 'Invalid faculty ID'], 400);
        }
        
        try {
            $departments = $this->db->fetchAll(
                "SELECT * FROM departments WHERE faculty_id = ? ORDER BY name",
                [$facultyId]
            );
            
            $this->json(['departments' => $departments]);
        } catch (Exception $e) {
            error_log("Error fetching departments: " . $e->getMessage());
            $this->json(['error' => 'Failed to fetch departments'], 500);
        }
    }
    
    // Get LGAs for a state (AJAX endpoint)
    public function getLGAs($params) {
        $stateId = $params['state_id'] ?? null;
        
        if (!$stateId || !is_numeric($stateId)) {
            $this->json(['error' => 'Invalid state ID'], 400);
        }
        
        try {
            $lgas = $this->db->fetchAll(
                "SELECT * FROM nigerian_lgas WHERE state_id = ? ORDER BY name",
                [$stateId]
            );
            
            $this->json(['lgas' => $lgas]);
        } catch (Exception $e) {
            error_log("Error fetching LGAs: " . $e->getMessage());
            $this->json(['error' => 'Failed to fetch LGAs'], 500);
        }
    }
    
    // Send email helper (to be moved to Email service later)
    private function sendEmail($to, $subject, $message) {
        // Real email implementation using PHPMailer or similar
        // For now, store in a queue or send immediately
        
        $headers = [
            'From: GEOD University <noreply@geod.edu.ng>',
            'Reply-To: admissions@geod.edu.ng',
            'Content-Type: text/html; charset=UTF-8',
            'MIME-Version: 1.0'
        ];
        
        // Log email for debugging
        error_log("Email sent to: $to, Subject: $subject");
        
        // In production, integrate with email service like:
        // - SendGrid
        // - Mailgun  
        // - Amazon SES
        // - Local SMTP server
        
        return mail($to, $subject, $message, implode("\r\n", $headers));
    }
}