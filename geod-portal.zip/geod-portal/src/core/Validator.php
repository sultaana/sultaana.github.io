<?php
class Validator {
    private $errors = [];
    private $data = [];
    
    public function __construct($data = []) {
        $this->data = $data;
    }
    
    public function validate($field, $rules) {
        $value = $this->data[$field] ?? '';
        $rules = explode('|', $rules);
        
        foreach ($rules as $rule) {
            $this->applyRule($field, $value, $rule);
        }
        
        return $this;
    }
    
    private function applyRule($field, $value, $rule) {
        if (strpos($rule, ':') !== false) {
            [$rule, $parameter] = explode(':', $rule, 2);
        }
        
        switch ($rule) {
            case 'required':
                if (empty($value)) {
                    $this->addError($field, ucfirst($field) . ' is required');
                }
                break;
                
            case 'email':
                if (!empty($value) && !filter_var($value, FILTER_VALIDATE_EMAIL)) {
                    $this->addError($field, 'Please enter a valid email address');
                }
                break;
                
            case 'min':
                if (!empty($value) && strlen($value) < $parameter) {
                    $this->addError($field, ucfirst($field) . " must be at least $parameter characters");
                }
                break;
                
            case 'max':
                if (!empty($value) && strlen($value) > $parameter) {
                    $this->addError($field, ucfirst($field) . " must not exceed $parameter characters");
                }
                break;
                
            case 'numeric':
                if (!empty($value) && !is_numeric($value)) {
                    $this->addError($field, ucfirst($field) . ' must be a number');
                }
                break;
                
            case 'alpha':
                if (!empty($value) && !preg_match('/^[a-zA-Z]+$/', $value)) {
                    $this->addError($field, ucfirst($field) . ' must contain only letters');
                }
                break;
                
            case 'alpha_num':
                if (!empty($value) && !preg_match('/^[a-zA-Z0-9]+$/', $value)) {
                    $this->addError($field, ucfirst($field) . ' must contain only letters and numbers');
                }
                break;
                
            case 'phone':
                if (!empty($value) && !preg_match('/^[0-9]{11}$/', $value)) {
                    $this->addError($field, 'Please enter a valid 11-digit phone number');
                }
                break;
                
            case 'jamb_reg':
                if (!empty($value) && !preg_match('/^[0-9]{10}[A-Z]{2}$/', $value)) {
                    $this->addError($field, 'Please enter a valid JAMB registration number (format: 1234567890AB)');
                }
                break;
                
            case 'student_id':
                if (!empty($value) && !preg_match('/^[A-Z]{3}\/[0-9]{4}\/[0-9]{3}$/', $value)) {
                    $this->addError($field, 'Please enter a valid student ID format (e.g., CSC/2024/001)');
                }
                break;
                
            case 'unique':
                if (!empty($value)) {
                    [$table, $column] = explode(',', $parameter);
                    $db = Database::getInstance();
                    $exists = $db->fetch("SELECT id FROM $table WHERE $column = ?", [$value]);
                    if ($exists) {
                        $this->addError($field, ucfirst($field) . ' already exists');
                    }
                }
                break;
                
            case 'confirmed':
                $confirmField = $field . '_confirmation';
                if ($value !== ($this->data[$confirmField] ?? '')) {
                    $this->addError($field, ucfirst($field) . ' confirmation does not match');
                }
                break;
                
            case 'in':
                if (!empty($value)) {
                    $options = explode(',', $parameter);
                    if (!in_array($value, $options)) {
                        $this->addError($field, ucfirst($field) . ' must be one of: ' . implode(', ', $options));
                    }
                }
                break;
        }
    }
    
    public function addError($field, $message) {
        $this->errors[$field][] = $message;
    }
    
    public function passes() {
        return empty($this->errors);
    }
    
    public function fails() {
        return !$this->passes();
    }
    
    public function getErrors() {
        return $this->errors;
    }
    
    public function getFirstError($field) {
        return $this->errors[$field][0] ?? '';
    }
    
    public function getAllErrors() {
        $allErrors = [];
        foreach ($this->errors as $fieldErrors) {
            $allErrors = array_merge($allErrors, $fieldErrors);
        }
        return $allErrors;
    }
    
    // Static methods for common validations
    public static function sanitizeInput($input) {
        return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
    }
    
    public static function validateFile($file, $allowedTypes = ['pdf', 'jpg', 'jpeg', 'png'], $maxSize = 5242880) {
        $errors = [];
        
        if ($file['error'] !== UPLOAD_ERR_OK) {
            $errors[] = 'File upload failed';
            return $errors;
        }
        
        // Check file size
        if ($file['size'] > $maxSize) {
            $errors[] = 'File size must not exceed ' . round($maxSize / 1024 / 1024) . 'MB';
        }
        
        // Check file type
        $fileExtension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if (!in_array($fileExtension, $allowedTypes)) {
            $errors[] = 'File type must be: ' . implode(', ', $allowedTypes);
        }
        
        // Check MIME type for additional security
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mimeType = finfo_file($finfo, $file['tmp_name']);
        finfo_close($finfo);
        
        $allowedMimes = [
            'pdf' => 'application/pdf',
            'jpg' => 'image/jpeg',
            'jpeg' => 'image/jpeg',
            'png' => 'image/png',
            'doc' => 'application/msword',
            'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
        ];
        
        if (isset($allowedMimes[$fileExtension]) && $mimeType !== $allowedMimes[$fileExtension]) {
            $errors[] = 'Invalid file type';
        }
        
        return $errors;
    }
    
    public static function hashPassword($password) {
        return password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
    }
    
    public static function verifyPassword($password, $hash) {
        return password_verify($password, $hash);
    }
    
    public static function generateSecureToken($length = 32) {
        return bin2hex(random_bytes($length));
    }
}