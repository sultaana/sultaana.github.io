<?php
abstract class Controller {
    protected $db;
    
    public function __construct() {
        $this->db = Database::getInstance();
        Session::start();
    }
    
    protected function view($view, $data = []) {
        extract($data);
        
        // output buffering for the view
        ob_start();
        include __DIR__ . "/../views/$view.php";
        $content = ob_get_clean();
        
        include __DIR__ . "/../views/layouts/header.php";
        echo $content;
        include __DIR__ . "/../views/layouts/footer.php";
    }
    
    protected function json($data, $status = 200) {
        http_response_code($status);
        header('Content-Type: application/json');
        echo json_encode($data);
        exit;
    }
    
    protected function redirect($url, $message = null, $type = 'info') {
        if ($message) {
            Session::flash($type, $message);
        }
        header("Location: $url");
        exit;
    }
    
    protected function back($message = null, $type = 'error') {
        $referer = $_SERVER['HTTP_REFERER'] ?? '/';
        $this->redirect($referer, $message, $type);
    }
    
    protected function requireAuth() {
        Session::requireAuth();
    }
    
    protected function requireRole($role) {
        Session::requireRole($role);
    }
    
    protected function validateCSRF() {
        $token = $_POST['csrf_token'] ?? '';
        if (!CSRF::validateToken($token)) {
            $this->json(['error' => 'Invalid CSRF token'], 403);
        }
    }
    
    protected function validateCSRFForm() {
        $token = $_POST['csrf_token'] ?? '';
        if (!CSRF::validateFormToken($token)) {
            Session::flash('error', 'CSRF token validation failed. Please try again.');
            $this->back();
        }
    }
    
    protected function upload($file, $directory = 'uploads') {
        $uploadDir = __DIR__ . "/../storage/$directory/";
        
        // Create directory if it doesn't exist
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }
        
        // Generate unique filename
        $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
        $filename = uniqid() . '_' . time() . '.' . $extension;
        $filePath = $uploadDir . $filename;
        
        if (move_uploaded_file($file['tmp_name'], $filePath)) {
            return "$directory/$filename";
        }
        
        return false;
    }
}
