<?php

class CSRF {
    private static $tokenName = 'csrf_token';
    
    public static function generateToken() {
        Session::start();
        $token = bin2hex(random_bytes(32));
        Session::set(self::$tokenName, $token);
        
        // Store in database only for logged-in users (extra security layer)
        if (Session::isLoggedIn()) {
            try {
                $db = Database::getInstance();
                // Clean up old tokens first
                $db->delete('csrf_tokens', 'user_id = ?', [Session::getUserId()]);
                // Insert new token
                $db->query(
                    "INSERT INTO csrf_tokens (token, user_id, expires_at) VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 1 HOUR))",
                    [$token, Session::getUserId()]
                );
            } catch (Exception $e) {
                error_log("CSRF token database storage failed: " . $e->getMessage());
                // Continue with session-only protection
            }
        }
        
        return $token;
    }
    
    public static function getToken() {
        Session::start();
        if (!Session::has(self::$tokenName)) {
            return self::generateToken();
        }
        return Session::get(self::$tokenName);
    }
    
    public static function validateToken($token) {
        Session::start();
        
        if (!$token) {
            return false;
        }
        
        $sessionToken = Session::get(self::$tokenName);
        if (!$sessionToken) {
            return false;
        }
        
        // Simple session-based validation - more reliable
        return hash_equals($sessionToken, $token);
    }
    
    public static function validateFormToken($token) {
        Session::start();
        
        if (!$token) {
            error_log("CSRF validation failed: No token provided");
            return false;
        }
        
        $sessionToken = Session::get(self::$tokenName);
        if (!$sessionToken) {
            error_log("CSRF validation failed: No session token found. Generating new token.");
            // Generate a new token if none exists
            self::getToken();
            $sessionToken = Session::get(self::$tokenName);
        }
        
        $isValid = hash_equals($sessionToken, $token);
        error_log("CSRF validation: Session token exists: " . ($sessionToken ? 'yes' : 'no') . ", Form token: " . substr($token, 0, 8) . "..., Valid: " . ($isValid ? 'yes' : 'no'));
        
        if (!$isValid) {
            error_log("CSRF validation failed: Token mismatch. Session: " . substr($sessionToken, 0, 8) . "... Form: " . substr($token, 0, 8) . "...");
        }
        
        return $isValid;
    }
    
    public static function getTokenField() {
        return '<input type="hidden" name="csrf_token" value="' . htmlspecialchars(self::getToken()) . '">';
    }
    
    public static function cleanExpiredTokens() {
        try {
            $db = Database::getInstance();
            $db->delete('csrf_tokens', 'expires_at < NOW()');
        } catch (Exception $e) {
            error_log("CSRF token cleanup failed: " . $e->getMessage());
        }
    }
}