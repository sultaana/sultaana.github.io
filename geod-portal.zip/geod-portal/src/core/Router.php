<?php
class Router {
    private $routes = [];
    private $middlewares = [];
    
    public function get($path, $handler, $middleware = []) {
        $this->addRoute('GET', $path, $handler, $middleware);
    }
    
    public function post($path, $handler, $middleware = []) {
        $this->addRoute('POST', $path, $handler, $middleware);
    }
    
    public function put($path, $handler, $middleware = []) {
        $this->addRoute('PUT', $path, $handler, $middleware);
    }
    
    public function delete($path, $handler, $middleware = []) {
        $this->addRoute('DELETE', $path, $handler, $middleware);
    }
    
    private function addRoute($method, $path, $handler, $middleware) {
        $this->routes[] = [
            'method' => $method,
            'path' => $path,
            'handler' => $handler,
            'middleware' => $middleware
        ];
    }
    
    public function run() {
        $method = $_SERVER['REQUEST_METHOD'];
        $path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
        
        // Remove trailing slash except for root
        if (strlen($path) > 1) {
            $path = rtrim($path, '/');
        }
        
        foreach ($this->routes as $route) {
            if ($route['method'] === $method && $this->matchPath($route['path'], $path, $params)) {
                // Run middleware
                foreach ($route['middleware'] as $middleware) {
                    $this->runMiddleware($middleware);
                }
                
                // Run handler
                $this->runHandler($route['handler'], $params);
                return;
            }
        }
        http_response_code(404);
        include __DIR__ . '/../views/errors/404.php';
    }
    
    private function matchPath($routePath, $requestPath, &$params) {
        $params = [];
        
        // Convert route path to regex pattern
        $pattern = preg_replace('/\{([^}]+)\}/', '([^/]+)', $routePath);
        $pattern = '#^' . $pattern . '$#';
        
        if (preg_match($pattern, $requestPath, $matches)) {
            // Extract parameter names
            preg_match_all('/\{([^}]+)\}/', $routePath, $paramNames);
            
            // Map parameter values
            for ($i = 1; $i < count($matches); $i++) {
                $paramName = $paramNames[1][$i - 1];
                $params[$paramName] = $matches[$i];
            }
            
            return true;
        }
        
        return false;
    }
    
    private function runMiddleware($middleware) {
        if (is_string($middleware)) {
            switch ($middleware) {
                case 'auth':
                    error_log("Running auth middleware - isLoggedIn: " . (Session::isLoggedIn() ? 'true' : 'false'));
                    if (!Session::isLoggedIn()) {
                        error_log("User not logged in, redirecting...");
                        header('Location: /auth/login');
                        exit;
                    }
                    error_log("Auth middleware passed");
                    break;
                case 'guest':
                    if (Session::isLoggedIn()) {
                        header('Location: /dashboard');
                        exit;
                    }
                    break;
                case 'admin':
                    Session::requireRole('admin');
                    break;
                case 'faculty':
                    Session::requireRole('faculty');
                    break;
                case 'student':
                    Session::requireRole('student');
                    break;
                case 'csrf':
                    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                        $token = $_POST['csrf_token'] ?? '';
                        if (!CSRF::validateToken($token)) {
                            http_response_code(403);
                            die('CSRF token validation failed');
                        }
                    }
                    break;
            }
        } elseif (is_callable($middleware)) {
            $middleware();
        }
    }
    
    private function runHandler($handler, $params) {
        if (is_string($handler)) {
            [$controllerName, $method] = explode('@', $handler);
            
            // Check if class already exists (loaded via config)
            if (!class_exists($controllerName)) {
                // Include controller file if not already loaded
                $controllerFile = __DIR__ . "/../controllers/$controllerName.php";
                if (!file_exists($controllerFile)) {
                    throw new Exception("Controller file not found: $controllerFile");
                }
                require_once $controllerFile;
            }
            
            if (!class_exists($controllerName)) {
                throw new Exception("Controller class not found: $controllerName");
            }
            
            $controller = new $controllerName();
            
            if (!method_exists($controller, $method)) {
                throw new Exception("Method not found: $controllerName::$method");
            }
            
            $controller->$method($params);
        } elseif (is_callable($handler)) {
            $handler($params);
        }
    }
}