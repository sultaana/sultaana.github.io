<?php
abstract class Model {
    protected $db;
    protected $table;
    protected $primaryKey = 'id';
    protected $fillable = [];
    protected $hidden = ['password_hash'];
    
    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    public function find($id) {
        $sql = "SELECT * FROM {$this->table} WHERE {$this->primaryKey} = ?";
        return $this->db->fetch($sql, [$id]);
    }
    
    public function findBy($field, $value) {
        $sql = "SELECT * FROM {$this->table} WHERE $field = ?";
        return $this->db->fetch($sql, [$value]);
    }
    
    public function all($orderBy = null) {
        $sql = "SELECT * FROM {$this->table}";
        if ($orderBy) {
            $sql .= " ORDER BY $orderBy";
        }
        return $this->db->fetchAll($sql);
    }
    
    public function where($conditions, $params = []) {
        $sql = "SELECT * FROM {$this->table} WHERE $conditions";
        return $this->db->fetchAll($sql, $params);
    }
    
    public function create($data) {
        $filteredData = $this->filterFillable($data);
        return $this->db->insert($this->table, $filteredData);
    }
    
    public function update($id, $data) {
        $filteredData = $this->filterFillable($data);
        return $this->db->update(
            $this->table, 
            $filteredData, 
            "{$this->primaryKey} = :id", 
            [':id' => $id]
        );
    }
    
    public function delete($id) {
        return $this->db->delete($this->table, "{$this->primaryKey} = ?", [$id]);
    }
    
    public function count($conditions = '', $params = []) {
        $sql = "SELECT COUNT(*) as count FROM {$this->table}";
        if ($conditions) {
            $sql .= " WHERE $conditions";
        }
        $result = $this->db->fetch($sql, $params);
        return (int) $result['count'];
    }
    
    public function paginate($page = 1, $perPage = 10, $conditions = '', $params = []) {
        $offset = ($page - 1) * $perPage;
        
        $sql = "SELECT * FROM {$this->table}";
        if ($conditions) {
            $sql .= " WHERE $conditions";
        }
        $sql .= " LIMIT $perPage OFFSET $offset";
        
        $data = $this->db->fetchAll($sql, $params);
        $total = $this->count($conditions, $params);
        $totalPages = ceil($total / $perPage);
        
        return [
            'data' => $data,
            'pagination' => [
                'current_page' => $page,
                'per_page' => $perPage,
                'total' => $total,
                'total_pages' => $totalPages,
                'has_next' => $page < $totalPages,
                'has_prev' => $page > 1
            ]
        ];
    }
    
    protected function filterFillable($data) {
        if (empty($this->fillable)) {
            return $data;
        }
        
        return array_intersect_key($data, array_flip($this->fillable));
    }
    
    protected function hideFields($data) {
        if (is_array($data) && isset($data[0])) {
            // Multiple records
            return array_map([$this, 'hideFields'], $data);
        }
        
        // Single record
        foreach ($this->hidden as $field) {
            unset($data[$field]);
        }
        
        return $data;
    }
}
