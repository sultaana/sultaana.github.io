<?php
class Session {
    private static $started = false;
    
    public static function start() {
        if (!self::$started) {
            session_start();
            self::$started = true;
            
            // regenerate session ID periodically for security
            if (!isset($_SESSION['created'])) {
                $_SESSION['created'] = time();
            } elseif (time() - $_SESSION['created'] > 1800) {
                session_regenerate_id(true);
                $_SESSION['created'] = time();
            }
        }
    }
    
    public static function set($key, $value) {
        self::start();
        $_SESSION[$key] = $value;
    }
    
    public static function get($key, $default = null) {
        self::start();
        return $_SESSION[$key] ?? $default;
    }
    
    public static function has($key) {
        self::start();
        return isset($_SESSION[$key]);
    }
    
    public static function remove($key) {
        self::start();
        unset($_SESSION[$key]);
    }
    
    public static function destroy() {
        self::start();
        session_destroy();
        self::$started = false;
    }
    
    public static function flash($key, $value = null) {
        if ($value === null) {
            $message = self::get("flash_$key");
            self::remove("flash_$key");
            return $message;
        }
        self::set("flash_$key", $value);
    }
    
    public static function isLoggedIn() {
        return self::has('user_id') && self::has('user_role');
    }
    
    public static function getUserId() {
        return self::get('user_id');
    }
    
    public static function getUserRole() {
        return self::get('user_role');
    }
    
    public static function requireAuth() {
        if (!self::isLoggedIn()) {
            error_log("Redirecting to login - headers sent: " . (headers_sent() ? 'true' : 'false'));
            header('Location: /auth/login');
            exit;
        }
    }
    
    public static function requireRole($role) {
        self::requireAuth();
        if (self::getUserRole() !== $role) {
            header('HTTP/1.1 403 Forbidden');
            die('Access denied');
        }
    }
}
