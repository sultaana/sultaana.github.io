<?php
require_once 'config/app.php';

Session::start();

$router = new Router();
$router->get('/', 'HomeController@index');
$router->get('/about', 'HomeController@about');
$router->get('/contact', 'HomeController@contact');
$router->get('/admission-requirements', 'HomeController@admissionRequirements');

$router->get('/auth/login', 'AuthController@showLogin', ['guest']);
$router->post('/auth/login', 'AuthController@login', ['guest', 'csrf']);
$router->get('/auth/register', 'AuthController@showRegister', ['guest']);
$router->post('/auth/register', 'AuthController@register', ['guest', 'csrf']);
$router->get('/auth/logout', 'AuthController@logout', ['auth']);
$router->get('/auth/forgot-password', 'AuthController@showForgotPassword', ['guest']);
$router->post('/auth/forgot-password', 'AuthController@forgotPassword', ['guest', 'csrf']);
$router->get('/auth/reset-password', 'AuthController@showResetPassword', ['guest']);
$router->post('/auth/reset-password', 'AuthController@resetPassword', ['guest', 'csrf']);

$router->get('/dashboard', 'DashboardController@index', ['auth']);

$router->get('/application', 'ApplicationController@showForm', ['auth']);
$router->post('/application', 'ApplicationController@submit', ['auth', 'csrf']);
$router->get('/application/status', 'ApplicationController@status', ['auth']);
$router->get('/application/{id}', 'ApplicationController@view', ['auth']);

$router->get('/courses', 'StudentController@courses', ['auth', 'student']);
$router->get('/courses/{id}', 'StudentController@courseDetails', ['auth', 'student']);
$router->post('/student/enroll/{id}', 'StudentController@enrollCourse', ['auth', 'student', 'csrf']);
$router->get('/student/my-courses', 'StudentController@myCourses', ['auth', 'student']);
$router->get('/student/grades', 'StudentController@grades', ['auth', 'student']);
$router->get('/student/transcript', 'StudentController@transcript', ['auth', 'student']);

$router->get('/payments', 'PaymentController@index', ['auth']);
$router->get('/payments/fees', 'PaymentController@fees', ['auth']);
$router->post('/payments/initiate', 'PaymentController@initiate', ['auth', 'csrf']);
$router->get('/payments/verify/{reference}', 'PaymentController@verify', ['auth']);
$router->post('/payments/check-status/{reference}', 'PaymentController@checkStatus', ['auth']);
$router->get('/payments/receipt/{id}', 'PaymentController@receipt', ['auth']);

$router->get('/faculty', 'FacultyController@dashboard', ['auth', 'faculty']);
$router->get('/faculty/dashboard', 'FacultyController@dashboard', ['auth', 'faculty']);
$router->get('/faculty/courses', 'FacultyController@courses', ['auth', 'faculty']);
$router->get('/faculty/courses/{id}', 'FacultyController@courseDetails', ['auth', 'faculty']);
$router->get('/faculty/courses/{id}/students', 'FacultyController@courseStudents', ['auth', 'faculty']);
$router->post('/faculty/courses/{id}/grades', 'FacultyController@submitGrades', ['auth', 'faculty', 'csrf']);
$router->get('/faculty/students', 'FacultyController@students', ['auth', 'faculty']);
$router->get('/admin', 'AdminController@dashboard', ['auth', 'admin']);
$router->get('/admin/dashboard', 'AdminController@dashboard', ['auth', 'admin']);
$router->get('/admin/applications', 'AdminController@applications', ['auth', 'admin']);
$router->get('/admin/applications/{id}', 'AdminController@applicationDetails', ['auth', 'admin']);
$router->post('/admin/applications/{id}/approve', 'AdminController@approveApplication', ['auth', 'admin', 'csrf']);
$router->post('/admin/applications/{id}/reject', 'AdminController@rejectApplication', ['auth', 'admin', 'csrf']);
$router->get('/admin/students', 'AdminController@students', ['auth', 'admin']);
$router->get('/admin/faculty', 'AdminController@faculty', ['auth', 'admin']);
$router->get('/admin/courses', 'AdminController@courses', ['auth', 'admin']);
$router->get('/admin/payments', 'AdminController@payments', ['auth', 'admin']);
$router->get('/admin/reports', 'AdminController@reports', ['auth', 'admin']);

$router->get('/api/states', 'ApiController@states');
$router->get('/api/lgas/{state_id}', 'ApiController@lgas');
$router->get('/api/departments/{faculty_id}', 'ApplicationController@getDepartments');
$router->get('/api/application/departments/{faculty_id}', 'ApplicationController@getDepartments');
$router->get('/api/application/lgas/{state_id}', 'ApplicationController@getLGAs');
$router->get('/api/programs', 'ApiController@programs');

$router->get('/messages', 'MessageController@index', ['auth']);
$router->get('/messages/compose', 'MessageController@compose', ['auth']);
$router->post('/messages/send', 'MessageController@send', ['auth', 'csrf']);
$router->get('/messages/{id}', 'MessageController@viewMessage', ['auth']);
$router->get('/messages/{id}/reply', 'MessageController@reply', ['auth']);
$router->post('/messages/reply', 'MessageController@sendReply', ['auth', 'csrf']);
$router->post('/messages/{id}/delete', 'MessageController@delete', ['auth', 'csrf']);
$router->get('/messages/announcement', 'MessageController@announcement', ['auth', 'admin']);
$router->post('/messages/announcement', 'MessageController@announcement', ['auth', 'admin', 'csrf']);
$router->get('/messages/unread-count', 'MessageController@unreadCount', ['auth']);
$router->post('/messages/{id}/mark-read', 'MessageController@markRead', ['auth']);
$router->get('/messages/search', 'MessageController@search', ['auth']);

$router->get('/download/{type}/{file}', 'FileController@download', ['auth']);
try {
    $router->run();
} catch (Exception $e) {
    error_log("Application error: " . $e->getMessage());
    http_response_code(500);
    include __DIR__ . '/views/errors/500.php';
}