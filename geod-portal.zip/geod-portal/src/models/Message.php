<?php
class Message extends Model {
    protected $table = 'messages';
    protected $fillable = [
        'sender_id', 'receiver_id', 'subject', 'message', 'message_type'
    ];
    
    public function sendMessage($senderId, $receiverId, $subject, $message, $type = 'personal') {
        return $this->create([
            'sender_id' => $senderId,
            'receiver_id' => $receiverId,
            'subject' => $subject,
            'message' => $message,
            'message_type' => $type
        ]);
    }
    
    public function getUserMessages($userId, $type = null) {
        $conditions = 'receiver_id = ?';
        $params = [$userId];
        
        if ($type) {
            $conditions .= ' AND message_type = ?';
            $params[] = $type;
        }
        
        $sql = "SELECT m.*, u.username as sender_name
                FROM messages m
                JOIN users u ON m.sender_id = u.id
                WHERE $conditions
                ORDER BY m.created_at DESC";
        
        return $this->db->fetchAll($sql, $params);
    }
    
    public function getConversation($userId1, $userId2) {
        $sql = "SELECT m.*, u.username as sender_name
                FROM messages m
                JOIN users u ON m.sender_id = u.id
                WHERE (m.sender_id = ? AND m.receiver_id = ?) 
                   OR (m.sender_id = ? AND m.receiver_id = ?)
                ORDER BY m.created_at ASC";
        
        return $this->db->fetchAll($sql, [$userId1, $userId2, $userId2, $userId1]);
    }
    
    public function markAsRead($messageId, $userId) {
        return $this->db->update('messages', 
            ['read_status' => true], 
            'id = ? AND receiver_id = ?', 
            [':id' => $messageId, ':receiver_id' => $userId]
        );
    }
    
    public function getUnreadCount($userId) {
        $sql = "SELECT COUNT(*) as count FROM messages 
                WHERE receiver_id = ? AND read_status = FALSE";
        $result = $this->db->fetch($sql, [$userId]);
        return $result['count'];
    }
    
    public function sendAnnouncement($senderId, $receiverIds, $subject, $message) {
        $this->db->beginTransaction();
        try {
            foreach ($receiverIds as $receiverId) {
                $this->create([
                    'sender_id' => $senderId,
                    'receiver_id' => $receiverId,
                    'subject' => $subject,
                    'message' => $message,
                    'message_type' => 'announcement'
                ]);
            }
            $this->db->commit();
            return true;
        } catch (Exception $e) {
            $this->db->rollback();
            throw $e;
        }
    }
    
    public function deleteMessage($messageId, $userId) {
        // Only allow deletion if user is sender or receiver
        return $this->db->delete('messages', 
            'id = ? AND (sender_id = ? OR receiver_id = ?)', 
            [$messageId, $userId, $userId]
        );
    }
}