<?php

class Payment extends Model {
    protected $table = 'payments';
    protected $fillable = [
        'user_id', 'payment_type', 'amount', 'status', 'reference',
        'payment_method', 'gateway_response', 'paid_at'
    ];
    
    public function generateReference() {
        return 'PAY-' . strtoupper(uniqid()) . '-' . time();
    }
    
    public function createPayment($data) {
        $data['reference'] = $this->generateReference();
        return $this->create($data);
    }
    
    public function getByUser($userId) {
        return $this->where('user_id = ?', [$userId]);
    }
    
    public function getByStatus($status) {
        return $this->where('status = ?', [$status]);
    }
    
    public function getByReference($reference) {
        return $this->findBy('reference', $reference);
    }
    
    public function markAsPaid($paymentId, $paymentMethod = null, $gatewayResponse = null) {
        return $this->update($paymentId, [
            'status' => 'completed',
            'payment_method' => $paymentMethod,
            'gateway_response' => $gatewayResponse,
            'paid_at' => date('Y-m-d H:i:s')
        ]);
    }
    
    public function markAsFailed($paymentId, $gatewayResponse = null) {
        return $this->update($paymentId, [
            'status' => 'failed',
            'gateway_response' => $gatewayResponse
        ]);
    }
    
    public function getUserPaymentHistory($userId) {
        $sql = "SELECT * FROM payments WHERE user_id = ? ORDER BY created_at DESC";
        return $this->db->fetchAll($sql, [$userId]);
    }
    
    public function getOutstandingBalance($userId) {
        $sql = "SELECT SUM(amount) as total FROM payments 
                WHERE user_id = ? AND status = 'pending'";
        $result = $this->db->fetch($sql, [$userId]);
        return $result['total'] ?? 0;
    }
    
    public function getPaymentStats($startDate = null, $endDate = null) {
        $conditions = "1=1";
        $params = [];
        
        if ($startDate) {
            $conditions .= " AND created_at >= ?";
            $params[] = $startDate;
        }
        
        if ($endDate) {
            $conditions .= " AND created_at <= ?";
            $params[] = $endDate;
        }
        
        $sql = "SELECT 
                    payment_type,
                    status,
                    COUNT(*) as count,
                    SUM(amount) as total
                FROM payments 
                WHERE $conditions
                GROUP BY payment_type, status";
        
        return $this->db->fetchAll($sql, $params);
    }
    
    public function getTotalRevenue($startDate = null, $endDate = null) {
        $conditions = "status = 'completed'";
        $params = [];
        
        if ($startDate) {
            $conditions .= " AND paid_at >= ?";
            $params[] = $startDate;
        }
        
        if ($endDate) {
            $conditions .= " AND paid_at <= ?";
            $params[] = $endDate;
        }
        
        $sql = "SELECT SUM(amount) as total FROM payments WHERE $conditions";
        $result = $this->db->fetch($sql, $params);
        return $result['total'] ?? 0;
    }
}
