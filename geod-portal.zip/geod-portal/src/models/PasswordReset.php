<?php

class PasswordReset extends Model {
    protected $table = 'password_reset_tokens';
    protected $fillable = ['email', 'token', 'expires_at'];
    
    public function createResetToken($email) {
        $token = bin2hex(random_bytes(32));
        $expiresAt = date('Y-m-d H:i:s', strtotime('+1 hour'));
        
        $this->db->delete($this->table, 'email = ?', [$email]);
        $this->create([
            'email' => $email,
            'token' => $token,
            'expires_at' => $expiresAt
        ]);
        
        return $token;
    }
    
    public function validateToken($token) {
        $resetRecord = $this->db->fetch(
            "SELECT * FROM {$this->table} WHERE token = ? AND expires_at > NOW() AND used = FALSE",
            [$token]
        );
        
        return $resetRecord ?: false;
    }
    
    public function markTokenAsUsed($token) {
        return $this->db->update(
            $this->table,
            ['used' => true],
            'token = ?',
            [':token' => $token]
        );
    }
    
    public function cleanExpiredTokens() {
        return $this->db->delete($this->table, 'expires_at < NOW() OR used = TRUE');
    }
}