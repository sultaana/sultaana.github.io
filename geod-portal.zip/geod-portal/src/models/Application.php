<?php

class Application extends Model {
    protected $table = 'applications';
    protected $fillable = [
        'user_id', 'jamb_reg_no', 'program', 'status', 'documents_path',
        'jamb_score', 'waec_grade', 'post_utme_score', 'aggregate_score',
        'admission_letter_path', 'reviewed_by', 'notes'
    ];
    
    public function createApplication($data) {
        // Calculate aggregate score
        $data['aggregate_score'] = $this->calculateAggregateScore(
            $data['jamb_score'],
            $data['post_utme_score'] ?? 0,
            $data['waec_grade']
        );
        
        return $this->create($data);
    }
    
    public function calculateAggregateScore($jambScore, $postUtmeScore, $waecGrade) {
        
        $jambPercent = ($jambScore / 400) * 50; 
        $postUtmePercent = ($postUtmeScore / 100) * 30; 
        
        // Convert WAEC grades to points
        $waecPoints = $this->convertWaecToPoints($waecGrade);
        $waecPercent = ($waecPoints / 45) * 20; // Max 45 points for 5 subjects
        
        return round($jambPercent + $postUtmePercent + $waecPercent, 2);
    }
    
    private function convertWaecToPoints($waecGrade) {
        $grades = explode('-', $waecGrade);
        $totalPoints = 0;
        
        foreach ($grades as $grade) {
            switch ($grade) {
                case 'A1': $totalPoints += 9; break;
                case 'B2': $totalPoints += 8; break;
                case 'B3': $totalPoints += 7; break;
                case 'C4': $totalPoints += 6; break;
                case 'C5': $totalPoints += 5; break;
                case 'C6': $totalPoints += 4; break;
                case 'D7': $totalPoints += 3; break;
                case 'E8': $totalPoints += 2; break;
                case 'F9': $totalPoints += 1; break;
                default: $totalPoints += 0;
            }
        }
        
        return $totalPoints;
    }
    
    public function getByStatus($status) {
        return $this->where('status = ?', [$status]);
    }
    
    public function getByProgram($program) {
        return $this->where('program = ?', [$program]);
    }
    
    public function getWithUserDetails($applicationId) {
        $sql = "SELECT a.*, u.email, u.username, u.created_at as user_created
                FROM applications a
                JOIN users u ON a.user_id = u.id
                WHERE a.id = ?";
        return $this->db->fetch($sql, [$applicationId]);
    }
    
    public function getPendingApplications() {
        $sql = "SELECT a.*, u.email, u.username
                FROM applications a
                JOIN users u ON a.user_id = u.id
                WHERE a.status = 'pending'
                ORDER BY a.submitted_at ASC";
        return $this->db->fetchAll($sql);
    }
    
    public function approveApplication($applicationId, $reviewerId, $notes = '') {
        $this->db->beginTransaction();
        try {
            $this->update($applicationId, [
                'status' => 'approved',
                'reviewed_by' => $reviewerId,
                'reviewed_at' => date('Y-m-d H:i:s'),
                'notes' => $notes
            ]);
            
            $application = $this->getWithUserDetails($applicationId);
            
            $studentModel = new Student();
            $studentId = $studentModel->createFromApplication($application);
            
            $userModel = new User();
            $userModel->update($application['user_id'], ['role' => 'student']);
            
            $this->db->commit();
            return $studentId;
        } catch (Exception $e) {
            $this->db->rollback();
            throw $e;
        }
    }
    
    public function rejectApplication($applicationId, $reviewerId, $notes = '') {
        return $this->update($applicationId, [
            'status' => 'rejected',
            'reviewed_by' => $reviewerId,
            'reviewed_at' => date('Y-m-d H:i:s'),
            'notes' => $notes
        ]);
    }
    
    public function getApplicationStats() {
        $sql = "SELECT status, COUNT(*) as count FROM applications GROUP BY status";
        $results = $this->db->fetchAll($sql);
        
        $stats = ['pending' => 0, 'approved' => 0, 'rejected' => 0, 'screening' => 0];
        foreach ($results as $result) {
            $stats[$result['status']] = $result['count'];
        }
        
        return $stats;
    }
}
