<?php
class User extends Model {
    protected $table = 'users';
    protected $fillable = [
        'username', 'email', 'password_hash', 'role', 'status', 'email_verified', 'updated_at'
    ];
    protected $hidden = ['password_hash'];
    
    public function createUser($data) {
        if (isset($data['password'])) {
            $data['password_hash'] = Validator::hashPassword($data['password']);
            unset($data['password']);
        }
        
        // Convert boolean to integer for MySQL
        if (isset($data['email_verified'])) {
            $data['email_verified'] = $data['email_verified'] ? 1 : 0;
        }
        
        return $this->create($data);
    }
    
    public function authenticate($email, $password) {
        $user = $this->findBy('email', $email);
        
        if ($user && Validator::verifyPassword($password, $user['password_hash'])) {
            // Update last login
            $this->update($user['id'], ['updated_at' => date('Y-m-d H:i:s')]);
            return $user;
        }
        
        return false;
    }
    
    public function getByRole($role) {
        return $this->where('role = ?', [$role]);
    }
    
    public function getActiveUsers() {
        return $this->where('status = ?', ['active']);
    }
    
    public function getProfile($userId) {
        $sql = "SELECT u.*, s.* FROM users u 
                LEFT JOIN students s ON u.id = s.user_id 
                WHERE u.id = ?";
        return $this->db->fetch($sql, [$userId]);
    }
    
    public function updatePassword($userId, $newPassword) {
        $hashedPassword = Validator::hashPassword($newPassword);
        return $this->update($userId, ['password_hash' => $hashedPassword]);
    }
    
    public function emailExists($email, $excludeId = null) {
        $sql = "SELECT id FROM users WHERE email = ?";
        $params = [$email];
        
        if ($excludeId) {
            $sql .= " AND id != ?";
            $params[] = $excludeId;
        }
        
        return $this->db->fetch($sql, $params) !== false;
    }
    
    public function usernameExists($username, $excludeId = null) {
        $sql = "SELECT id FROM users WHERE username = ?";
        $params = [$username];
        
        if ($excludeId) {
            $sql .= " AND id != ?";
            $params[] = $excludeId;
        }
        
        return $this->db->fetch($sql, $params) !== false;
    }
}