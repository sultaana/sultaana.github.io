<?php

class Student extends Model {
    protected $table = 'students';
    protected $fillable = [
        'user_id', 'student_id', 'first_name', 'last_name', 'middle_name',
        'phone', 'program', 'level', 'state_of_origin', 'lga', 'address',
        'date_of_birth', 'gender', 'admission_year', 'graduation_year'
    ];
    
    public function generateStudentId($program, $year) {
        // generate student id in this format: PROG/YEAR/001
        $programCode = strtoupper(substr($program, 0, 3));
        
        // get next sequencial number 
        $sql = "SELECT COUNT(*) + 1 as next_num FROM students 
                WHERE student_id LIKE ? AND admission_year = ?";
        $result = $this->db->fetch($sql, [$programCode . '/' . $year . '/%', $year]);
        $nextNum = str_pad($result['next_num'], 3, '0', STR_PAD_LEFT);
        
        return $programCode . '/' . $year . '/' . $nextNum;
    }
    
    public function createFromApplication($applicationData) {
        $studentData = [
            'user_id' => $applicationData['user_id'],
            'first_name' => $applicationData['first_name'],
            'last_name' => $applicationData['last_name'],
            'phone' => $applicationData['phone'],
            'program' => $applicationData['program'],
            'level' => '100', // First year
            'state_of_origin' => $applicationData['state_of_origin'],
            'lga' => $applicationData['lga'],
            'address' => $applicationData['address'],
            'date_of_birth' => $applicationData['date_of_birth'],
            'gender' => $applicationData['gender'],
            'admission_year' => date('Y')
        ];
        
        // Generate student ID
        $studentData['student_id'] = $this->generateStudentId($studentData['program'], $studentData['admission_year']);
        
        return $this->create($studentData);
    }
    
    public function getByProgram($program) {
        return $this->where('program = ?', [$program]);
    }
    
    public function getByLevel($level) {
        return $this->where('level = ?', [$level]);
    }
    
    public function getWithUser($studentId) {
        $sql = "SELECT s.*, u.email, u.username, u.status 
                FROM students s 
                JOIN users u ON s.user_id = u.id 
                WHERE s.id = ?";
        return $this->db->fetch($sql, [$studentId]);
    }
    
    public function searchStudents($search) {
        $searchTerm = "%$search%";
        $sql = "SELECT s.*, u.email FROM students s 
                JOIN users u ON s.user_id = u.id 
                WHERE s.student_id LIKE ? OR s.first_name LIKE ? OR s.last_name LIKE ? OR u.email LIKE ?";
        return $this->db->fetchAll($sql, [$searchTerm, $searchTerm, $searchTerm, $searchTerm]);
    }
    
    public function getAcademicRecord($studentId) {
        $sql = "SELECT c.course_code, c.course_name, c.credits, e.grade, e.grade_point, e.semester, e.academic_year
                FROM enrollments e
                JOIN courses c ON e.course_id = c.id
                WHERE e.student_id = ? AND e.status = 'completed'
                ORDER BY e.academic_year DESC, e.semester DESC";
        return $this->db->fetchAll($sql, [$studentId]);
    }
    
    public function calculateGPA($studentId) {
        $sql = "SELECT SUM(c.credits * e.grade_point) / SUM(c.credits) as gpa
                FROM enrollments e
                JOIN courses c ON e.course_id = c.id
                WHERE e.student_id = ? AND e.status = 'completed' AND e.grade_point IS NOT NULL";
        $result = $this->db->fetch($sql, [$studentId]);
        return round($result['gpa'] ?? 0, 2);
    }
}
