<?php
class Course extends Model {
    protected $table = 'courses';
    protected $fillable = [
        'course_code', 'course_name', 'department_id', 'faculty_id',
        'credits', 'semester', 'level', 'max_students', 'description',
        'prerequisites', 'status'
    ];
    
    public function getByLevel($level) {
        return $this->where('level = ? AND status = ?', [$level, 'active']);
    }
    
    public function getBySemester($semester, $level = null) {
        $conditions = 'semester = ? AND status = ?';
        $params = [$semester, 'active'];
        
        if ($level) {
            $conditions .= ' AND level = ?';
            $params[] = $level;
        }
        
        return $this->where($conditions, $params);
    }
    
    public function getByFaculty($facultyId) {
        return $this->where('faculty_id = ? AND status = ?', [$facultyId, 'active']);
    }
    
    public function getWithDepartment($courseId) {
        $sql = "SELECT c.*, d.name as department_name, f.name as faculty_name
                FROM courses c
                JOIN departments d ON c.department_id = d.id
                JOIN faculties f ON c.faculty_id = f.id
                WHERE c.id = ?";
        return $this->db->fetch($sql, [$courseId]);
    }
    
    public function getAvailableForStudent($studentLevel, $semester) {
        $sql = "SELECT c.*, d.name as department_name
                FROM courses c
                JOIN departments d ON c.department_id = d.id
                WHERE c.level = ? AND (c.semester = ? OR c.semester = 'both') AND c.status = 'active'
                ORDER BY c.course_code";
        return $this->db->fetchAll($sql, [$studentLevel, $semester]);
    }
    
    public function getEnrolledStudents($courseId, $semester, $academicYear) {
        $sql = "SELECT s.*, u.email, e.enrollment_date, e.status
                FROM enrollments e
                JOIN students s ON e.student_id = s.id
                JOIN users u ON s.user_id = u.id
                WHERE e.course_id = ? AND e.semester = ? AND e.academic_year = ?
                ORDER BY s.last_name, s.first_name";
        return $this->db->fetchAll($sql, [$courseId, $semester, $academicYear]);
    }
    
    public function getEnrollmentCount($courseId, $semester, $academicYear) {
        $sql = "SELECT COUNT(*) as count FROM enrollments 
                WHERE course_id = ? AND semester = ? AND academic_year = ? AND status = 'enrolled'";
        $result = $this->db->fetch($sql, [$courseId, $semester, $academicYear]);
        return $result['count'];
    }
    
    public function isEnrollmentFull($courseId, $semester, $academicYear) {
        $course = $this->find($courseId);
        $currentEnrollment = $this->getEnrollmentCount($courseId, $semester, $academicYear);
        return $currentEnrollment >= $course['max_students'];
    }
    
    public function searchCourses($search) {
        $searchTerm = "%$search%";
        $sql = "SELECT c.*, d.name as department_name
                FROM courses c
                JOIN departments d ON c.department_id = d.id
                WHERE (c.course_code LIKE ? OR c.course_name LIKE ?) AND c.status = 'active'
                ORDER BY c.course_code";
        return $this->db->fetchAll($sql, [$searchTerm, $searchTerm]);
    }
}