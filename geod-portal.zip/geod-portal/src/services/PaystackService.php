<?php

class PaystackService {
    
    private $secretKey;
    private $publicKey;
    private $baseUrl = 'https://api.paystack.co';
    
    public function __construct() {
        // Load from environment variables (try both $_ENV and getenv)
        $this->secretKey = $_ENV['PAYSTACK_SECRET_KEY'] ?? getenv('PAYSTACK_SECRET_KEY') ?: 'sk_test_your_secret_key_here';
        $this->publicKey = $_ENV['PAYSTACK_PUBLIC_KEY'] ?? getenv('PAYSTACK_PUBLIC_KEY') ?: 'pk_test_your_public_key_here';
    }
    
    /**
     * Initialize a payment transaction
     */
    public function initializePayment($email, $amount, $reference = null, $metadata = []) {
        $reference = $reference ?: $this->generateReference();
        
        $data = [
            'email' => $email,
            'amount' => $amount * 100, // Paystack expects amount in kobo
            'reference' => $reference,
            'currency' => 'NGN',
            'callback_url' => ($_ENV['APP_URL'] ?? 'http://localhost:8080') . '/payments/verify/' . $reference,
            'metadata' => $metadata
        ];
        
        $response = $this->makeRequest('POST', '/transaction/initialize', $data);
        
        if ($response && $response['status']) {
            return [
                'success' => true,
                'data' => $response['data'],
                'reference' => $reference,
                'authorization_url' => $response['data']['authorization_url'],
                'access_code' => $response['data']['access_code']
            ];
        }
        
        return [
            'success' => false,
            'message' => $response['message'] ?? 'Payment initialization failed'
        ];
    }
    
    /**
     * Verify a payment transaction
     */
    public function verifyPayment($reference) {
        $response = $this->makeRequest('GET', "/transaction/verify/{$reference}");
        
        if ($response && $response['status']) {
            $data = $response['data'];
            return [
                'success' => true,
                'data' => $data,
                'status' => $data['status'],
                'amount' => $data['amount'] / 100, // Convert back to naira
                'reference' => $data['reference'],
                'paid_at' => $data['paid_at'],
                'gateway_response' => $data['gateway_response']
            ];
        }
        
        return [
            'success' => false,
            'message' => $response['message'] ?? 'Payment verification failed'
        ];
    }
    
    /**
     * Get payment details
     */
    public function getPayment($reference) {
        $response = $this->makeRequest('GET', "/transaction/{$reference}");
        
        if ($response && $response['status']) {
            return [
                'success' => true,
                'data' => $response['data']
            ];
        }
        
        return [
            'success' => false,
            'message' => $response['message'] ?? 'Payment retrieval failed'
        ];
    }
    
    /**
     * List all payments
     */
    public function listPayments($perPage = 50, $page = 1) {
        $response = $this->makeRequest('GET', "/transaction?perPage={$perPage}&page={$page}");
        
        if ($response && $response['status']) {
            return [
                'success' => true,
                'data' => $response['data'],
                'meta' => $response['meta']
            ];
        }
        
        return [
            'success' => false,
            'message' => $response['message'] ?? 'Payment list retrieval failed'
        ];
    }
    
    /**
     * Get supported banks
     */
    public function getBanks() {
        $response = $this->makeRequest('GET', '/bank');
        
        if ($response && $response['status']) {
            return [
                'success' => true,
                'data' => $response['data']
            ];
        }
        
        return [
            'success' => false,
            'message' => $response['message'] ?? 'Banks retrieval failed'
        ];
    }
    
    /**
     * Create a transfer recipient
     */
    public function createTransferRecipient($name, $accountNumber, $bankCode) {
        $data = [
            'type' => 'nuban',
            'name' => $name,
            'account_number' => $accountNumber,
            'bank_code' => $bankCode,
            'currency' => 'NGN'
        ];
        
        $response = $this->makeRequest('POST', '/transferrecipient', $data);
        
        if ($response && $response['status']) {
            return [
                'success' => true,
                'data' => $response['data']
            ];
        }
        
        return [
            'success' => false,
            'message' => $response['message'] ?? 'Transfer recipient creation failed'
        ];
    }
    
    /**
     * Initiate a transfer
     */
    public function initiateTransfer($amount, $recipientCode, $reason = null) {
        $data = [
            'source' => 'balance',
            'amount' => $amount * 100, // Convert to kobo
            'recipient' => $recipientCode,
            'reason' => $reason ?: 'Payment from GEOD University Portal'
        ];
        
        $response = $this->makeRequest('POST', '/transfer', $data);
        
        if ($response && $response['status']) {
            return [
                'success' => true,
                'data' => $response['data']
            ];
        }
        
        return [
            'success' => false,
            'message' => $response['message'] ?? 'Transfer initiation failed'
        ];
    }
    
    /**
     * Get public key for frontend integration
     */
    public function getPublicKey() {
        return $this->publicKey;
    }
    
    /**
     * Generate a unique reference
     */
    private function generateReference($prefix = 'GEO') {
        return $prefix . '-' . strtoupper(uniqid()) . '-' . time();
    }
    
    /**
     * Make HTTP request to Paystack API
     */
    private function makeRequest($method, $endpoint, $data = null) {
        $url = $this->baseUrl . $endpoint;
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $this->secretKey,
            'Content-Type: application/json',
            'Cache-Control: no-cache',
        ]);
        
        if ($method === 'POST') {
            curl_setopt($ch, CURLOPT_POST, true);
            if ($data) {
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
            }
        } elseif ($method === 'PUT') {
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT');
            if ($data) {
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
            }
        }
        
        // SSL verification
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);
        
        if ($error) {
            error_log("Paystack API Error: " . $error);
            return false;
        }
        
        $decodedResponse = json_decode($response, true);
        
        if ($httpCode >= 400) {
            error_log("Paystack API HTTP Error {$httpCode}: " . $response);
            return $decodedResponse ?: false;
        }
        
        return $decodedResponse;
    }
    
    /**
     * Webhook signature verification
     */
    public function verifyWebhookSignature($payload, $signature) {
        $hash = hash_hmac('sha512', $payload, $this->secretKey);
        return hash_equals($hash, $signature);
    }
    
    /**
     * Handle webhook events
     */
    public function handleWebhook($payload) {
        $event = json_decode($payload, true);
        
        if (!$event) {
            return ['success' => false, 'message' => 'Invalid payload'];
        }
        
        switch ($event['event']) {
            case 'charge.success':
                return $this->handlePaymentSuccess($event['data']);
                
            case 'charge.failed':
                return $this->handlePaymentFailure($event['data']);
                
            case 'transfer.success':
                return $this->handleTransferSuccess($event['data']);
                
            case 'transfer.failed':
                return $this->handleTransferFailure($event['data']);
                
            default:
                return ['success' => true, 'message' => 'Event not handled'];
        }
    }
    
    private function handlePaymentSuccess($data) {
        try {
            $db = Database::getInstance();
            
            // Update payment status
            $db->update('payments', [
                'status' => 'completed',
                'paystack_reference' => $data['reference'],
                'gateway_response' => json_encode($data),
                'paid_at' => date('Y-m-d H:i:s', strtotime($data['paid_at']))
            ], 'reference = ?', [$data['reference']]);
            
            // Log success
            error_log("Payment successful: " . $data['reference']);
            
            return ['success' => true, 'message' => 'Payment updated'];
            
        } catch (Exception $e) {
            error_log("Payment success handler error: " . $e->getMessage());
            return ['success' => false, 'message' => 'Handler error'];
        }
    }
    
    private function handlePaymentFailure($data) {
        try {
            $db = Database::getInstance();
            
            // Update payment status
            $db->update('payments', [
                'status' => 'failed',
                'gateway_response' => json_encode($data)
            ], 'reference = ?', [$data['reference']]);
            
            // Log failure
            error_log("Payment failed: " . $data['reference']);
            
            return ['success' => true, 'message' => 'Payment failure updated'];
            
        } catch (Exception $e) {
            error_log("Payment failure handler error: " . $e->getMessage());
            return ['success' => false, 'message' => 'Handler error'];
        }
    }
    
    private function handleTransferSuccess($data) {
        // Handle successful transfers
        error_log("Transfer successful: " . json_encode($data));
        return ['success' => true, 'message' => 'Transfer success handled'];
    }
    
    private function handleTransferFailure($data) {
        // Handle failed transfers
        error_log("Transfer failed: " . json_encode($data));
        return ['success' => true, 'message' => 'Transfer failure handled'];
    }
}