<?php

class EmailService {
    
    private $host;
    private $port;
    private $username;
    private $password;
    private $fromEmail;
    private $fromName;
    private $encryption;
    
    public function __construct() {
        // Mailtrap SMTP configuration
        $this->host = $_ENV['MAIL_HOST'] ?? 'live.smtp.mailtrap.io';
        $this->port = $_ENV['MAIL_PORT'] ?? 587;
        $this->username = $_ENV['MAIL_USERNAME'] ?? 'api';
        $this->password = $_ENV['MAIL_PASSWORD'] ?? 'your_mailtrap_password_here';
        $this->fromEmail = $_ENV['MAIL_FROM_EMAIL'] ?? 'noreply@geoduniversity.edu.ng';
        $this->fromName = $_ENV['MAIL_FROM_NAME'] ?? 'GEOD University Portal';
        $this->encryption = $_ENV['MAIL_ENCRYPTION'] ?? 'tls';
    }
    
    /**
     * Send email using SMTP
     */
    public function sendEmail($to, $subject, $htmlBody, $textBody = null, $attachments = []) {
        try {
            // Create a unique boundary
            $boundary = md5(time());
            
            // Email headers
            $headers = $this->buildHeaders($to, $boundary);
            
            // Build email body
            $body = $this->buildEmailBody($htmlBody, $textBody, $attachments, $boundary);
            
            // Send email via SMTP
            $result = $this->sendViaSMTP($to, $subject, $body, $headers);
            
            if ($result) {
                // Log success
                error_log("Email sent successfully to: {$to}, Subject: {$subject}");
                return ['success' => true, 'message' => 'Email sent successfully'];
            } else {
                error_log("Failed to send email to: {$to}");
                return ['success' => false, 'message' => 'Failed to send email'];
            }
            
        } catch (Exception $e) {
            error_log("Email error: " . $e->getMessage());
            return ['success' => false, 'message' => 'Email service error: ' . $e->getMessage()];
        }
    }
    
    /**
     * Send welcome email to new users
     */
    public function sendWelcomeEmail($email, $name, $username, $temporaryPassword = null) {
        $subject = "Welcome to GEOD University Portal";
        
        $htmlBody = $this->getWelcomeEmailTemplate($name, $username, $temporaryPassword);
        $textBody = "Welcome to GEOD University Portal, {$name}! Your username is: {$username}";
        
        return $this->sendEmail($email, $subject, $htmlBody, $textBody);
    }
    
    /**
     * Send password reset email
     */
    public function sendPasswordResetEmail($email, $token) {
        $subject = "Password Reset Request - GEOD University";
        $resetLink = $_ENV['APP_URL'] . "/auth/reset-password?token=" . $token;
        
        $htmlBody = $this->getPasswordResetEmailTemplate($resetLink, $token);
        $textBody = "Click this link to reset your password: {$resetLink}";
        
        return $this->sendEmail($email, $subject, $htmlBody, $textBody);
    }
    
    /**
     * Send application confirmation email
     */
    public function sendApplicationConfirmationEmail($email, $name, $applicationId, $program, $jambRegNo) {
        $subject = "Application Received - GEOD University";
        
        $htmlBody = $this->getApplicationConfirmationTemplate($name, $applicationId, $program, $jambRegNo);
        $textBody = "Dear {$name}, your application to {$program} has been received. Application ID: GEO-APP-{$applicationId}";
        
        return $this->sendEmail($email, $subject, $htmlBody, $textBody);
    }
    
    /**
     * Send admission notification email
     */
    public function sendAdmissionNotificationEmail($email, $name, $status, $program, $studentId = null) {
        $subject = $status === 'approved' ? "Congratulations! Admission Offer - GEOD University" : "Application Update - GEOD University";
        
        $htmlBody = $this->getAdmissionNotificationTemplate($name, $status, $program, $studentId);
        $textBody = $status === 'approved' 
            ? "Congratulations {$name}! You have been admitted to {$program}. Student ID: {$studentId}"
            : "Dear {$name}, your application status has been updated to: {$status}";
        
        return $this->sendEmail($email, $subject, $htmlBody, $textBody);
    }
    
    /**
     * Send payment confirmation email
     */
    public function sendPaymentConfirmationEmail($email, $name, $amount, $paymentType, $reference) {
        $subject = "Payment Confirmation - GEOD University";
        
        $htmlBody = $this->getPaymentConfirmationTemplate($name, $amount, $paymentType, $reference);
        $textBody = "Dear {$name}, your payment of ₦{$amount} for {$paymentType} has been confirmed. Reference: {$reference}";
        
        return $this->sendEmail($email, $subject, $htmlBody, $textBody);
    }
    
    /**
     * Build email headers
     */
    private function buildHeaders($to, $boundary) {
        $headers = [
            "From: {$this->fromName} <{$this->fromEmail}>",
            "Reply-To: {$this->fromEmail}",
            "To: {$to}",
            "MIME-Version: 1.0",
            "Content-Type: multipart/alternative; boundary=\"{$boundary}\"",
            "X-Mailer: GEOD University Portal"
        ];
        
        return implode("\r\n", $headers);
    }
    
    /**
     * Build email body
     */
    private function buildEmailBody($htmlBody, $textBody, $attachments, $boundary) {
        $body = "--{$boundary}\r\n";
        
        // Add text version
        if ($textBody) {
            $body .= "Content-Type: text/plain; charset=UTF-8\r\n";
            $body .= "Content-Transfer-Encoding: 7bit\r\n\r\n";
            $body .= $textBody . "\r\n\r\n";
            $body .= "--{$boundary}\r\n";
        }
        
        // Add HTML version
        $body .= "Content-Type: text/html; charset=UTF-8\r\n";
        $body .= "Content-Transfer-Encoding: 7bit\r\n\r\n";
        $body .= $htmlBody . "\r\n\r\n";
        
        // Add attachments (if any)
        foreach ($attachments as $attachment) {
            $body .= "--{$boundary}\r\n";
            $body .= "Content-Type: application/octet-stream\r\n";
            $body .= "Content-Disposition: attachment; filename=\"{$attachment['name']}\"\r\n";
            $body .= "Content-Transfer-Encoding: base64\r\n\r\n";
            $body .= chunk_split(base64_encode($attachment['content'])) . "\r\n";
        }
        
        $body .= "--{$boundary}--";
        
        return $body;
    }
    
    /**
     * Send email via SMTP
     */
    private function sendViaSMTP($to, $subject, $body, $headers) {
        // Connect to SMTP server
        $socket = fsockopen($this->host, $this->port, $errno, $errstr, 30);
        
        if (!$socket) {
            throw new Exception("Could not connect to SMTP server: {$errstr} ({$errno})");
        }
        
        // Read server response
        $this->readSMTPResponse($socket);
        
        // Send EHLO
        fwrite($socket, "EHLO {$_SERVER['SERVER_NAME']}\r\n");
        $this->readSMTPResponse($socket);
        
        // Start TLS if required
        if ($this->encryption === 'tls') {
            fwrite($socket, "STARTTLS\r\n");
            $this->readSMTPResponse($socket);
            stream_socket_enable_crypto($socket, true, STREAM_CRYPTO_METHOD_TLS_CLIENT);
            
            // Send EHLO again after TLS
            fwrite($socket, "EHLO {$_SERVER['SERVER_NAME']}\r\n");
            $this->readSMTPResponse($socket);
        }
        
        // Authenticate
        fwrite($socket, "AUTH LOGIN\r\n");
        $this->readSMTPResponse($socket);
        
        fwrite($socket, base64_encode($this->username) . "\r\n");
        $this->readSMTPResponse($socket);
        
        fwrite($socket, base64_encode($this->password) . "\r\n");
        $this->readSMTPResponse($socket);
        
        // Send email
        fwrite($socket, "MAIL FROM: <{$this->fromEmail}>\r\n");
        $this->readSMTPResponse($socket);
        
        fwrite($socket, "RCPT TO: <{$to}>\r\n");
        $this->readSMTPResponse($socket);
        
        fwrite($socket, "DATA\r\n");
        $this->readSMTPResponse($socket);
        
        // Send headers and body
        fwrite($socket, $headers . "\r\n");
        fwrite($socket, "Subject: {$subject}\r\n\r\n");
        fwrite($socket, $body . "\r\n.\r\n");
        $this->readSMTPResponse($socket);
        
        // Quit
        fwrite($socket, "QUIT\r\n");
        $this->readSMTPResponse($socket);
        
        fclose($socket);
        
        return true;
    }
    
    /**
     * Read SMTP server response
     */
    private function readSMTPResponse($socket) {
        $response = '';
        while ($line = fgets($socket, 515)) {
            $response .= $line;
            if (substr($line, 3, 1) === ' ') break;
        }
        
        // Check for errors
        $code = substr($response, 0, 3);
        if ($code >= 400) {
            throw new Exception("SMTP Error: {$response}");
        }
        
        return $response;
    }
    
    /**
     * Email templates
     */
    private function getWelcomeEmailTemplate($name, $username, $temporaryPassword) {
        return "
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset='UTF-8'>
            <title>Welcome to GEOD University</title>
        </head>
        <body style='font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;'>
            <div style='text-align: center; margin-bottom: 30px;'>
                <h1 style='color: #16a34a; margin-bottom: 10px;'>Welcome to GEOD University Portal</h1>
                <p style='color: #666; font-size: 16px;'>Your gateway to academic excellence</p>
            </div>
            
            <div style='background: #f8f9fa; padding: 20px; border-radius: 8px; margin-bottom: 20px;'>
                <h2 style='color: #16a34a; margin-top: 0;'>Hello {$name}!</h2>
                <p>Welcome to GEOD University Portal. Your account has been successfully created.</p>
                
                <div style='background: white; padding: 15px; border-radius: 5px; margin: 15px 0;'>
                    <strong>Your Login Details:</strong><br>
                    Username: <code style='background: #e5e7eb; padding: 2px 5px; border-radius: 3px;'>{$username}</code><br>
                    " . ($temporaryPassword ? "Temporary Password: <code style='background: #e5e7eb; padding: 2px 5px; border-radius: 3px;'>{$temporaryPassword}</code>" : "Use the password you created during registration") . "
                </div>
                
                " . ($temporaryPassword ? "<p style='color: #d97706; background: #fef3c7; padding: 10px; border-radius: 5px;'><strong>Important:</strong> Please change your temporary password after your first login.</p>" : "") . "
                
                <p>You can now access your portal to:</p>
                <ul style='padding-left: 20px;'>
                    <li>Submit university applications</li>
                    <li>Make payments</li>
                    <li>Check admission status</li>
                    <li>Access course materials (for admitted students)</li>
                </ul>
            </div>
            
            <div style='text-align: center; margin: 30px 0;'>
                <a href='" . ($_ENV['APP_URL'] ?? 'http://localhost') . "/auth/login' style='background: #16a34a; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; display: inline-block;'>Login to Portal</a>
            </div>
            
            <div style='border-top: 1px solid #e5e7eb; padding-top: 20px; text-align: center; color: #666; font-size: 14px;'>
                <p>If you have any questions, please contact our support team.</p>
                <p><strong>GEOD University Portal</strong><br>
                Email: support@geoduniversity.edu.ng</p>
            </div>
        </body>
        </html>";
    }
    
    private function getPasswordResetEmailTemplate($resetLink, $token) {
        return "
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset='UTF-8'>
            <title>Password Reset - GEOD University</title>
        </head>
        <body style='font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;'>
            <div style='text-align: center; margin-bottom: 30px;'>
                <h1 style='color: #16a34a; margin-bottom: 10px;'>Password Reset Request</h1>
                <p style='color: #666; font-size: 16px;'>GEOD University Portal</p>
            </div>
            
            <div style='background: #f8f9fa; padding: 20px; border-radius: 8px; margin-bottom: 20px;'>
                <h2 style='color: #dc2626; margin-top: 0;'>Reset Your Password</h2>
                <p>You have requested to reset your password for your GEOD University Portal account.</p>
                
                <p>Click the button below to reset your password:</p>
                
                <div style='text-align: center; margin: 30px 0;'>
                    <a href='{$resetLink}' style='background: #dc2626; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; display: inline-block;'>Reset Password</a>
                </div>
                
                <p style='color: #666; font-size: 14px;'>If the button above doesn't work, copy and paste this link into your browser:</p>
                <p style='word-break: break-all; background: #e5e7eb; padding: 10px; border-radius: 5px; font-family: monospace;'>{$resetLink}</p>
                
                <div style='background: #fef3c7; padding: 15px; border-radius: 5px; margin: 20px 0;'>
                    <p style='margin: 0; color: #d97706;'><strong>Security Notice:</strong></p>
                    <ul style='margin: 10px 0 0 0; color: #d97706;'>
                        <li>This link will expire in 1 hour</li>
                        <li>If you didn't request this reset, please ignore this email</li>
                        <li>For security reasons, change your password regularly</li>
                    </ul>
                </div>
            </div>
            
            <div style='border-top: 1px solid #e5e7eb; padding-top: 20px; text-align: center; color: #666; font-size: 14px;'>
                <p>If you have any questions, please contact our support team.</p>
                <p><strong>GEOD University Portal</strong><br>
                Email: support@geoduniversity.edu.ng</p>
            </div>
        </body>
        </html>";
    }
    
    private function getApplicationConfirmationTemplate($name, $applicationId, $program, $jambRegNo) {
        return "
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset='UTF-8'>
            <title>Application Received - GEOD University</title>
        </head>
        <body style='font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;'>
            <div style='text-align: center; margin-bottom: 30px;'>
                <h1 style='color: #16a34a; margin-bottom: 10px;'>Application Received Successfully</h1>
                <p style='color: #666; font-size: 16px;'>GEOD University Admissions Office</p>
            </div>
            
            <div style='background: #f8f9fa; padding: 20px; border-radius: 8px; margin-bottom: 20px;'>
                <h2 style='color: #16a34a; margin-top: 0;'>Dear {$name},</h2>
                <p>Thank you for submitting your application to GEOD University. We have successfully received your application and it is now under review.</p>
                
                <div style='background: white; padding: 20px; border-radius: 5px; margin: 20px 0; border-left: 4px solid #16a34a;'>
                    <h3 style='color: #16a34a; margin-top: 0;'>Application Details</h3>
                    <table style='width: 100%; border-collapse: collapse;'>
                        <tr><td style='padding: 5px 0; font-weight: bold;'>Application ID:</td><td style='padding: 5px 0;'>GEO-APP-{$applicationId}</td></tr>
                        <tr><td style='padding: 5px 0; font-weight: bold;'>Program:</td><td style='padding: 5px 0;'>{$program}</td></tr>
                        <tr><td style='padding: 5px 0; font-weight: bold;'>JAMB Registration:</td><td style='padding: 5px 0;'>{$jambRegNo}</td></tr>
                        <tr><td style='padding: 5px 0; font-weight: bold;'>Status:</td><td style='padding: 5px 0;'><span style='background: #fbbf24; color: white; padding: 2px 8px; border-radius: 12px; font-size: 12px;'>Under Review</span></td></tr>
                    </table>
                </div>
                
                <h3 style='color: #16a34a;'>Next Steps</h3>
                <ol style='padding-left: 20px;'>
                    <li><strong>Complete Payment:</strong> Please complete your application fee payment to proceed with the admission process.</li>
                    <li><strong>Post-UTME Screening:</strong> Eligible candidates will be contacted for Post-UTME screening.</li>
                    <li><strong>Check Status:</strong> You can check your application status anytime by logging into your portal.</li>
                </ol>
                
                <div style='background: #dbeafe; padding: 15px; border-radius: 5px; margin: 20px 0;'>
                    <p style='margin: 0; color: #1e40af;'><strong>Important:</strong> Keep this email for your records. You'll need your Application ID for any inquiries.</p>
                </div>
            </div>
            
            <div style='text-align: center; margin: 30px 0;'>
                <a href='" . ($_ENV['APP_URL'] ?? 'http://localhost') . "/application/status' style='background: #16a34a; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; display: inline-block;'>Check Application Status</a>
            </div>
            
            <div style='border-top: 1px solid #e5e7eb; padding-top: 20px; text-align: center; color: #666; font-size: 14px;'>
                <p>Best regards,<br><strong>GEOD University Admissions Office</strong></p>
                <p>Email: admissions@geoduniversity.edu.ng<br>Phone: +234-XXX-XXX-XXXX</p>
            </div>
        </body>
        </html>";
    }
    
    private function getAdmissionNotificationTemplate($name, $status, $program, $studentId) {
        $isApproved = $status === 'approved';
        $statusColor = $isApproved ? '#16a34a' : '#dc2626';
        $statusBg = $isApproved ? '#dcfce7' : '#fee2e2';
        
        return "
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset='UTF-8'>
            <title>Admission Update - GEOD University</title>
        </head>
        <body style='font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;'>
            <div style='text-align: center; margin-bottom: 30px;'>
                <h1 style='color: {$statusColor}; margin-bottom: 10px;'>" . ($isApproved ? 'Congratulations! Admission Offer' : 'Application Status Update') . "</h1>
                <p style='color: #666; font-size: 16px;'>GEOD University Admissions Office</p>
            </div>
            
            <div style='background: #f8f9fa; padding: 20px; border-radius: 8px; margin-bottom: 20px;'>
                <h2 style='color: {$statusColor}; margin-top: 0;'>Dear {$name},</h2>
                
                " . ($isApproved ? "
                <div style='background: {$statusBg}; padding: 20px; border-radius: 8px; text-align: center; margin: 20px 0; border: 2px solid {$statusColor};'>
                    <h2 style='color: {$statusColor}; margin: 0 0 10px 0;'>🎉 ADMISSION OFFER 🎉</h2>
                    <p style='margin: 0; font-size: 18px; color: {$statusColor};'>You have been offered admission to<br><strong>{$program}</strong></p>
                </div>
                
                <div style='background: white; padding: 20px; border-radius: 5px; margin: 20px 0; border-left: 4px solid {$statusColor};'>
                    <h3 style='color: {$statusColor}; margin-top: 0;'>Your Details</h3>
                    <table style='width: 100%; border-collapse: collapse;'>
                        <tr><td style='padding: 5px 0; font-weight: bold;'>Student ID:</td><td style='padding: 5px 0;'>{$studentId}</td></tr>
                        <tr><td style='padding: 5px 0; font-weight: bold;'>Program:</td><td style='padding: 5px 0;'>{$program}</td></tr>
                        <tr><td style='padding: 5px 0; font-weight: bold;'>Status:</td><td style='padding: 5px 0;'><span style='background: {$statusColor}; color: white; padding: 2px 8px; border-radius: 12px; font-size: 12px;'>ADMITTED</span></td></tr>
                    </table>
                </div>
                
                <h3 style='color: {$statusColor};'>Next Steps</h3>
                <ol style='padding-left: 20px;'>
                    <li><strong>Accept Offer:</strong> Login to your portal and accept this admission offer</li>
                    <li><strong>Pay Acceptance Fee:</strong> Complete payment of acceptance fee within 2 weeks</li>
                    <li><strong>School Fees:</strong> Pay school fees before resumption</li>
                    <li><strong>Course Registration:</strong> Register for courses during registration period</li>
                </ol>
                " : "
                <p>We have completed the review of your application to {$program}.</p>
                <div style='background: {$statusBg}; padding: 15px; border-radius: 5px; margin: 20px 0; text-align: center;'>
                    <p style='margin: 0; color: {$statusColor}; font-size: 18px;'><strong>Status: " . strtoupper($status) . "</strong></p>
                </div>
                ") . "
                
                <div style='background: #dbeafe; padding: 15px; border-radius: 5px; margin: 20px 0;'>
                    <p style='margin: 0; color: #1e40af;'><strong>Important:</strong> Login to your portal for complete details and next steps.</p>
                </div>
            </div>
            
            <div style='text-align: center; margin: 30px 0;'>
                <a href='" . ($_ENV['APP_URL'] ?? 'http://localhost') . "/dashboard' style='background: {$statusColor}; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; display: inline-block;'>Access Portal</a>
            </div>
            
            <div style='border-top: 1px solid #e5e7eb; padding-top: 20px; text-align: center; color: #666; font-size: 14px;'>
                <p>Best regards,<br><strong>GEOD University Admissions Office</strong></p>
                <p>Email: admissions@geoduniversity.edu.ng<br>Phone: +234-XXX-XXX-XXXX</p>
            </div>
        </body>
        </html>";
    }
    
    private function getPaymentConfirmationTemplate($name, $amount, $paymentType, $reference) {
        return "
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset='UTF-8'>
            <title>Payment Confirmation - GEOD University</title>
        </head>
        <body style='font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;'>
            <div style='text-align: center; margin-bottom: 30px;'>
                <h1 style='color: #16a34a; margin-bottom: 10px;'>Payment Confirmed</h1>
                <p style='color: #666; font-size: 16px;'>GEOD University Finance Office</p>
            </div>
            
            <div style='background: #f8f9fa; padding: 20px; border-radius: 8px; margin-bottom: 20px;'>
                <h2 style='color: #16a34a; margin-top: 0;'>Dear {$name},</h2>
                
                <div style='background: #dcfce7; padding: 20px; border-radius: 8px; text-align: center; margin: 20px 0; border: 2px solid #16a34a;'>
                    <h2 style='color: #16a34a; margin: 0 0 10px 0;'>✅ PAYMENT SUCCESSFUL</h2>
                    <p style='margin: 0; font-size: 18px; color: #16a34a;'>Your payment has been processed successfully</p>
                </div>
                
                <div style='background: white; padding: 20px; border-radius: 5px; margin: 20px 0; border-left: 4px solid #16a34a;'>
                    <h3 style='color: #16a34a; margin-top: 0;'>Payment Details</h3>
                    <table style='width: 100%; border-collapse: collapse;'>
                        <tr><td style='padding: 8px 0; font-weight: bold; border-bottom: 1px solid #e5e7eb;'>Amount:</td><td style='padding: 8px 0; border-bottom: 1px solid #e5e7eb; text-align: right;'><strong>₦" . number_format($amount, 2) . "</strong></td></tr>
                        <tr><td style='padding: 8px 0; font-weight: bold; border-bottom: 1px solid #e5e7eb;'>Payment For:</td><td style='padding: 8px 0; border-bottom: 1px solid #e5e7eb; text-align: right;'>" . ucwords(str_replace('_', ' ', $paymentType)) . "</td></tr>
                        <tr><td style='padding: 8px 0; font-weight: bold; border-bottom: 1px solid #e5e7eb;'>Reference:</td><td style='padding: 8px 0; border-bottom: 1px solid #e5e7eb; text-align: right; font-family: monospace;'>{$reference}</td></tr>
                        <tr><td style='padding: 8px 0; font-weight: bold;'>Date:</td><td style='padding: 8px 0; text-align: right;'>" . date('F j, Y \a\t g:i A') . "</td></tr>
                    </table>
                </div>
                
                <div style='background: #dbeafe; padding: 15px; border-radius: 5px; margin: 20px 0;'>
                    <p style='margin: 0; color: #1e40af;'><strong>Receipt:</strong> This email serves as your payment receipt. Please keep it for your records.</p>
                </div>
                
                <p>Your payment has been successfully processed and your account has been updated. You can view your payment history anytime in your portal.</p>
            </div>
            
            <div style='text-align: center; margin: 30px 0;'>
                <a href='" . ($_ENV['APP_URL'] ?? 'http://localhost') . "/payments' style='background: #16a34a; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; display: inline-block;'>View Payment History</a>
            </div>
            
            <div style='border-top: 1px solid #e5e7eb; padding-top: 20px; text-align: center; color: #666; font-size: 14px;'>
                <p>Thank you for your payment!</p>
                <p><strong>GEOD University Finance Office</strong><br>
                Email: finance@geoduniversity.edu.ng<br>Phone: +234-XXX-XXX-XXXX</p>
            </div>
        </body>
        </html>";
    }
}