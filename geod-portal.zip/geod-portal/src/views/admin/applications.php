<?php
$userRole = Session::getUserRole();
$userName = Session::get('username');
?>


<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $title; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style></style>

<div class="min-h-screen bg-gray-50">
    <!-- Header -->
    <div class="bg-white shadow-sm border-b">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center py-4">
                <div>
                    <h1 class="text-2xl font-bold text-gray-900">Manage Applications</h1>
                    <p class="text-gray-600">Review and process student applications</p>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="/admin/reports?type=applications" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors">
                        View Reports
                    </a>
                    <a href="/admin/dashboard" class="text-gray-600 hover:text-gray-900">← Admin Dashboard</a>
                </div>
            </div>
        </div>
    </div>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        <!-- Filter Bar -->
        <div class="bg-white p-6 rounded-lg shadow-sm border mb-8">
            <form method="GET" class="flex flex-wrap gap-4 items-end">
                <div class="flex-1 min-w-0">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Search Applications</label>
                    <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" 
                           placeholder="Search by name, email, or JAMB number..." 
                           class="w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Status</label>
                    <select name="status" class="border border-gray-300 rounded-md px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                        <option value="all" <?php echo $status === 'all' ? 'selected' : ''; ?>>All Status</option>
                        <option value="pending" <?php echo $status === 'pending' ? 'selected' : ''; ?>>Pending</option>
                        <option value="screening" <?php echo $status === 'screening' ? 'selected' : ''; ?>>Screening</option>
                        <option value="approved" <?php echo $status === 'approved' ? 'selected' : ''; ?>>Approved</option>
                        <option value="rejected" <?php echo $status === 'rejected' ? 'selected' : ''; ?>>Rejected</option>
                    </select>
                </div>
                
                <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded-md text-sm hover:bg-blue-700 transition-colors">
                    Filter
                </button>
                
                <a href="/admin/applications" class="bg-gray-300 text-gray-700 px-4 py-2 rounded-md text-sm hover:bg-gray-400 transition-colors">
                    Clear
                </a>
            </form>
        </div>

        <!-- Results Summary -->
        <div class="bg-white p-4 rounded-lg shadow-sm border mb-6">
            <div class="flex justify-between items-center">
                <p class="text-sm text-gray-600">
                    Showing <?php echo count($applications); ?> of <?php echo number_format($total_count); ?> applications
                    <?php if ($search): ?>
                        for "<?php echo htmlspecialchars($search); ?>"
                    <?php endif; ?>
                    <?php if ($status !== 'all'): ?>
                        with status "<?php echo htmlspecialchars($status); ?>"
                    <?php endif; ?>
                </p>
                
                <!-- Pagination Info -->
                <?php if ($total_pages > 1): ?>
                    <p class="text-sm text-gray-600">
                        Page <?php echo $page; ?> of <?php echo $total_pages; ?>
                    </p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Applications Table -->
        <?php if (empty($applications)): ?>
            <div class="bg-white rounded-lg shadow-sm border">
                <div class="text-center py-12">
                    <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                    </svg>
                    <h3 class="mt-2 text-sm font-medium text-gray-900">No applications found</h3>
                    <p class="mt-1 text-sm text-gray-500">
                        <?php if ($search || $status !== 'all'): ?>
                            Try adjusting your search or filter criteria.
                        <?php else: ?>
                            No applications have been submitted yet.
                        <?php endif; ?>
                    </p>
                </div>
            </div>
        <?php else: ?>
            <div class="bg-white shadow-sm rounded-lg border overflow-hidden">
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Applicant</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Program</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">JAMB Score</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Payment</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Submitted</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php foreach ($applications as $application): ?>
                                <tr class="hover:bg-gray-50">
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="flex items-center">
                                            <div class="h-10 w-10 rounded-full bg-gray-200 flex items-center justify-center">
                                                <span class="text-sm font-medium text-gray-600">
                                                    <?php echo strtoupper(substr($application['username'], 0, 2)); ?>
                                                </span>
                                            </div>
                                            <div class="ml-4">
                                                <div class="text-sm font-medium text-gray-900">
                                                    <?php echo htmlspecialchars($application['username']); ?>
                                                </div>
                                                <div class="text-sm text-gray-500">
                                                    <?php echo htmlspecialchars($application['email']); ?>
                                                </div>
                                                <?php if ($application['jamb_reg_no']): ?>
                                                    <div class="text-xs text-gray-400 font-mono">
                                                        <?php echo htmlspecialchars($application['jamb_reg_no']); ?>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm text-gray-900">
                                            <?php echo htmlspecialchars($application['program']); ?>
                                        </div>
                                        <div class="text-sm text-gray-500">
                                            <?php echo ucfirst($application['entry_mode'] ?? 'UTME'); ?>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm font-medium text-gray-900">
                                            <?php echo $application['jamb_score'] ?? 'N/A'; ?>
                                        </div>
                                        <?php if ($application['jamb_score']): ?>
                                            <div class="text-xs text-gray-500">
                                                <?php
                                                $score = (int)$application['jamb_score'];
                                                if ($score >= 250) echo 'Excellent';
                                                elseif ($score >= 200) echo 'Good';
                                                elseif ($score >= 150) echo 'Fair';
                                                else echo 'Below Average';
                                                ?>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <?php if ($application['payment_status'] === 'completed'): ?>
                                            <span class="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800">
                                                ✓ Paid
                                            </span>
                                            <div class="text-xs text-gray-500">
                                                ₦<?php echo number_format($application['payment_amount'] ?? 0); ?>
                                            </div>
                                        <?php elseif ($application['payment_status'] === 'pending'): ?>
                                            <span class="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-yellow-100 text-yellow-800">
                                                Pending
                                            </span>
                                        <?php else: ?>
                                            <span class="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-red-100 text-red-800">
                                                Not Paid
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <?php
                                        $statusColors = [
                                            'pending' => 'bg-yellow-100 text-yellow-800',
                                            'screening' => 'bg-blue-100 text-blue-800',
                                            'approved' => 'bg-green-100 text-green-800',
                                            'rejected' => 'bg-red-100 text-red-800'
                                        ];
                                        $statusColor = $statusColors[$application['status']] ?? 'bg-gray-100 text-gray-800';
                                        ?>
                                        <span class="inline-flex px-2 py-1 text-xs font-semibold rounded-full <?php echo $statusColor; ?>">
                                            <?php echo ucfirst($application['status']); ?>
                                        </span>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        <?php echo date('M j, Y', strtotime($application['submitted_at'])); ?>
                                        <div class="text-xs text-gray-400">
                                            <?php echo date('g:i A', strtotime($application['submitted_at'])); ?>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                        <div class="flex space-x-2">
                                            <a href="/admin/applications/<?php echo $application['id']; ?>" 
                                               class="text-blue-600 hover:text-blue-900">
                                                Review
                                            </a>
                                            
                                            <?php if ($application['status'] === 'pending'): ?>
                                                <span class="text-gray-300">|</span>
                                                <button onclick="quickApprove(<?php echo $application['id']; ?>)" 
                                                        class="text-green-600 hover:text-green-900">
                                                    Approve
                                                </button>
                                                <span class="text-gray-300">|</span>
                                                <button onclick="quickReject(<?php echo $application['id']; ?>)" 
                                                        class="text-red-600 hover:text-red-900">
                                                    Reject
                                                </button>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Pagination -->
            <?php if ($total_pages > 1): ?>
                <div class="mt-6 flex justify-between items-center">
                    <div class="flex space-x-2">
                        <?php if ($page > 1): ?>
                            <a href="?page=<?php echo $page - 1; ?>&status=<?php echo urlencode($status); ?>&search=<?php echo urlencode($search); ?>" 
                               class="px-3 py-2 border border-gray-300 rounded-md text-sm text-gray-700 hover:bg-gray-50">
                                Previous
                            </a>
                        <?php endif; ?>
                        
                        <?php for ($i = max(1, $page - 2); $i <= min($total_pages, $page + 2); $i++): ?>
                            <a href="?page=<?php echo $i; ?>&status=<?php echo urlencode($status); ?>&search=<?php echo urlencode($search); ?>" 
                               class="px-3 py-2 border rounded-md text-sm <?php echo $i === $page ? 'bg-blue-600 text-white border-blue-600' : 'border-gray-300 text-gray-700 hover:bg-gray-50'; ?>">
                                <?php echo $i; ?>
                            </a>
                        <?php endfor; ?>
                        
                        <?php if ($page < $total_pages): ?>
                            <a href="?page=<?php echo $page + 1; ?>&status=<?php echo urlencode($status); ?>&search=<?php echo urlencode($search); ?>" 
                               class="px-3 py-2 border border-gray-300 rounded-md text-sm text-gray-700 hover:bg-gray-50">
                                Next
                            </a>
                        <?php endif; ?>
                    </div>
                    
                    <span class="text-sm text-gray-600">
                        Showing <?php echo (($page - 1) * 20) + 1; ?>-<?php echo min($page * 20, $total_count); ?> of <?php echo $total_count; ?> results
                    </span>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</div>

<!-- Quick Action Modals -->
<div id="quickApproveModal" class="fixed inset-0 bg-black bg-opacity-50 hidden z-50">
    <div class="flex items-center justify-center min-h-screen p-4">
        <div class="bg-white rounded-lg max-w-md w-full p-6">
            <h3 class="text-lg font-medium text-gray-900 mb-4">Quick Approve Application</h3>
            <form id="quickApproveForm" method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo CSRF::getToken(); ?>">
                <input type="hidden" id="approveApplicationId" name="application_id">
                
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Approval Notes (Optional)</label>
                    <textarea name="notes" rows="3" class="w-full border border-gray-300 rounded-md px-3 py-2 text-sm" 
                              placeholder="Add any notes about the approval..."></textarea>
                </div>
                
                <div class="flex space-x-3">
                    <button type="button" onclick="closeQuickApproveModal()" 
                            class="flex-1 bg-gray-300 text-gray-700 py-2 px-4 rounded-lg hover:bg-gray-400 transition-colors">
                        Cancel
                    </button>
                    <button type="submit" class="flex-1 bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700 transition-colors">
                        Approve Application
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<div id="quickRejectModal" class="fixed inset-0 bg-black bg-opacity-50 hidden z-50">
    <div class="flex items-center justify-center min-h-screen p-4">
        <div class="bg-white rounded-lg max-w-md w-full p-6">
            <h3 class="text-lg font-medium text-gray-900 mb-4">Quick Reject Application</h3>
            <form id="quickRejectForm" method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo CSRF::getToken(); ?>">
                <input type="hidden" id="rejectApplicationId" name="application_id">
                
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Rejection Reason *</label>
                    <textarea name="reason" rows="3" class="w-full border border-gray-300 rounded-md px-3 py-2 text-sm" 
                              placeholder="Please provide a reason for rejection..." required></textarea>
                </div>
                
                <div class="flex space-x-3">
                    <button type="button" onclick="closeQuickRejectModal()" 
                            class="flex-1 bg-gray-300 text-gray-700 py-2 px-4 rounded-lg hover:bg-gray-400 transition-colors">
                        Cancel
                    </button>
                    <button type="submit" class="flex-1 bg-red-600 text-white py-2 px-4 rounded-lg hover:bg-red-700 transition-colors">
                        Reject Application
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function quickApprove(applicationId) {
    document.getElementById('approveApplicationId').value = applicationId;
    document.getElementById('quickApproveForm').action = `/admin/applications/${applicationId}/approve`;
    document.getElementById('quickApproveModal').classList.remove('hidden');
}

function quickReject(applicationId) {
    document.getElementById('rejectApplicationId').value = applicationId;
    document.getElementById('quickRejectForm').action = `/admin/applications/${applicationId}/reject`;
    document.getElementById('quickRejectModal').classList.remove('hidden');
}

function closeQuickApproveModal() {
    document.getElementById('quickApproveModal').classList.add('hidden');
}

function closeQuickRejectModal() {
    document.getElementById('quickRejectModal').classList.add('hidden');
}

// Close modals when clicking outside
document.getElementById('quickApproveModal').addEventListener('click', function(e) {
    if (e.target === this) closeQuickApproveModal();
});

document.getElementById('quickRejectModal').addEventListener('click', function(e) {
    if (e.target === this) closeQuickRejectModal();
});
</script>