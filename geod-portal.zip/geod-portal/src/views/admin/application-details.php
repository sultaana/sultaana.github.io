<?php
$userRole = Session::getUserRole();
$userName = Session::get('username');
?>


<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $title; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style></style>

<div class="min-h-screen bg-gray-50">
    <!-- Header -->
    <div class="bg-white shadow-sm border-b">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center py-4">
                <div>
                    <h1 class="text-2xl font-bold text-gray-900">Application Details</h1>
                    <p class="text-gray-600"><?php echo htmlspecialchars($application['username']); ?> - <?php echo htmlspecialchars($application['program']); ?></p>
                </div>
                <div class="flex items-center space-x-4">
                    <span class="inline-flex px-3 py-1 text-sm font-semibold rounded-full 
                        <?php 
                        $statusColors = [
                            'pending' => 'bg-yellow-100 text-yellow-800',
                            'screening' => 'bg-blue-100 text-blue-800',
                            'approved' => 'bg-green-100 text-green-800',
                            'rejected' => 'bg-red-100 text-red-800'
                        ];
                        echo $statusColors[$application['status']] ?? 'bg-gray-100 text-gray-800';
                        ?>">
                        <?php echo ucfirst($application['status']); ?>
                    </span>
                    <a href="/admin/applications" class="text-gray-600 hover:text-gray-900">← Back to Applications</a>
                </div>
            </div>
        </div>
    </div>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <!-- Main Content -->
            <div class="lg:col-span-2 space-y-8">
                
                <!-- Personal Information -->
                <div class="bg-white rounded-lg shadow-sm border">
                    <div class="px-6 py-4 border-b">
                        <h3 class="text-lg font-medium text-gray-900">Personal Information</h3>
                    </div>
                    <div class="p-6">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div class="space-y-4">
                                <div>
                                    <label class="block text-sm font-medium text-gray-700">Full Name</label>
                                    <p class="mt-1 text-sm text-gray-900"><?php echo htmlspecialchars($application['first_name'] . ' ' . $application['last_name']); ?></p>
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-gray-700">Email Address</label>
                                    <p class="mt-1 text-sm text-gray-900"><?php echo htmlspecialchars($application['email']); ?></p>
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-gray-700">Phone Number</label>
                                    <p class="mt-1 text-sm text-gray-900"><?php echo htmlspecialchars($application['phone'] ?? 'Not provided'); ?></p>
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-gray-700">Date of Birth</label>
                                    <p class="mt-1 text-sm text-gray-900">
                                        <?php echo $application['date_of_birth'] ? date('F j, Y', strtotime($application['date_of_birth'])) : 'Not provided'; ?>
                                    </p>
                                </div>
                            </div>
                            <div class="space-y-4">
                                <div>
                                    <label class="block text-sm font-medium text-gray-700">Gender</label>
                                    <p class="mt-1 text-sm text-gray-900 capitalize"><?php echo htmlspecialchars($application['gender'] ?? 'Not provided'); ?></p>
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-gray-700">Address</label>
                                    <p class="mt-1 text-sm text-gray-900"><?php echo htmlspecialchars($application['address'] ?? 'Not provided'); ?></p>
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-gray-700">Username</label>
                                    <p class="mt-1 text-sm text-gray-900 font-mono"><?php echo htmlspecialchars($application['username']); ?></p>
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-gray-700">Account Created</label>
                                    <p class="mt-1 text-sm text-gray-900"><?php echo date('F j, Y g:i A', strtotime($application['account_created'])); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Academic Information -->
                <div class="bg-white rounded-lg shadow-sm border">
                    <div class="px-6 py-4 border-b">
                        <h3 class="text-lg font-medium text-gray-900">Academic Information</h3>
                    </div>
                    <div class="p-6">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div class="space-y-4">
                                <div>
                                    <label class="block text-sm font-medium text-gray-700">Program Applied For</label>
                                    <p class="mt-1 text-sm text-gray-900 font-medium"><?php echo htmlspecialchars($application['program']); ?></p>
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-gray-700">Entry Mode</label>
                                    <p class="mt-1 text-sm text-gray-900 capitalize"><?php echo htmlspecialchars($application['entry_mode'] ?? 'UTME'); ?></p>
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-gray-700">JAMB Registration Number</label>
                                    <p class="mt-1 text-sm text-gray-900 font-mono"><?php echo htmlspecialchars($application['jamb_reg_no'] ?? 'Not provided'); ?></p>
                                </div>
                            </div>
                            <div class="space-y-4">
                                <div>
                                    <label class="block text-sm font-medium text-gray-700">JAMB Score</label>
                                    <div class="mt-1">
                                        <span class="text-sm text-gray-900 font-bold"><?php echo $application['jamb_score'] ?? 'Not provided'; ?></span>
                                        <?php if ($application['jamb_score']): ?>
                                            <span class="ml-2 text-xs px-2 py-1 rounded-full
                                                <?php
                                                $score = (int)$application['jamb_score'];
                                                if ($score >= 250) echo 'bg-green-100 text-green-800';
                                                elseif ($score >= 200) echo 'bg-blue-100 text-blue-800';
                                                elseif ($score >= 150) echo 'bg-yellow-100 text-yellow-800';
                                                else echo 'bg-red-100 text-red-800';
                                                ?>">
                                                <?php
                                                if ($score >= 250) echo 'Excellent';
                                                elseif ($score >= 200) echo 'Good';
                                                elseif ($score >= 150) echo 'Fair';
                                                else echo 'Below Average';
                                                ?>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-gray-700">O'Level Results</label>
                                    <p class="mt-1 text-sm text-gray-900"><?php echo htmlspecialchars($application['olevel_results'] ?? 'Not provided'); ?></p>
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-gray-700">Application Date</label>
                                    <p class="mt-1 text-sm text-gray-900"><?php echo date('F j, Y g:i A', strtotime($application['submitted_at'])); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Documents -->
                <?php if (!empty($documents)): ?>
                <div class="bg-white rounded-lg shadow-sm border">
                    <div class="px-6 py-4 border-b">
                        <h3 class="text-lg font-medium text-gray-900">Uploaded Documents</h3>
                    </div>
                    <div class="p-6">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <?php foreach ($documents as $docType => $docPath): ?>
                                <div class="flex items-center p-3 border border-gray-200 rounded-lg">
                                    <svg class="w-8 h-8 text-blue-600 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                                    </svg>
                                    <div class="flex-1">
                                        <p class="text-sm font-medium text-gray-900 capitalize"><?php echo str_replace('_', ' ', $docType); ?></p>
                                        <a href="<?php echo htmlspecialchars($docPath); ?>" target="_blank" 
                                           class="text-sm text-blue-600 hover:text-blue-800">View Document</a>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Review History -->
                <?php if (!empty($review_history)): ?>
                <div class="bg-white rounded-lg shadow-sm border">
                    <div class="px-6 py-4 border-b">
                        <h3 class="text-lg font-medium text-gray-900">Review History</h3>
                    </div>
                    <div class="p-6">
                        <div class="flow-root">
                            <ul class="-mb-8">
                                <?php foreach ($review_history as $index => $history): ?>
                                    <li>
                                        <div class="relative pb-8">
                                            <?php if ($index !== count($review_history) - 1): ?>
                                                <span class="absolute top-4 left-4 -ml-px h-full w-0.5 bg-gray-200"></span>
                                            <?php endif; ?>
                                            <div class="relative flex space-x-3">
                                                <div>
                                                    <span class="h-8 w-8 rounded-full bg-blue-500 flex items-center justify-center ring-8 ring-white">
                                                        <svg class="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 20 20">
                                                            <path fill-rule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clip-rule="evenodd" />
                                                        </svg>
                                                    </span>
                                                </div>
                                                <div class="min-w-0 flex-1 pt-1.5 flex justify-between space-x-4">
                                                    <div>
                                                        <p class="text-sm text-gray-500"><?php echo htmlspecialchars($history['action']); ?></p>
                                                        <p class="text-xs text-gray-400">by <?php echo htmlspecialchars($history['action_by']); ?></p>
                                                    </div>
                                                    <div class="text-right text-sm whitespace-nowrap text-gray-500">
                                                        <?php echo date('M j, Y g:i A', strtotime($history['action_date'])); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>

            <!-- Sidebar -->
            <div class="lg:col-span-1 space-y-6">
                
                <!-- Payment Status -->
                <div class="bg-white rounded-lg shadow-sm border">
                    <div class="px-6 py-4 border-b">
                        <h3 class="text-lg font-medium text-gray-900">Payment Status</h3>
                    </div>
                    <div class="p-6">
                        <?php if ($application['payment_status'] === 'completed'): ?>
                            <div class="text-center">
                                <div class="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3">
                                    <svg class="w-8 h-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                    </svg>
                                </div>
                                <p class="text-sm font-medium text-green-800">Payment Completed</p>
                                <p class="text-2xl font-bold text-gray-900 mt-1">₦<?php echo number_format($application['payment_amount'] ?? 0); ?></p>
                                <p class="text-xs text-gray-500 mt-1">
                                    Paid on <?php echo $application['paid_at'] ? date('M j, Y', strtotime($application['paid_at'])) : 'Unknown'; ?>
                                </p>
                            </div>
                        <?php elseif ($application['payment_status'] === 'pending'): ?>
                            <div class="text-center">
                                <div class="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-3">
                                    <svg class="w-8 h-8 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                    </svg>
                                </div>
                                <p class="text-sm font-medium text-yellow-800">Payment Pending</p>
                                <p class="text-xs text-gray-500 mt-1">Awaiting payment confirmation</p>
                            </div>
                        <?php else: ?>
                            <div class="text-center">
                                <div class="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-3">
                                    <svg class="w-8 h-8 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                                    </svg>
                                </div>
                                <p class="text-sm font-medium text-red-800">Payment Not Made</p>
                                <p class="text-xs text-gray-500 mt-1">Application fee not paid</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Action Buttons -->
                <?php if ($application['status'] === 'pending'): ?>
                <div class="bg-white rounded-lg shadow-sm border">
                    <div class="px-6 py-4 border-b">
                        <h3 class="text-lg font-medium text-gray-900">Application Actions</h3>
                    </div>
                    <div class="p-6 space-y-3">
                        <form method="POST" action="/admin/applications/<?php echo $application['id']; ?>/approve" onsubmit="return confirm('Are you sure you want to approve this application?')">
                            <input type="hidden" name="csrf_token" value="<?php echo CSRF::getToken(); ?>">
                            <button type="submit" class="w-full bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700 transition-colors">
                                Approve Application
                            </button>
                        </form>
                        
                        <button onclick="showRejectModal()" class="w-full bg-red-600 text-white py-2 px-4 rounded-lg hover:bg-red-700 transition-colors">
                            Reject Application
                        </button>
                        
                        <form method="POST" action="/admin/applications/<?php echo $application['id']; ?>/status" onsubmit="return confirm('Move application to screening?')">
                            <input type="hidden" name="csrf_token" value="<?php echo CSRF::getToken(); ?>">
                            <input type="hidden" name="status" value="screening">
                            <button type="submit" class="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors">
                                Move to Screening
                            </button>
                        </form>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Application Summary -->
                <div class="bg-white rounded-lg shadow-sm border">
                    <div class="px-6 py-4 border-b">
                        <h3 class="text-lg font-medium text-gray-900">Quick Summary</h3>
                    </div>
                    <div class="p-6">
                        <dl class="space-y-3">
                            <div class="flex justify-between">
                                <dt class="text-sm font-medium text-gray-500">Application ID</dt>
                                <dd class="text-sm text-gray-900 font-mono"><?php echo $application['id']; ?></dd>
                            </div>
                            <div class="flex justify-between">
                                <dt class="text-sm font-medium text-gray-500">Status</dt>
                                <dd class="text-sm text-gray-900 capitalize"><?php echo $application['status']; ?></dd>
                            </div>
                            <div class="flex justify-between">
                                <dt class="text-sm font-medium text-gray-500">Submitted</dt>
                                <dd class="text-sm text-gray-900"><?php echo date('M j, Y', strtotime($application['submitted_at'])); ?></dd>
                            </div>
                            <?php if ($application['reviewed_at']): ?>
                            <div class="flex justify-between">
                                <dt class="text-sm font-medium text-gray-500">Last Review</dt>
                                <dd class="text-sm text-gray-900"><?php echo date('M j, Y', strtotime($application['reviewed_at'])); ?></dd>
                            </div>
                            <?php endif; ?>
                        </dl>
                    </div>
                </div>

                <!-- Notes -->
                <?php if ($application['notes']): ?>
                <div class="bg-white rounded-lg shadow-sm border">
                    <div class="px-6 py-4 border-b">
                        <h3 class="text-lg font-medium text-gray-900">Review Notes</h3>
                    </div>
                    <div class="p-6">
                        <p class="text-sm text-gray-700"><?php echo nl2br(htmlspecialchars($application['notes'])); ?></p>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Reject Modal -->
<div id="rejectModal" class="fixed inset-0 bg-black bg-opacity-50 hidden z-50">
    <div class="flex items-center justify-center min-h-screen p-4">
        <div class="bg-white rounded-lg max-w-md w-full p-6">
            <h3 class="text-lg font-medium text-gray-900 mb-4">Reject Application</h3>
            <form method="POST" action="/admin/applications/<?php echo $application['id']; ?>/reject">
                <input type="hidden" name="csrf_token" value="<?php echo CSRF::getToken(); ?>">
                
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Reason for Rejection *</label>
                    <textarea name="reason" rows="4" class="w-full border border-gray-300 rounded-md px-3 py-2 text-sm" 
                              placeholder="Please provide a detailed reason for rejecting this application..." required></textarea>
                </div>
                
                <div class="flex space-x-3">
                    <button type="button" onclick="hideRejectModal()" 
                            class="flex-1 bg-gray-300 text-gray-700 py-2 px-4 rounded-lg hover:bg-gray-400 transition-colors">
                        Cancel
                    </button>
                    <button type="submit" class="flex-1 bg-red-600 text-white py-2 px-4 rounded-lg hover:bg-red-700 transition-colors">
                        Reject Application
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function showRejectModal() {
    document.getElementById('rejectModal').classList.remove('hidden');
}

function hideRejectModal() {
    document.getElementById('rejectModal').classList.add('hidden');
}

// Close modal when clicking outside
document.getElementById('rejectModal').addEventListener('click', function(e) {
    if (e.target === this) hideRejectModal();
});
</script>