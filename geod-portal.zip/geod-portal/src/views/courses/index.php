<?php
$userRole = Session::getUserRole();
$userName = Session::get('username');
?>

<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $title; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style></style>

<div class="min-h-screen bg-gray-50">
    <!-- Header -->
    <div class="bg-white shadow-sm border-b">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center py-4">
                <div>
                    <h1 class="text-2xl font-bold text-gray-900">Available Courses</h1>
                    <p class="text-gray-600">Browse and enroll in courses for your level</p>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="/student/my-courses" class="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors">
                        My Courses
                    </a>
                    <a href="/dashboard" class="text-gray-600 hover:text-gray-900">← Back to Dashboard</a>
                </div>
            </div>
        </div>
    </div>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        <!-- Student Info -->
        <?php if (isset($student) && $student): ?>
        <div class="bg-white p-6 rounded-lg shadow-sm border mb-8">
            <div class="flex items-center justify-between">
                <div>
                    <h3 class="text-lg font-medium text-gray-900">Student Information</h3>
                    <div class="mt-2 grid grid-cols-1 md:grid-cols-3 gap-4 text-sm text-gray-600">
                        <div>
                            <span class="font-medium">Level:</span> <?php echo htmlspecialchars($student['level']); ?> Level
                        </div>
                        <div>
                            <span class="font-medium">Student ID:</span> <?php echo htmlspecialchars($student['student_id'] ?? 'Not assigned'); ?>
                        </div>
                        <div>
                            <span class="font-medium">Program:</span> <?php echo htmlspecialchars($student['program'] ?? 'Not assigned'); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Course Grid -->
        <?php if (empty($courses)): ?>
            <div class="text-center py-12">
                <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.746 0 3.332.477 4.5 1.253v13C19.832 18.477 18.246 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"></path>
                </svg>
                <h3 class="mt-2 text-sm font-medium text-gray-900">No courses available</h3>
                <p class="mt-1 text-sm text-gray-500">There are currently no courses available for your level.</p>
            </div>
        <?php else: ?>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <?php foreach ($courses as $course): ?>
                    <div class="bg-white rounded-lg shadow-sm border overflow-hidden">
                        <div class="p-6">
                            <div class="flex items-center justify-between mb-3">
                                <h3 class="text-lg font-medium text-gray-900">
                                    <?php echo htmlspecialchars($course['course_code']); ?>
                                </h3>
                                <span class="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-blue-100 text-blue-800">
                                    <?php echo $course['credits']; ?> Credits
                                </span>
                            </div>
                            
                            <h4 class="text-base font-medium text-gray-700 mb-2">
                                <?php echo htmlspecialchars($course['course_name']); ?>
                            </h4>
                            
                            <p class="text-sm text-gray-600 mb-4">
                                <?php echo htmlspecialchars($course['description'] ?? 'No description available'); ?>
                            </p>
                            
                            <div class="flex items-center text-sm text-gray-500 mb-4">
                                <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-4m-5 0H3m2 0h3M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 8h1m-1-4h1m4 4h1m-1-4h1"></path>
                                </svg>
                                <?php echo htmlspecialchars($course['department_name']); ?>
                            </div>
                            
                            <div class="flex items-center text-sm text-gray-500 mb-4">
                                <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path>
                                </svg>
                                <?php echo $course['enrolled_count']; ?>/<?php echo $course['max_students'] ?? '∞'; ?> Enrolled
                            </div>
                            
                            <div class="flex space-x-3">
                                <a href="/courses/<?php echo $course['id']; ?>" class="flex-1 bg-blue-600 text-white text-center py-2 px-3 rounded text-sm hover:bg-blue-700 transition-colors">
                                    View Details
                                </a>
                                
                                <?php if (in_array($course['id'], $enrolled_ids)): ?>
                                    <span class="flex-1 bg-green-100 text-green-800 text-center py-2 px-3 rounded text-sm font-medium">
                                        ✓ Enrolled
                                    </span>
                                <?php else: ?>
                                    <button onclick="enrollInCourse(<?php echo $course['id']; ?>)" 
                                            class="flex-1 bg-green-600 text-white py-2 px-3 rounded text-sm hover:bg-green-700 transition-colors">
                                        Enroll Now
                                    </button>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
        
        <!-- Quick Actions -->
        <div class="mt-12 bg-white p-6 rounded-lg shadow-sm border">
            <h3 class="text-lg font-medium text-gray-900 mb-4">Quick Actions</h3>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <a href="/student/my-courses" class="flex items-center p-4 border border-gray-200 rounded-lg hover:border-green-300 hover:shadow-sm transition-all">
                    <div class="p-2 bg-green-100 rounded-lg mr-3">
                        <svg class="w-5 h-5 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.746 0 3.332.477 4.5 1.253v13C19.832 18.477 18.246 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"></path>
                        </svg>
                    </div>
                    <div>
                        <p class="text-sm font-medium text-gray-900">My Courses</p>
                        <p class="text-xs text-gray-500">View enrolled courses</p>
                    </div>
                </a>
                
                <a href="/student/grades" class="flex items-center p-4 border border-gray-200 rounded-lg hover:border-green-300 hover:shadow-sm transition-all">
                    <div class="p-2 bg-blue-100 rounded-lg mr-3">
                        <svg class="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"></path>
                        </svg>
                    </div>
                    <div>
                        <p class="text-sm font-medium text-gray-900">View Grades</p>
                        <p class="text-xs text-gray-500">Academic records</p>
                    </div>
                </a>
                
                <a href="/payments/fees" class="flex items-center p-4 border border-gray-200 rounded-lg hover:border-green-300 hover:shadow-sm transition-all">
                    <div class="p-2 bg-purple-100 rounded-lg mr-3">
                        <svg class="w-5 h-5 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z"></path>
                        </svg>
                    </div>
                    <div>
                        <p class="text-sm font-medium text-gray-900">Fee Structure</p>
                        <p class="text-xs text-gray-500">View payment options</p>
                    </div>
                </a>
                
                <a href="/dashboard" class="flex items-center p-4 border border-gray-200 rounded-lg hover:border-green-300 hover:shadow-sm transition-all">
                    <div class="p-2 bg-gray-100 rounded-lg mr-3">
                        <svg class="w-5 h-5 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2H5a2 2 0 00-2-2z"></path>
                        </svg>
                    </div>
                    <div>
                        <p class="text-sm font-medium text-gray-900">Dashboard</p>
                        <p class="text-xs text-gray-500">Go to main dashboard</p>
                    </div>
                </a>
            </div>
        </div>
    </div>
</div>

<script>
function enrollInCourse(courseId) {
    if (!confirm('Are you sure you want to enroll in this course?')) {
        return;
    }
    
    const formData = new FormData();
    formData.append('csrf_token', '<?php echo CSRF::getToken(); ?>');
    
    fetch(`/student/enroll/${courseId}`, {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Successfully enrolled in course!');
            location.reload();
        } else {
            alert('Enrollment failed: ' + data.error);
        }
    })
    .catch(error => {
        console.error('Enrollment error:', error);
        alert('Enrollment failed. Please try again.');
    });
}
</script>