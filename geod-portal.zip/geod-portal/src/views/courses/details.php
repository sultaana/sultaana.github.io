<?php
$userRole = Session::getUserRole();
$userName = Session::get('username');
?>

<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $title; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style></style>

    
<div class="min-h-screen bg-gray-50">
    <!-- Header -->
    <div class="bg-white shadow-sm border-b">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center py-4">
                <div>
                    <h1 class="text-2xl font-bold text-gray-900"><?php echo htmlspecialchars($course['course_code']); ?></h1>
                    <p class="text-gray-600"><?php echo htmlspecialchars($course['course_name']); ?></p>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="/courses" class="text-gray-600 hover:text-gray-900">← Back to Courses</a>
                </div>
            </div>
        </div>
    </div>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <!-- Main Course Information -->
            <div class="lg:col-span-2">
                <!-- Course Overview -->
                <div class="bg-white rounded-lg shadow-sm border p-6 mb-8">
                    <h2 class="text-xl font-bold text-gray-900 mb-4">Course Overview</h2>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                        <div class="space-y-3">
                            <div class="flex justify-between">
                                <span class="text-gray-600">Course Code:</span>
                                <span class="font-medium"><?php echo htmlspecialchars($course['course_code']); ?></span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-gray-600">Credits:</span>
                                <span class="font-medium"><?php echo $course['credits']; ?></span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-gray-600">Level:</span>
                                <span class="font-medium"><?php echo $course['level']; ?> Level</span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-gray-600">Semester:</span>
                                <span class="font-medium capitalize"><?php echo $course['semester']; ?></span>
                            </div>
                        </div>
                        
                        <div class="space-y-3">
                            <div class="flex justify-between">
                                <span class="text-gray-600">Department:</span>
                                <span class="font-medium"><?php echo htmlspecialchars($course['department_name']); ?></span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-gray-600">Faculty:</span>
                                <span class="font-medium"><?php echo htmlspecialchars($course['faculty_name']); ?></span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-gray-600">Max Students:</span>
                                <span class="font-medium"><?php echo $course['max_students'] ?? 'Unlimited'; ?></span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-gray-600">Course Status:</span>
                                <span class="inline-flex px-2 py-1 text-xs font-semibold rounded-full <?php echo $course['status'] === 'active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'; ?>">
                                    <?php echo ucfirst($course['status']); ?>
                                </span>
                            </div>
                        </div>
                    </div>
                    
                    <?php if (!empty($course['description'])): ?>
                    <div class="border-t pt-6">
                        <h3 class="text-lg font-medium text-gray-900 mb-3">Course Description</h3>
                        <p class="text-gray-700 leading-relaxed">
                            <?php echo nl2br(htmlspecialchars($course['description'])); ?>
                        </p>
                    </div>
                    <?php endif; ?>
                </div>

                <!-- Course Content -->
                <div class="bg-white rounded-lg shadow-sm border p-6 mb-8">
                    <h3 class="text-lg font-medium text-gray-900 mb-4">Course Outline</h3>
                    
                    <?php if (!empty($course['outline'])): ?>
                        <div class="prose max-w-none text-gray-700">
                            <?php echo nl2br(htmlspecialchars($course['outline'])); ?>
                        </div>
                    <?php else: ?>
                        <p class="text-gray-500 italic">Course outline will be available soon.</p>
                    <?php endif; ?>
                </div>

                <!-- Prerequisites -->
                <?php if (!empty($course['prerequisites'])): ?>
                <div class="bg-white rounded-lg shadow-sm border p-6 mb-8">
                    <h3 class="text-lg font-medium text-gray-900 mb-3">Prerequisites</h3>
                    <div class="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                        <p class="text-yellow-800">
                            <?php echo nl2br(htmlspecialchars($course['prerequisites'])); ?>
                        </p>
                    </div>
                </div>
                <?php endif; ?>
            </div>
            
            <!-- Sidebar -->
            <div class="lg:col-span-1">
                <!-- Enrollment Status -->
                <div class="bg-white rounded-lg shadow-sm border p-6 mb-6">
                    <h3 class="text-lg font-medium text-gray-900 mb-4">Enrollment</h3>
                    
                    <div class="text-center mb-6">
                        <div class="text-3xl font-bold text-gray-900">
                            <?php echo $enrollment_stats['total_enrolled']; ?>
                        </div>
                        <div class="text-sm text-gray-600">Students Enrolled</div>
                    </div>
                    
                    <?php if ($is_enrolled): ?>
                        <div class="bg-green-100 text-green-800 text-center py-3 px-4 rounded-lg font-medium">
                            ✓ You are enrolled in this course
                        </div>
                        <div class="mt-4 text-center">
                            <a href="/student/my-courses" class="text-green-600 hover:text-green-800 text-sm font-medium">
                                View in My Courses →
                            </a>
                        </div>
                    <?php else: ?>
                        <?php if ($course['status'] === 'active'): ?>
                            <?php if (isset($course['max_students']) && $enrollment_stats['total_enrolled'] >= $course['max_students']): ?>
                                <div class="bg-red-100 text-red-800 text-center py-3 px-4 rounded-lg font-medium">
                                    Course is Full
                                </div>
                            <?php else: ?>
                                <button onclick="enrollInCourse(<?php echo $course['id']; ?>)" 
                                        class="w-full bg-green-600 text-white py-3 px-4 rounded-lg hover:bg-green-700 transition-colors font-medium">
                                    Enroll in Course
                                </button>
                            <?php endif; ?>
                        <?php else: ?>
                            <div class="bg-gray-100 text-gray-600 text-center py-3 px-4 rounded-lg font-medium">
                                Course Not Available
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>

                <!-- Course Information -->
                <div class="bg-white rounded-lg shadow-sm border p-6 mb-6">
                    <h3 class="text-lg font-medium text-gray-900 mb-4">Course Information</h3>
                    
                    <div class="space-y-3 text-sm">
                        <div class="flex items-center">
                            <svg class="w-4 h-4 text-gray-400 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                            </svg>
                            <span class="text-gray-600">Duration:</span>
                            <span class="ml-auto font-medium">1 Semester</span>
                        </div>
                        
                        <div class="flex items-center">
                            <svg class="w-4 h-4 text-gray-400 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                            </svg>
                            <span class="text-gray-600">Course Type:</span>
                            <span class="ml-auto font-medium capitalize"><?php echo $course['course_type'] ?? 'Core'; ?></span>
                        </div>
                        
                        <div class="flex items-center">
                            <svg class="w-4 h-4 text-gray-400 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path>
                            </svg>
                            <span class="text-gray-600">Class Size:</span>
                            <span class="ml-auto font-medium"><?php echo $enrollment_stats['total_enrolled']; ?><?php echo isset($course['max_students']) ? '/' . $course['max_students'] : ''; ?></span>
                        </div>
                    </div>
                </div>

                <!-- Quick Actions -->
                <div class="bg-white rounded-lg shadow-sm border p-6">
                    <h3 class="text-lg font-medium text-gray-900 mb-4">Quick Actions</h3>
                    
                    <div class="space-y-3">
                        <a href="/courses" class="block w-full text-center py-2 px-4 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors">
                            Browse All Courses
                        </a>
                        
                        <a href="/student/my-courses" class="block w-full text-center py-2 px-4 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors">
                            My Courses
                        </a>
                        
                        <a href="/student/grades" class="block w-full text-center py-2 px-4 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors">
                            View Grades
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function enrollInCourse(courseId) {
    if (!confirm('Are you sure you want to enroll in this course?')) {
        return;
    }
    
    const button = event.target;
    const originalText = button.textContent;
    button.textContent = 'Enrolling...';
    button.disabled = true;
    
    const formData = new FormData();
    formData.append('csrf_token', '<?php echo CSRF::getToken(); ?>');
    
    fetch(`/student/enroll/${courseId}`, {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Successfully enrolled in course!');
            location.reload();
        } else {
            alert('Enrollment failed: ' + data.error);
            button.textContent = originalText;
            button.disabled = false;
        }
    })
    .catch(error => {
        console.error('Enrollment error:', error);
        alert('Enrollment failed. Please try again.');
        button.textContent = originalText;
        button.disabled = false;
    });
}
</script>