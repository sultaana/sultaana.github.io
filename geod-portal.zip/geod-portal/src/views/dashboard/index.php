<?php
$userRole = $user_role ?? 'applicant';
$userName = $username ?? 'User';

$additionalStyles = '
<style>
    .dashboard-card {
        background: white;
        border-radius: 12px;
        border: 1px solid #f1f5f9;
        transition: border-color 0.2s ease;
    }
    .dashboard-card:hover {
        border-color: #e2e8f0;
    }
    .stat-card {
        background: #f8fafc;
        border: 1px solid #e2e8f0;
    }
    .stat-card.students {
        background: #fef7ff;
        border-color: #f3e8ff;
    }
    .stat-card.applications {
        background: #f0fdf4;
        border-color: #dcfce7;
    }
    .stat-card.pending {
        background: #fffbeb;
        border-color: #fed7aa;
    }
    .stat-card.revenue {
        background: #eff6ff;
        border-color: #dbeafe;
    }
    .nav-item {
        transition: background-color 0.15s ease;
    }
    .nav-item:hover {
        background-color: #f8fafc;
    }
    .subtle-shadow {
        box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.05);
    }
    .progress-bar {
        background: #3b82f6;
    }
    .icon-purple { color: #8b5cf6; }
    .icon-green { color: #10b981; }
    .icon-orange { color: #f59e0b; }
    .icon-blue { color: #3b82f6; }
    .text-purple { color: #8b5cf6; }
    .text-green { color: #10b981; }
    .text-orange { color: #f59e0b; }
    .text-blue { color: #3b82f6; }
    .bg-purple-light { background-color: #faf5ff; }
    .bg-green-light { background-color: #f0fdf4; }
    .bg-orange-light { background-color: #fffbeb; }
    .bg-blue-light { background-color: #eff6ff; }
</style>';

ob_start();
?>

<!-- Main Layout -->
<div class="min-h-screen bg-gray-50">
    <!-- Top Navigation -->
    <nav class="bg-white border-b border-gray-200">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center h-16">
                <div class="flex items-center">
                    <div class="flex-shrink-0">
                        <span class="text-xl font-semibold text-gray-900">GEOD UNIVERSITY</span>
                    </div>
                </div>
                
                <!-- Desktop Navigation -->
                <div class="hidden md:flex items-center space-x-8">
                    <?php if ($userRole === 'applicant'): ?>
                        <a href="/application" class="text-gray-600 hover:text-gray-900 transition-colors text-sm font-medium">Application</a>
                        <a href="/payments" class="text-gray-600 hover:text-gray-900 transition-colors text-sm font-medium">Payments</a>
                    <?php elseif ($userRole === 'student'): ?>
                        <a href="/courses" class="text-gray-600 hover:text-gray-900 transition-colors text-sm font-medium">Courses</a>
                        <a href="/student/grades" class="text-gray-600 hover:text-gray-900 transition-colors text-sm font-medium">Grades</a>
                        <a href="/payments" class="text-gray-600 hover:text-gray-900 transition-colors text-sm font-medium">Payments</a>
                    <?php elseif ($userRole === 'admin'): ?>
                        <a href="/admin/applications" class="text-gray-600 hover:text-gray-900 transition-colors text-sm font-medium">Applications</a>
                        <a href="/admin/students" class="text-gray-600 hover:text-gray-900 transition-colors text-sm font-medium">Students</a>
                        <a href="/admin/courses" class="text-gray-600 hover:text-gray-900 transition-colors text-sm font-medium">Courses</a>
                    <?php elseif ($userRole === 'faculty'): ?>
                        <a href="/faculty/courses" class="text-gray-600 hover:text-gray-900 transition-colors text-sm font-medium">My Courses</a>
                        <a href="/faculty/students" class="text-gray-600 hover:text-gray-900 transition-colors text-sm font-medium">Students</a>
                    <?php endif; ?>
                    <a href="/messages" class="text-gray-600 hover:text-gray-900 transition-colors text-sm font-medium">Messages</a>
                </div>
                
                <!-- User Profile -->
                <div class="flex items-center space-x-4">
                    <div class="text-right">
                        <p class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($userName); ?></p>
                        <p class="text-xs text-gray-500"><?php echo ucfirst($userRole); ?></p>
                    </div>
                    <div class="h-8 w-8 bg-gray-800 rounded-full flex items-center justify-center">
                        <span class="text-white text-sm font-medium"><?php echo strtoupper(substr($userName, 0, 1)); ?></span>
                    </div>
                    <a href="/auth/logout" class="text-gray-400 hover:text-gray-600 transition-colors">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path>
                        </svg>
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Header Section -->
    <div class="bg-white border-b border-gray-200">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
            <div class="text-center">
                <h1 class="text-4xl font-bold text-gray-900 mb-4">Welcome Back, <?php echo htmlspecialchars($userName); ?></h1>
                <p class="text-xl text-gray-600">
                    <?php if ($userRole === 'applicant'): ?>
                        Complete your university application journey
                    <?php elseif ($userRole === 'student'): ?>
                        Continue your academic excellence
                    <?php elseif ($userRole === 'admin'): ?>
                        Manage university operations
                    <?php else: ?>
                        Empower the next generation
                    <?php endif; ?>
                </p>
            </div>
        </div>
    </div>

    <!-- Flash Messages -->
    <?php if (Session::flash('success') || Session::flash('error')): ?>
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <?php if (Session::flash('success')): ?>
                <div class="bg-green-50 border border-green-200 p-4 rounded-lg">
                    <div class="flex">
                        <div class="flex-shrink-0">
                            <svg class="h-5 w-5 text-green-400" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path>
                            </svg>
                        </div>
                        <div class="ml-3">
                            <p class="text-sm font-medium text-green-800"><?php echo Session::flash('success'); ?></p>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <?php if (Session::flash('error')): ?>
                <div class="bg-red-50 border border-red-200 p-4 rounded-lg">
                    <div class="flex">
                        <div class="flex-shrink-0">
                            <svg class="h-5 w-5 text-red-400" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"></path>
                            </svg>
                        </div>
                        <div class="ml-3">
                            <p class="text-sm font-medium text-red-800"><?php echo Session::flash('error'); ?></p>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <!-- Main Dashboard Content -->
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        <?php if ($userRole === 'applicant'): ?>
            <!-- Applicant Dashboard -->
            <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <!-- Left Column -->
                <div class="lg:col-span-2 space-y-6">
                    <!-- Application Progress -->
                    <div class="dashboard-card subtle-shadow p-8">
                        <div class="flex items-center justify-between mb-8">
                            <h2 class="text-2xl font-semibold text-gray-900">Application Progress</h2>
                            <div class="flex items-center space-x-2">
                                <div class="w-2 h-2 bg-green-500 rounded-full"></div>
                                <span class="text-sm text-gray-600 font-medium">Active</span>
                            </div>
                        </div>
                        
                        <?php if ($has_application ?? false): ?>
                            <div class="space-y-6">
                                <div class="flex items-center justify-between">
                                    <span class="text-lg font-medium text-gray-900">Application Status</span>
                                    <span class="px-3 py-1 rounded-full text-sm font-medium <?php echo ($application['status'] ?? '') === 'approved' ? 'bg-green-100 text-green-800' : (($application['status'] ?? '') === 'pending' ? 'bg-yellow-100 text-yellow-800' : 'bg-gray-100 text-gray-800'); ?>">
                                        <?php echo ucfirst($application['status'] ?? 'Unknown'); ?>
                                    </span>
                                </div>
                                
                                <div class="bg-gray-100 rounded-full h-2">
                                    <div class="progress-bar h-2 rounded-full transition-all duration-300" style="width: <?php echo ($application['status'] ?? '') === 'approved' ? '100%' : (($application['status'] ?? '') === 'pending' ? '75%' : '50%'); ?>"></div>
                                </div>
                                
                                <div class="grid grid-cols-3 gap-4 text-center">
                                    <div>
                                        <div class="text-lg font-semibold text-green-600 mb-1">✓</div>
                                        <div class="text-sm text-gray-600 font-medium">Submitted</div>
                                    </div>
                                    <div>
                                        <div class="text-lg font-semibold mb-1 <?php echo in_array($application['status'] ?? '', ['pending', 'approved']) ? 'text-green-600' : 'text-gray-300'; ?>">
                                            <?php echo in_array($application['status'] ?? '', ['pending', 'approved']) ? '✓' : '○'; ?>
                                        </div>
                                        <div class="text-sm text-gray-600 font-medium">Under Review</div>
                                    </div>
                                    <div>
                                        <div class="text-lg font-semibold mb-1 <?php echo ($application['status'] ?? '') === 'approved' ? 'text-green-600' : 'text-gray-300'; ?>">
                                            <?php echo ($application['status'] ?? '') === 'approved' ? '✓' : '○'; ?>
                                        </div>
                                        <div class="text-sm text-gray-600 font-medium">Approved</div>
                                    </div>
                                </div>
                            </div>
                        <?php else: ?>
                            <div class="text-center py-12">
                                <div class="w-16 h-16 bg-gray-100 rounded-2xl flex items-center justify-center mx-auto mb-6">
                                    <svg class="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                                    </svg>
                                </div>
                                <h3 class="text-xl font-semibold text-gray-900 mb-2">Start Your Application</h3>
                                <p class="text-gray-600 mb-8 max-w-md mx-auto">Begin your journey to GEOD University by submitting your application.</p>
                                <a href="/application" class="inline-flex items-center px-6 py-3 bg-gray-900 text-white font-medium rounded-lg hover:bg-gray-800 transition-colors">
                                    <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path>
                                    </svg>
                                    Start Application
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>

                    <!-- Recent Activity -->
                    <div class="dashboard-card subtle-shadow p-8">
                        <h2 class="text-2xl font-semibold text-gray-900 mb-6">Recent Activity</h2>
                        <div class="space-y-4">
                            <div class="flex items-start space-x-4">
                                <div class="w-2 h-2 bg-blue-400 rounded-full mt-2 flex-shrink-0"></div>
                                <div>
                                    <p class="text-gray-900 font-medium">Account created</p>
                                    <p class="text-sm text-gray-500">Welcome to GEOD University Portal</p>
                                </div>
                            </div>
                            <?php if ($has_application ?? false): ?>
                            <div class="flex items-start space-x-4">
                                <div class="w-2 h-2 bg-green-400 rounded-full mt-2 flex-shrink-0"></div>
                                <div>
                                    <p class="text-gray-900 font-medium">Application submitted</p>
                                    <p class="text-sm text-gray-500">Your application is now under review</p>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- Right Sidebar -->
                <div class="space-y-6">
                    <!-- Quick Actions -->
                    <div class="dashboard-card subtle-shadow p-6">
                        <h3 class="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h3>
                        <div class="space-y-3">
                            <?php if (!($has_application ?? false)): ?>
                                <a href="/application" class="nav-item flex items-center p-4 rounded-lg border border-gray-200">
                                    <div class="w-10 h-10 bg-green-light rounded-xl flex items-center justify-center mr-4 flex-shrink-0">
                                        <svg class="w-5 h-5 icon-green" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                                        </svg>
                                    </div>
                                    <div>
                                        <p class="font-medium text-gray-900">Submit Application</p>
                                        <p class="text-sm text-gray-500">Start your university application</p>
                                    </div>
                                </a>
                            <?php else: ?>
                                <a href="/application/status" class="nav-item flex items-center p-4 rounded-lg border border-gray-200">
                                    <div class="w-10 h-10 bg-blue-light rounded-xl flex items-center justify-center mr-4 flex-shrink-0">
                                        <svg class="w-5 h-5 icon-blue" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v10a2 2 0 002 2h8a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"></path>
                                        </svg>
                                    </div>
                                    <div>
                                        <p class="font-medium text-gray-900">View Application</p>
                                        <p class="text-sm text-gray-500">Check application status</p>
                                    </div>
                                </a>
                            <?php endif; ?>
                            
                            <a href="/payments" class="nav-item flex items-center p-4 rounded-lg border border-gray-200">
                                <div class="w-10 h-10 bg-purple-light rounded-xl flex items-center justify-center mr-4 flex-shrink-0">
                                    <svg class="w-5 h-5 icon-purple" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z"></path>
                                    </svg>
                                </div>
                                <div>
                                    <p class="font-medium text-gray-900">Payments</p>
                                    <p class="text-sm text-gray-500">View payment history</p>
                                </div>
                            </a>
                        </div>
                    </div>

                    <!-- Support -->
                    <div class="dashboard-card subtle-shadow p-6">
                        <h3 class="text-lg font-semibold text-gray-900 mb-4">Need Help?</h3>
                        <p class="text-sm text-gray-600 mb-4">Our support team is here to help you with any questions about your application.</p>
                        <a href="/contact" class="inline-flex items-center text-sm font-medium text-blue-600 hover:text-blue-700 transition-colors">
                            Contact Support
                            <svg class="w-4 h-4 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
                            </svg>
                        </a>
                    </div>
                </div>
            </div>

        <?php elseif ($userRole === 'admin'): ?>
            <!-- Admin Dashboard -->
            <!-- Stats Cards -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                <div class="dashboard-card stat-card students subtle-shadow p-6">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-purple-600 text-sm font-medium mb-1">Total Students</p>
                            <p class="text-3xl font-bold text-gray-900"><?php echo $stats['total_students'] ?? 0; ?></p>
                        </div>
                        <div class="w-12 h-12 bg-purple-light rounded-xl flex items-center justify-center">
                            <svg class="w-6 h-6 icon-purple" fill="currentColor" viewBox="0 0 20 20">
                                <path d="M9 6a3 3 0 11-6 0 3 3 0 016 0zM17 6a3 3 0 11-6 0 3 3 0 016 0zM12.93 17c.046-.327.07-.66.07-1a6.97 6.97 0 00-1.5-4.33A5 5 0 0119 16v1h-6.07zM6 11a5 5 0 015 5v1H1v-1a5 5 0 015-5z"></path>
                            </svg>
                        </div>
                    </div>
                </div>
                
                <div class="dashboard-card stat-card applications subtle-shadow p-6">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-green-600 text-sm font-medium mb-1">Total Applications</p>
                            <p class="text-3xl font-bold text-gray-900"><?php echo $stats['total_applications'] ?? 0; ?></p>
                        </div>
                        <div class="w-12 h-12 bg-green-light rounded-xl flex items-center justify-center">
                            <svg class="w-6 h-6 icon-green" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M4 4a2 2 0 012-2h8a2 2 0 012 2v12a1 1 0 110 2h-3a1 1 0 01-1-1v-2a1 1 0 00-1-1H9a1 1 0 00-1 1v2a1 1 0 01-1 1H4a1 1 0 110-2V4zm3 1h2v2H7V5zm2 4H7v2h2V9zm2-4h2v2h-2V5zm2 4h-2v2h2V9z" clip-rule="evenodd"></path>
                            </svg>
                        </div>
                    </div>
                </div>
                
                <div class="dashboard-card stat-card pending subtle-shadow p-6">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-orange-600 text-sm font-medium mb-1">Pending Applications</p>
                            <p class="text-3xl font-bold text-gray-900"><?php echo $stats['pending_applications'] ?? 0; ?></p>
                        </div>
                        <div class="w-12 h-12 bg-orange-light rounded-xl flex items-center justify-center">
                            <svg class="w-6 h-6 icon-orange" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clip-rule="evenodd"></path>
                            </svg>
                        </div>
                    </div>
                </div>
                
                <div class="dashboard-card stat-card revenue subtle-shadow p-6">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-blue-600 text-sm font-medium mb-1">Total Revenue</p>
                            <p class="text-3xl font-bold text-gray-900">₦<?php echo number_format($stats['total_payments'] ?? 0, 0); ?></p>
                        </div>
                        <div class="w-12 h-12 bg-blue-light rounded-xl flex items-center justify-center">
                            <svg class="w-6 h-6 icon-blue" fill="currentColor" viewBox="0 0 20 20">
                                <path d="M4 4a2 2 0 00-2 2v1h16V6a2 2 0 00-2-2H4zM18 9H2v5a2 2 0 002 2h12a2 2 0 002-2V9zM4 13a1 1 0 011-1h1a1 1 0 110 2H5a1 1 0 01-1-1zm5-1a1 1 0 100 2h1a1 1 0 100-2H9z"></path>
                            </svg>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Recent Applications -->
            <?php if (!empty($pending_applications ?? [])): ?>
                <div class="dashboard-card subtle-shadow p-8">
                    <div class="flex items-center justify-between mb-6">
                        <h2 class="text-2xl font-semibold text-gray-900">Recent Applications</h2>
                        <a href="/admin/applications" class="text-blue-600 hover:text-blue-700 font-medium transition-colors">View All</a>
                    </div>
                    <div class="overflow-hidden">
                        <table class="min-w-full">
                            <thead>
                                <tr class="border-b border-gray-100">
                                    <th class="text-left py-4 text-sm font-medium text-gray-500">Applicant</th>
                                    <th class="text-left py-4 text-sm font-medium text-gray-500">Program</th>
                                    <th class="text-left py-4 text-sm font-medium text-gray-500">JAMB Score</th>
                                    <th class="text-left py-4 text-sm font-medium text-gray-500">Date</th>
                                    <th class="text-left py-4 text-sm font-medium text-gray-500">Action</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-50">
                                <?php foreach (array_slice($pending_applications, 0, 5) as $app): ?>
                                    <tr class="hover:bg-gray-25 transition-colors">
                                        <td class="py-4 text-sm font-medium text-gray-900"><?php echo htmlspecialchars($app['username']); ?></td>
                                        <td class="py-4 text-sm text-gray-600"><?php echo htmlspecialchars($app['program']); ?></td>
                                        <td class="py-4 text-sm text-gray-600"><?php echo $app['jamb_score']; ?></td>
                                        <td class="py-4 text-sm text-gray-500"><?php echo date('M j, Y', strtotime($app['submitted_at'])); ?></td>
                                        <td class="py-4">
                                            <a href="/admin/applications/<?php echo $app['id']; ?>" class="inline-flex items-center px-3 py-1 rounded-md text-xs font-medium bg-gray-100 text-gray-700 hover:bg-gray-200 transition-colors">
                                                Review
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php endif; ?>

        <?php else: ?>
            <!-- Student/Faculty Dashboard -->
            <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div class="lg:col-span-2">
                    <div class="dashboard-card subtle-shadow p-8">
                        <h2 class="text-2xl font-semibold text-gray-900 mb-6">
                            <?php echo $userRole === 'student' ? 'Academic Overview' : 'Faculty Portal'; ?>
                        </h2>
                        <p class="text-gray-600 mb-8">
                            <?php echo $userRole === 'student' ? 'Track your academic progress and course enrollment.' : 'Manage your courses and student interactions.'; ?>
                        </p>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <?php if ($userRole === 'student'): ?>
                                <a href="/courses" class="nav-item p-6 rounded-lg border border-gray-200">
                                    <h3 class="font-medium text-gray-900 mb-1">Browse Courses</h3>
                                    <p class="text-sm text-gray-500">Explore available courses</p>
                                </a>
                                <a href="/student/grades" class="nav-item p-6 rounded-lg border border-gray-200">
                                    <h3 class="font-medium text-gray-900 mb-1">View Grades</h3>
                                    <p class="text-sm text-gray-500">Check your academic performance</p>
                                </a>
                            <?php else: ?>
                                <a href="/faculty/courses" class="nav-item p-6 rounded-lg border border-gray-200">
                                    <h3 class="font-medium text-gray-900 mb-1">My Courses</h3>
                                    <p class="text-sm text-gray-500">Manage your courses</p>
                                </a>
                                <a href="/faculty/students" class="nav-item p-6 rounded-lg border border-gray-200">
                                    <h3 class="font-medium text-gray-900 mb-1">Students</h3>
                                    <p class="text-sm text-gray-500">View student information</p>
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <div>
                    <div class="dashboard-card subtle-shadow p-6">
                        <h3 class="text-lg font-semibold text-gray-900 mb-4">Quick Links</h3>
                        <div class="space-y-3">
                            <a href="/messages" class="nav-item flex items-center p-4 rounded-lg border border-gray-200">
                                <div class="w-10 h-10 bg-blue-light rounded-xl flex items-center justify-center mr-4 flex-shrink-0">
                                    <svg class="w-5 h-5 icon-blue" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"></path>
                                    </svg>
                                </div>
                                <div>
                                    <p class="font-medium text-gray-900">Messages</p>
                                    <p class="text-sm text-gray-500">Communication center</p>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php
$content = ob_get_clean();
include __DIR__ . '/../layouts/app.php';
?>