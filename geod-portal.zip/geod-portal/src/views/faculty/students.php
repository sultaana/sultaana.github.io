<?php
ob_start();
?>

<div class="min-h-screen bg-gray-50 py-8">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <!-- Header -->
        <div class="mb-8">
            <div class="flex items-center justify-between">
                <div>
                    <h1 class="text-3xl font-bold text-gray-900">My Students</h1>
                    <p class="mt-2 text-sm text-gray-600">Students enrolled in your courses</p>
                </div>
                <div class="flex items-center space-x-4">
                    <span class="px-3 py-1 bg-blue-100 text-blue-800 text-sm font-medium rounded-full">
                        <?= count($students) ?> Student<?= count($students) !== 1 ? 's' : '' ?>
                    </span>
                    <button class="bg-gray-100 hover:bg-gray-200 text-gray-700 px-4 py-2 rounded-md text-sm font-medium">
                        Export List
                    </button>
                </div>
            </div>
        </div>

        <!-- Search and Filter -->
        <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-8">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Search Students</label>
                    <input type="text" id="searchInput" placeholder="Search by name or student ID..." 
                           class="w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Filter by Level</label>
                    <select id="levelFilter" class="w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                        <option value="">All Levels</option>
                        <option value="100">100 Level</option>
                        <option value="200">200 Level</option>
                        <option value="300">300 Level</option>
                        <option value="400">400 Level</option>
                        <option value="500">500 Level</option>
                    </select>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Sort by</label>
                    <select id="sortFilter" class="w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                        <option value="student_id">Student ID</option>
                        <option value="name">Name</option>
                        <option value="level">Level</option>
                        <option value="gpa">GPA</option>
                        <option value="courses">Course Count</option>
                    </select>
                </div>
            </div>
        </div>

        <!-- Students List -->
        <?php if (empty($students)): ?>
            <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-12 text-center">
                <div class="mx-auto w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mb-4">
                    <svg class="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-3-3m-3 3z"></path>
                    </svg>
                </div>
                <h3 class="text-lg font-medium text-gray-900 mb-2">No Students Found</h3>
                <p class="text-gray-500">You don't have any students enrolled in your courses yet.</p>
            </div>
        <?php else: ?>
            <div class="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Student
                                </th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Level
                                </th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Enrolled Courses
                                </th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Total Enrollments
                                </th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Average GPA
                                </th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Actions
                                </th>
                            </tr>
                        </thead>
                        <tbody id="studentsTableBody" class="bg-white divide-y divide-gray-200">
                            <?php foreach ($students as $student): ?>
                                <tr class="hover:bg-gray-50 student-row" 
                                    data-name="<?= htmlspecialchars(strtolower($student['first_name'] . ' ' . $student['last_name'])) ?>"
                                    data-student-id="<?= htmlspecialchars(strtolower($student['student_id'])) ?>"
                                    data-level="<?= $student['level'] ?>"
                                    data-gpa="<?= $student['avg_gpa'] ?? 0 ?>"
                                    data-courses="<?= $student['total_enrollments'] ?>">
                                    
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="flex items-center">
                                            <div class="flex-shrink-0 h-12 w-12">
                                                <div class="h-12 w-12 rounded-full bg-blue-100 flex items-center justify-center">
                                                    <span class="text-sm font-medium text-blue-600">
                                                        <?= strtoupper(substr($student['first_name'], 0, 1) . substr($student['last_name'], 0, 1)) ?>
                                                    </span>
                                                </div>
                                            </div>
                                            <div class="ml-4">
                                                <div class="text-sm font-medium text-gray-900">
                                                    <?= htmlspecialchars($student['first_name'] . ' ' . $student['last_name']) ?>
                                                </div>
                                                <div class="text-sm text-gray-500">
                                                    <?= htmlspecialchars($student['student_id']) ?>
                                                </div>
                                                <div class="text-xs text-gray-400">
                                                    <?= htmlspecialchars($student['email']) ?>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <span class="px-2 py-1 text-xs font-medium rounded-full bg-gray-100 text-gray-800">
                                            <?= $student['level'] ?> Level
                                        </span>
                                    </td>
                                    
                                    <td class="px-6 py-4">
                                        <div class="text-sm text-gray-900">
                                            <?php if ($student['enrolled_courses']): ?>
                                                <?php 
                                                $courses = explode(',', $student['enrolled_courses']);
                                                $displayCourses = array_slice($courses, 0, 3);
                                                ?>
                                                <div class="flex flex-wrap gap-1">
                                                    <?php foreach ($displayCourses as $course): ?>
                                                        <span class="inline-block px-2 py-1 text-xs font-medium bg-blue-100 text-blue-800 rounded">
                                                            <?= htmlspecialchars(trim($course)) ?>
                                                        </span>
                                                    <?php endforeach; ?>
                                                    <?php if (count($courses) > 3): ?>
                                                        <span class="inline-block px-2 py-1 text-xs font-medium bg-gray-100 text-gray-600 rounded">
                                                            +<?= count($courses) - 3 ?> more
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            <?php else: ?>
                                                <span class="text-gray-400 italic">No courses</span>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                    
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                        <div class="flex items-center">
                                            <span class="font-medium text-lg"><?= $student['total_enrollments'] ?></span>
                                            <span class="ml-1 text-gray-500">course<?= $student['total_enrollments'] !== '1' ? 's' : '' ?></span>
                                        </div>
                                    </td>
                                    
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <?php if ($student['avg_gpa'] !== null): ?>
                                            <div class="flex items-center">
                                                <span class="font-medium text-lg 
                                                    <?= $student['avg_gpa'] >= 4.5 ? 'text-green-600' : 
                                                       ($student['avg_gpa'] >= 3.5 ? 'text-blue-600' : 
                                                       ($student['avg_gpa'] >= 2.5 ? 'text-yellow-600' : 'text-red-600')) ?>">
                                                    <?= number_format($student['avg_gpa'], 2) ?>
                                                </span>
                                                <span class="ml-1 text-gray-500">/5.0</span>
                                            </div>
                                            <div class="text-xs text-gray-400 mt-1">
                                                <?php 
                                                $gpa = $student['avg_gpa'];
                                                if ($gpa >= 4.5) echo 'Excellent';
                                                elseif ($gpa >= 3.5) echo 'Very Good';
                                                elseif ($gpa >= 2.5) echo 'Good';
                                                elseif ($gpa >= 1.5) echo 'Fair';
                                                else echo 'Poor';
                                                ?>
                                            </div>
                                        <?php else: ?>
                                            <span class="text-gray-400 italic">No grades</span>
                                        <?php endif; ?>
                                    </td>
                                    
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                        <div class="flex space-x-2">
                                            <button onclick="viewStudentDetails('<?= $student['id'] ?>')" 
                                                    class="text-blue-600 hover:text-blue-900">
                                                View Details
                                            </button>
                                            <button onclick="messageStudent('<?= $student['id'] ?>')" 
                                                    class="text-green-600 hover:text-green-900">
                                                Message
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- Pagination would go here if needed -->
                <div class="bg-gray-50 px-6 py-3 border-t border-gray-200">
                    <div class="text-sm text-gray-700">
                        Showing <span class="font-medium" id="showingCount"><?= count($students) ?></span> students
                    </div>
                </div>
            </div>

            <!-- Quick Stats -->
            <div class="mt-8 grid grid-cols-1 md:grid-cols-4 gap-6">
                <div class="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
                    <div class="text-center">
                        <div class="text-2xl font-bold text-blue-600">
                            <?= count($students) ?>
                        </div>
                        <div class="text-sm text-gray-600 mt-1">Total Students</div>
                    </div>
                </div>
                
                <div class="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
                    <div class="text-center">
                        <div class="text-2xl font-bold text-green-600">
                            <?= number_format(array_sum(array_column($students, 'avg_gpa')) / count($students), 2) ?>
                        </div>
                        <div class="text-sm text-gray-600 mt-1">Average GPA</div>
                    </div>
                </div>
                
                <div class="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
                    <div class="text-center">
                        <div class="text-2xl font-bold text-purple-600">
                            <?= array_sum(array_column($students, 'total_enrollments')) ?>
                        </div>
                        <div class="text-sm text-gray-600 mt-1">Total Enrollments</div>
                    </div>
                </div>
                
                <div class="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
                    <div class="text-center">
                        <div class="text-2xl font-bold text-orange-600">
                            <?= count(array_filter($students, function($s) { return $s['avg_gpa'] >= 4.0; })) ?>
                        </div>
                        <div class="text-sm text-gray-600 mt-1">High Performers</div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Scripts -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('searchInput');
    const levelFilter = document.getElementById('levelFilter');
    const sortFilter = document.getElementById('sortFilter');
    const tableBody = document.getElementById('studentsTableBody');
    const showingCount = document.getElementById('showingCount');
    
    let allRows = Array.from(document.querySelectorAll('.student-row'));
    
    function filterAndSort() {
        const searchTerm = searchInput.value.toLowerCase();
        const levelValue = levelFilter.value;
        const sortValue = sortFilter.value;
        
        // Filter rows
        let filteredRows = allRows.filter(row => {
            const matchesSearch = searchTerm === '' || 
                row.dataset.name.includes(searchTerm) || 
                row.dataset.studentId.includes(searchTerm);
            
            const matchesLevel = levelValue === '' || 
                row.dataset.level === levelValue;
            
            return matchesSearch && matchesLevel;
        });
        
        // Sort rows
        filteredRows.sort((a, b) => {
            switch (sortValue) {
                case 'name':
                    return a.dataset.name.localeCompare(b.dataset.name);
                case 'level':
                    return parseInt(a.dataset.level) - parseInt(b.dataset.level);
                case 'gpa':
                    return parseFloat(b.dataset.gpa) - parseFloat(a.dataset.gpa);
                case 'courses':
                    return parseInt(b.dataset.courses) - parseInt(a.dataset.courses);
                default: // student_id
                    return a.dataset.studentId.localeCompare(b.dataset.studentId);
            }
        });
        
        // Update display
        tableBody.innerHTML = '';
        filteredRows.forEach(row => tableBody.appendChild(row));
        showingCount.textContent = filteredRows.length;
    }
    
    searchInput.addEventListener('input', filterAndSort);
    levelFilter.addEventListener('change', filterAndSort);
    sortFilter.addEventListener('change', filterAndSort);
});

function viewStudentDetails(studentId) {
    // Implement student details modal or navigation
    alert('View student details feature would be implemented here for student ID: ' + studentId);
}

function messageStudent(studentId) {
    // Implement messaging feature
    window.location.href = '/messages/compose?to_student=' + studentId;
}
</script>

<?php
$content = ob_get_clean();
include __DIR__ . '/../layouts/app.php';
?>