<?php
$additionalStyles = '
<style>
    .dashboard-card {
        background: white;
        border-radius: 12px;
        border: 1px solid #f1f5f9;
        transition: border-color 0.2s ease, box-shadow 0.2s ease;
    }
    .dashboard-card:hover {
        border-color: #e2e8f0;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
    }
    .stat-card {
        background: #f8fafc;
        border: 1px solid #e2e8f0;
    }
    .stat-card.courses {
        background: #fef7ff;
        border-color: #f3e8ff;
    }
    .stat-card.students {
        background: #f0fdf4;
        border-color: #dcfce7;
    }
    .stat-card.grades {
        background: #fffbeb;
        border-color: #fed7aa;
    }
    .stat-card.completed {
        background: #eff6ff;
        border-color: #dbeafe;
    }
    .subtle-shadow {
        box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.05);
    }
    .icon-purple { color: #8b5cf6; }
    .icon-green { color: #10b981; }
    .icon-orange { color: #f59e0b; }
    .icon-blue { color: #3b82f6; }
    .bg-purple-light { background-color: #faf5ff; }
    .bg-green-light { background-color: #f0fdf4; }
    .bg-orange-light { background-color: #fffbeb; }
    .bg-blue-light { background-color: #eff6ff; }
    .nav-item {
        transition: all 0.2s ease;
    }
    .nav-item:hover {
        background-color: #f8fafc;
        transform: translateY(-1px);
    }
</style>';

ob_start();
?>

<!-- Main Layout -->
<div class="min-h-screen bg-gray-50">
    <!-- Top Navigation -->
    <nav class="bg-white border-b border-gray-200">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center h-16">
                <div class="flex items-center">
                    <div class="flex-shrink-0">
                        <span class="text-xl font-semibold text-gray-900">GEOD UNIVERSITY</span>
                    </div>
                </div>
                
                <!-- Desktop Navigation -->
                <div class="hidden md:flex items-center space-x-8">
                    <a href="/faculty/courses" class="text-gray-600 hover:text-gray-900 transition-colors text-sm font-medium">My Courses</a>
                    <a href="/faculty/students" class="text-gray-600 hover:text-gray-900 transition-colors text-sm font-medium">Students</a>
                    <a href="/messages" class="text-gray-600 hover:text-gray-900 transition-colors text-sm font-medium">Messages</a>
                </div>
                
                <!-- User Profile -->
                <div class="flex items-center space-x-4">
                    <div class="text-right">
                        <p class="text-sm font-medium text-gray-900"><?= htmlspecialchars($username ?? 'Faculty') ?></p>
                        <p class="text-xs text-gray-500">Faculty</p>
                    </div>
                    <div class="h-8 w-8 bg-gray-800 rounded-full flex items-center justify-center">
                        <span class="text-white text-sm font-medium"><?= strtoupper(substr($username ?? 'F', 0, 1)) ?></span>
                    </div>
                    <a href="/auth/logout" class="text-gray-400 hover:text-gray-600 transition-colors">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path>
                        </svg>
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Header Section -->
    <div class="bg-white border-b border-gray-200">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
            <div class="text-center">
                <h1 class="text-4xl font-bold text-gray-900 mb-4">Welcome Back, <?= htmlspecialchars($username ?? 'Faculty') ?></h1>
                <p class="text-xl text-gray-600">Empower the next generation through education</p>
                <?php if ($stats['pending_grades'] > 0): ?>
                    <div class="mt-4 inline-flex items-center px-4 py-2 bg-orange-100 text-orange-800 rounded-full text-sm font-medium">
                        <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.732-.833-2.464 0L3.34 16.5c-.77.833.192 2.5 1.732 2.5z"></path>
                        </svg>
                        <?= $stats['pending_grades'] ?> grade<?= $stats['pending_grades'] !== 1 ? 's' : '' ?> pending your attention
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Flash Messages -->
    <?php if (Session::flash('success') || Session::flash('error')): ?>
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <?php if (Session::flash('success')): ?>
                <div class="bg-green-50 border border-green-200 p-4 rounded-lg">
                    <div class="flex">
                        <div class="flex-shrink-0">
                            <svg class="h-5 w-5 text-green-400" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path>
                            </svg>
                        </div>
                        <div class="ml-3">
                            <p class="text-sm font-medium text-green-800"><?= Session::flash('success') ?></p>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <?php if (Session::flash('error')): ?>
                <div class="bg-red-50 border border-red-200 p-4 rounded-lg">
                    <div class="flex">
                        <div class="flex-shrink-0">
                            <svg class="h-5 w-5 text-red-400" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"></path>
                            </svg>
                        </div>
                        <div class="ml-3">
                            <p class="text-sm font-medium text-red-800"><?= Session::flash('error') ?></p>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <!-- Main Dashboard Content -->
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <!-- Stats Cards -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <!-- Total Courses -->
            <div class="dashboard-card stat-card courses subtle-shadow p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-purple-600 text-sm font-medium mb-1">Total Courses</p>
                        <p class="text-3xl font-bold text-gray-900"><?= $stats['total_courses'] ?></p>
                    </div>
                    <div class="w-12 h-12 bg-purple-light rounded-xl flex items-center justify-center">
                        <svg class="w-6 h-6 icon-purple" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.746 0 3.332.477 4.5 1.253v13C19.832 18.477 18.246 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"></path>
                        </svg>
                    </div>
                </div>
            </div>

            <!-- Total Students -->
            <div class="dashboard-card stat-card students subtle-shadow p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-green-600 text-sm font-medium mb-1">Total Students</p>
                        <p class="text-3xl font-bold text-gray-900"><?= $stats['total_students'] ?></p>
                    </div>
                    <div class="w-12 h-12 bg-green-light rounded-xl flex items-center justify-center">
                        <svg class="w-6 h-6 icon-green" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-3-3m-3 3z"></path>
                        </svg>
                    </div>
                </div>
            </div>

            <!-- Pending Grades -->
            <div class="dashboard-card stat-card grades subtle-shadow p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-orange-600 text-sm font-medium mb-1">Pending Grades</p>
                        <p class="text-3xl font-bold text-gray-900"><?= $stats['pending_grades'] ?></p>
                    </div>
                    <div class="w-12 h-12 bg-orange-light rounded-xl flex items-center justify-center">
                        <svg class="w-6 h-6 icon-orange" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v10a2 2 0 002 2h8a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4"></path>
                        </svg>
                    </div>
                </div>
            </div>

            <!-- Completed Enrollments -->
            <div class="dashboard-card stat-card completed subtle-shadow p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-blue-600 text-sm font-medium mb-1">Completed Enrollments</p>
                        <p class="text-3xl font-bold text-gray-900"><?= $stats['completed_courses'] ?></p>
                    </div>
                    <div class="w-12 h-12 bg-blue-light rounded-xl flex items-center justify-center">
                        <svg class="w-6 h-6 icon-blue" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                        </svg>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main Content Grid -->
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
            <!-- Left Column - Courses Overview -->
            <div class="lg:col-span-2 space-y-6">
                <!-- Assigned Courses Overview -->
                <div class="dashboard-card subtle-shadow overflow-hidden">
                    <div class="px-6 py-4 border-b border-gray-200">
                        <div class="flex items-center justify-between">
                            <h3 class="text-lg font-semibold text-gray-900">Your Assigned Courses</h3>
                            <span class="px-2 py-1 bg-gray-100 text-gray-600 text-xs rounded-full">
                                <?= count($assigned_courses) ?> course<?= count($assigned_courses) !== 1 ? 's' : '' ?>
                            </span>
                        </div>
                    </div>

                    <?php if (empty($assigned_courses)): ?>
                        <div class="p-12 text-center">
                            <div class="mx-auto w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mb-4">
                                <svg class="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.746 0 3.332.477 4.5 1.253v13C19.832 18.477 18.246 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"></path>
                                </svg>
                            </div>
                            <h3 class="text-lg font-medium text-gray-900 mb-2">No Courses Assigned</h3>
                            <p class="text-gray-500">You don't have any courses assigned yet. Contact administration for course assignments.</p>
                        </div>
                    <?php else: ?>
                        <div class="divide-y divide-gray-200 max-h-96 overflow-y-auto">
                            <?php foreach ($assigned_courses as $course): ?>
                                <div class="px-6 py-4 hover:bg-gray-50 transition-colors">
                                    <div class="flex items-center justify-between">
                                        <div class="flex-1">
                                            <div class="flex items-center space-x-3 mb-2">
                                                <h4 class="text-sm font-semibold text-gray-900">
                                                    <?= htmlspecialchars($course['course_code']) ?>
                                                </h4>
                                                <span class="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full font-medium">
                                                    <?= $course['credits'] ?> credits
                                                </span>
                                                <?php if ($course['status'] === 'active'): ?>
                                                    <span class="px-2 py-1 bg-green-100 text-green-800 text-xs rounded-full">Active</span>
                                                <?php endif; ?>
                                            </div>
                                            <h5 class="text-sm text-gray-700 mb-1 font-medium"><?= htmlspecialchars($course['course_name']) ?></h5>
                                            <p class="text-xs text-gray-500">Level <?= $course['level'] ?></p>
                                        </div>
                                        <div class="flex items-center space-x-4">
                                            <div class="text-center">
                                                <div class="text-lg font-bold text-blue-600"><?= $course['enrolled_count'] ?></div>
                                                <div class="text-xs text-gray-500">students</div>
                                            </div>
                                            <a href="/faculty/courses/<?= $course['id'] ?>" 
                                               class="inline-flex items-center px-3 py-1 bg-blue-600 hover:bg-blue-700 text-white text-xs font-medium rounded-md transition-colors">
                                                Manage
                                                <svg class="w-3 h-3 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
                                                </svg>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <div class="px-6 py-4 bg-gray-50 border-t border-gray-200">
                            <a href="/faculty/courses" class="inline-flex items-center text-blue-600 hover:text-blue-700 text-sm font-medium transition-colors">
                                View All Courses
                                <svg class="w-4 h-4 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
                                </svg>
                            </a>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Recent Enrollments -->
                <div class="dashboard-card subtle-shadow overflow-hidden">
                    <div class="px-6 py-4 border-b border-gray-200">
                        <div class="flex items-center justify-between">
                            <h3 class="text-lg font-semibold text-gray-900">Recent Enrollments</h3>
                            <span class="text-sm text-gray-500">Last 10 enrollments</span>
                        </div>
                    </div>

                    <?php if (empty($recent_enrollments)): ?>
                        <div class="p-12 text-center">
                            <div class="mx-auto w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mb-4">
                                <svg class="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-3-3m-3 3z"></path>
                                </svg>
                            </div>
                            <h4 class="text-lg font-medium text-gray-900 mb-2">No Recent Enrollments</h4>
                            <p class="text-gray-500">No students have enrolled in your courses recently.</p>
                        </div>
                    <?php else: ?>
                        <div class="divide-y divide-gray-200 max-h-80 overflow-y-auto">
                            <?php foreach ($recent_enrollments as $enrollment): ?>
                                <div class="px-6 py-4 hover:bg-gray-50 transition-colors">
                                    <div class="flex items-center justify-between">
                                        <div class="flex items-center space-x-4">
                                            <div class="flex-shrink-0">
                                                <div class="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                                                    <span class="text-sm font-medium text-blue-600">
                                                        <?= strtoupper(substr($enrollment['first_name'], 0, 1) . substr($enrollment['last_name'], 0, 1)) ?>
                                                    </span>
                                                </div>
                                            </div>
                                            <div>
                                                <h4 class="text-sm font-medium text-gray-900">
                                                    <?= htmlspecialchars($enrollment['first_name'] . ' ' . $enrollment['last_name']) ?>
                                                </h4>
                                                <p class="text-sm text-gray-500">
                                                    <span class="font-medium"><?= htmlspecialchars($enrollment['student_id']) ?></span> • 
                                                    enrolled in <span class="font-medium text-blue-600"><?= htmlspecialchars($enrollment['course_code']) ?></span>
                                                </p>
                                                <p class="text-xs text-gray-400">
                                                    <?= htmlspecialchars($enrollment['course_name']) ?>
                                                </p>
                                            </div>
                                        </div>
                                        <div class="text-right">
                                            <div class="text-sm font-medium text-gray-900">
                                                <?= date('M j, Y', strtotime($enrollment['enrolled_at'])) ?>
                                            </div>
                                            <div class="text-xs text-gray-500">
                                                <?= date('g:i A', strtotime($enrollment['enrolled_at'])) ?>
                                            </div>
                                            <span class="inline-block mt-1 px-2 py-1 bg-green-100 text-green-800 text-xs rounded-full">
                                                <?= ucfirst($enrollment['status']) ?>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <div class="px-6 py-4 bg-gray-50 border-t border-gray-200">
                            <a href="/faculty/students" class="inline-flex items-center text-blue-600 hover:text-blue-700 text-sm font-medium transition-colors">
                                View All Students
                                <svg class="w-4 h-4 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
                                </svg>
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Right Sidebar -->
            <div class="space-y-6">
                <!-- Quick Actions -->
                <div class="dashboard-card subtle-shadow p-6">
                    <h3 class="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h3>
                    <div class="space-y-3">
                        <a href="/faculty/courses" class="nav-item flex items-center p-4 rounded-lg border border-gray-200 hover:bg-gray-50 transition-all group">
                            <div class="w-10 h-10 bg-purple-light rounded-xl flex items-center justify-center mr-4 flex-shrink-0 group-hover:bg-purple-200 transition-colors">
                                <svg class="w-5 h-5 icon-purple" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.746 0 3.332.477 4.5 1.253v13C19.832 18.477 18.246 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"></path>
                                </svg>
                            </div>
                            <div>
                                <p class="font-medium text-gray-900">Manage Courses</p>
                                <p class="text-sm text-gray-500">View and manage your assigned courses</p>
                            </div>
                        </a>
                        
                        <a href="/faculty/students" class="nav-item flex items-center p-4 rounded-lg border border-gray-200 hover:bg-gray-50 transition-all group">
                            <div class="w-10 h-10 bg-green-light rounded-xl flex items-center justify-center mr-4 flex-shrink-0 group-hover:bg-green-200 transition-colors">
                                <svg class="w-5 h-5 icon-green" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-3-3m-3 3z"></path>
                                </svg>
                            </div>
                            <div>
                                <p class="font-medium text-gray-900">View Students</p>
                                <p class="text-sm text-gray-500">Access student information and grades</p>
                            </div>
                        </a>
                        
                        <a href="/messages" class="nav-item flex items-center p-4 rounded-lg border border-gray-200 hover:bg-gray-50 transition-all group">
                            <div class="w-10 h-10 bg-blue-light rounded-xl flex items-center justify-center mr-4 flex-shrink-0 group-hover:bg-blue-200 transition-colors">
                                <svg class="w-5 h-5 icon-blue" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"></path>
                                </svg>
                            </div>
                            <div>
                                <p class="font-medium text-gray-900">Messages</p>
                                <p class="text-sm text-gray-500">Communication center</p>
                            </div>
                        </a>
                    </div>
                </div>

                <!-- Grading Overview -->
                <?php if (!empty($assigned_courses)): ?>
                    <div class="dashboard-card subtle-shadow p-6">
                        <h3 class="text-lg font-semibold text-gray-900 mb-4">Grading Overview</h3>
                        <div class="space-y-4">
                            <?php 
                            $totalEnrollments = $stats['total_students'] + $stats['completed_courses'];
                            $gradedPercentage = $totalEnrollments > 0 ? ($stats['completed_courses'] / $totalEnrollments) * 100 : 0;
                            $pendingPercentage = $totalEnrollments > 0 ? ($stats['pending_grades'] / $totalEnrollments) * 100 : 0;
                            ?>
                            
                            <div class="space-y-3">
                                <div class="flex items-center justify-between text-sm">
                                    <span class="font-medium text-gray-700">Graded</span>
                                    <span class="text-green-600 font-semibold"><?= $stats['completed_courses'] ?></span>
                                </div>
                                <div class="w-full bg-gray-200 rounded-full h-2">
                                    <div class="bg-green-600 h-2 rounded-full transition-all duration-300" style="width: <?= $gradedPercentage ?>%"></div>
                                </div>
                                
                                <div class="flex items-center justify-between text-sm">
                                    <span class="font-medium text-gray-700">Pending</span>
                                    <span class="text-orange-600 font-semibold"><?= $stats['pending_grades'] ?></span>
                                </div>
                                <div class="w-full bg-gray-200 rounded-full h-2">
                                    <div class="bg-orange-500 h-2 rounded-full transition-all duration-300" style="width: <?= $pendingPercentage ?>%"></div>
                                </div>
                            </div>
                            
                            <div class="pt-4 mt-4 border-t border-gray-200 text-center">
                                <div class="text-2xl font-bold text-gray-900"><?= $totalEnrollments ?></div>
                                <div class="text-sm text-gray-500">Total Enrollments</div>
                                <?php if ($stats['pending_grades'] > 0): ?>
                                    <a href="/faculty/courses" class="mt-2 inline-flex items-center text-sm text-orange-600 hover:text-orange-700 font-medium">
                                        Grade Students
                                        <svg class="w-4 h-4 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
                                        </svg>
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <!-- Performance Summary -->
                <div class="dashboard-card subtle-shadow p-6">
                    <h3 class="text-lg font-semibold text-gray-900 mb-4">At a Glance</h3>
                    <div class="space-y-4">
                        <div class="flex items-center justify-between">
                            <div class="flex items-center space-x-3">
                                <div class="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
                                    <svg class="w-4 h-4 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.746 0 3.332.477 4.5 1.253v13C19.832 18.477 18.246 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"></path>
                                    </svg>
                                </div>
                                <span class="text-sm font-medium text-gray-700">Active Courses</span>
                            </div>
                            <span class="text-lg font-bold text-gray-900"><?= $stats['total_courses'] ?></span>
                        </div>
                        
                        <div class="flex items-center justify-between">
                            <div class="flex items-center space-x-3">
                                <div class="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                                    <svg class="w-4 h-4 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path>
                                    </svg>
                                </div>
                                <span class="text-sm font-medium text-gray-700">Students</span>
                            </div>
                            <span class="text-lg font-bold text-gray-900"><?= $stats['total_students'] ?></span>
                        </div>
                        
                        <?php if ($stats['pending_grades'] > 0): ?>
                            <div class="flex items-center justify-between p-3 bg-orange-50 rounded-lg border border-orange-200">
                                <div class="flex items-center space-x-3">
                                    <div class="w-8 h-8 bg-orange-100 rounded-full flex items-center justify-center">
                                        <svg class="w-4 h-4 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.732-.833-2.464 0L3.34 16.5c-.77.833.192 2.5 1.732 2.5z"></path>
                                        </svg>
                                    </div>
                                    <span class="text-sm font-medium text-orange-700">Action Needed</span>
                                </div>
                                <span class="text-lg font-bold text-orange-900"><?= $stats['pending_grades'] ?></span>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
$content = ob_get_clean();
include __DIR__ . '/../layouts/app.php';
?>