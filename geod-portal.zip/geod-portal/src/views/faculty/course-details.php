<?php
ob_start();
?>

<div class="min-h-screen bg-gray-50 py-8">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <!-- Header -->
        <div class="mb-8">
            <div class="flex items-center mb-4">
                <a href="/faculty/courses" class="text-blue-600 hover:text-blue-800 flex items-center">
                    <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path>
                    </svg>
                    Back to Courses
                </a>
            </div>
            <div class="flex items-center justify-between">
                <div>
                    <h1 class="text-3xl font-bold text-gray-900"><?= htmlspecialchars($course['course_code']) ?></h1>
                    <h2 class="text-xl text-gray-600 mt-1"><?= htmlspecialchars($course['course_name']) ?></h2>
                    <p class="mt-2 text-sm text-gray-500">
                        <?= htmlspecialchars($course['department_name']) ?> • <?= htmlspecialchars($course['faculty_name']) ?>
                    </p>
                </div>
                <div class="text-right">
                    <div class="text-sm text-gray-500 mb-2">
                        <span class="font-medium">Credits:</span> <?= $course['credits'] ?> • 
                        <span class="font-medium">Level:</span> <?= $course['level'] ?>
                    </div>
                    <span class="px-3 py-1 bg-green-100 text-green-800 text-sm font-medium rounded-full">
                        <?= ucfirst($course['status']) ?>
                    </span>
                </div>
            </div>
        </div>

        <?php if (!empty($course['description'])): ?>
        <!-- Course Description -->
        <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-8">
            <h3 class="text-lg font-semibold text-gray-900 mb-3">Course Description</h3>
            <p class="text-gray-700"><?= htmlspecialchars($course['description']) ?></p>
        </div>
        <?php endif; ?>

        <!-- Students Section -->
        <div class="bg-white rounded-lg shadow-sm border border-gray-200">
            <div class="px-6 py-4 border-b border-gray-200">
                <div class="flex items-center justify-between">
                    <h3 class="text-lg font-semibold text-gray-900">
                        Enrolled Students (<?= count($students) ?>)
                    </h3>
                    <?php if (!empty($students)): ?>
                        <div class="flex items-center space-x-3">
                            <button id="bulkGradeBtn" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md text-sm font-medium">
                                Submit Grades
                            </button>
                            <button id="exportBtn" class="bg-gray-100 hover:bg-gray-200 text-gray-700 px-4 py-2 rounded-md text-sm font-medium">
                                Export List
                            </button>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <?php if (empty($students)): ?>
                <div class="p-12 text-center">
                    <div class="mx-auto w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mb-4">
                        <svg class="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-3-3m-3 3z"></path>
                        </svg>
                    </div>
                    <h4 class="text-lg font-medium text-gray-900 mb-2">No Students Enrolled</h4>
                    <p class="text-gray-500">No students have enrolled in this course yet.</p>
                </div>
            <?php else: ?>
                <form id="gradesForm" class="overflow-hidden">
                    <input type="hidden" name="csrf_token" value="<?= CSRF::generateToken() ?>">
                    
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Student
                                    </th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Level
                                    </th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Status
                                    </th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Current Grade
                                    </th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        New Grade
                                    </th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Enrolled Date
                                    </th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                <?php foreach ($students as $student): ?>
                                    <tr class="hover:bg-gray-50">
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <div class="flex items-center">
                                                <div class="flex-shrink-0 h-10 w-10">
                                                    <div class="h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center">
                                                        <span class="text-sm font-medium text-blue-600">
                                                            <?= strtoupper(substr($student['first_name'], 0, 1) . substr($student['last_name'], 0, 1)) ?>
                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="ml-4">
                                                    <div class="text-sm font-medium text-gray-900">
                                                        <?= htmlspecialchars($student['first_name'] . ' ' . $student['last_name']) ?>
                                                    </div>
                                                    <div class="text-sm text-gray-500">
                                                        <?= htmlspecialchars($student['student_id']) ?> • <?= htmlspecialchars($student['email']) ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                            <?= $student['level'] ?>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                                                <?= $student['enrollment_status'] === 'enrolled' ? 'bg-green-100 text-green-800' : 
                                                   ($student['enrollment_status'] === 'completed' ? 'bg-blue-100 text-blue-800' : 'bg-yellow-100 text-yellow-800') ?>">
                                                <?= ucfirst($student['enrollment_status']) ?>
                                            </span>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                            <?php if ($student['grade']): ?>
                                                <div class="flex items-center">
                                                    <span class="font-medium text-lg mr-2"><?= htmlspecialchars($student['grade']) ?></span>
                                                    <span class="text-sm text-gray-500">(<?= number_format($student['grade_point'], 1) ?> pts)</span>
                                                </div>
                                            <?php else: ?>
                                                <span class="text-gray-400 italic">Not graded</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <select name="grades[<?= $student['id'] ?>][grade]" 
                                                    class="grade-select border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                                                <option value="">Select Grade</option>
                                                <option value="A" <?= $student['grade'] === 'A' ? 'selected' : '' ?>>A (5.0)</option>
                                                <option value="B" <?= $student['grade'] === 'B' ? 'selected' : '' ?>>B (4.0)</option>
                                                <option value="C" <?= $student['grade'] === 'C' ? 'selected' : '' ?>>C (3.0)</option>
                                                <option value="D" <?= $student['grade'] === 'D' ? 'selected' : '' ?>>D (2.0)</option>
                                                <option value="E" <?= $student['grade'] === 'E' ? 'selected' : '' ?>>E (1.0)</option>
                                                <option value="F" <?= $student['grade'] === 'F' ? 'selected' : '' ?>>F (0.0)</option>
                                            </select>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                            <?= date('M j, Y', strtotime($student['enrolled_at'])) ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- Grade Submission Footer -->
                    <div class="bg-gray-50 px-6 py-4 border-t border-gray-200">
                        <div class="flex items-center justify-between">
                            <div class="text-sm text-gray-600">
                                <span id="gradeCount">0</span> grade(s) ready to submit
                            </div>
                            <div class="flex items-center space-x-3">
                                <button type="button" id="clearGrades" class="text-gray-600 hover:text-gray-800 text-sm">
                                    Clear All
                                </button>
                                <button type="submit" id="submitGrades" 
                                        class="bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded-md text-sm font-medium disabled:bg-gray-300 disabled:cursor-not-allowed" 
                                        disabled>
                                    Submit Grades
                                </button>
                            </div>
                        </div>
                    </div>
                </form>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Scripts -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    const gradeSelects = document.querySelectorAll('.grade-select');
    const gradeCount = document.getElementById('gradeCount');
    const submitBtn = document.getElementById('submitGrades');
    const clearBtn = document.getElementById('clearGrades');
    const form = document.getElementById('gradesForm');

    function updateGradeCount() {
        const selectedGrades = Array.from(gradeSelects).filter(select => select.value !== '').length;
        gradeCount.textContent = selectedGrades;
        submitBtn.disabled = selectedGrades === 0;
    }

    gradeSelects.forEach(select => {
        select.addEventListener('change', updateGradeCount);
    });

    clearBtn.addEventListener('click', function() {
        if (confirm('Are you sure you want to clear all grade selections?')) {
            gradeSelects.forEach(select => select.value = '');
            updateGradeCount();
        }
    });

    form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const selectedGrades = Array.from(gradeSelects).filter(select => select.value !== '').length;
        if (selectedGrades === 0) {
            alert('Please select at least one grade to submit.');
            return;
        }

        if (!confirm(`Are you sure you want to submit ${selectedGrades} grade(s)? This action cannot be undone.`)) {
            return;
        }

        submitBtn.disabled = true;
        submitBtn.textContent = 'Submitting...';

        const formData = new FormData(form);
        
        fetch('/faculty/courses/<?= $course['id'] ?>/grades', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert(data.message || 'Grades submitted successfully!');
                location.reload();
            } else {
                alert(data.error || 'Failed to submit grades. Please try again.');
                submitBtn.disabled = false;
                submitBtn.textContent = 'Submit Grades';
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while submitting grades. Please try again.');
            submitBtn.disabled = false;
            submitBtn.textContent = 'Submit Grades';
        });
    });

    // Initial count update
    updateGradeCount();
});
</script>

<?php
$content = ob_get_clean();
include __DIR__ . '/../layouts/app.php';
?>