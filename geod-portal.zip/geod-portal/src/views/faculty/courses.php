<?php
ob_start();
?>

<div class="min-h-screen bg-gray-50 py-8">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <!-- Header -->
        <div class="mb-8">
            <div class="flex items-center justify-between">
                <div>
                    <h1 class="text-3xl font-bold text-gray-900">My Courses</h1>
                    <p class="mt-2 text-sm text-gray-600">Manage your assigned courses and students</p>
                </div>
                <div class="flex items-center space-x-4">
                    <span class="px-3 py-1 bg-blue-100 text-blue-800 text-sm font-medium rounded-full">
                        <?= count($courses) ?> Course<?= count($courses) !== 1 ? 's' : '' ?>
                    </span>
                </div>
            </div>
        </div>

        <!-- Courses Grid -->
        <?php if (empty($courses)): ?>
            <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-12 text-center">
                <div class="mx-auto w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mb-4">
                    <svg class="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.746 0 3.332.477 4.5 1.253v13C19.832 18.477 18.246 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"></path>
                    </svg>
                </div>
                <h3 class="text-lg font-medium text-gray-900 mb-2">No Courses Assigned</h3>
                <p class="text-gray-500">You don't have any courses assigned yet. Contact administration for course assignments.</p>
            </div>
        <?php else: ?>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <?php foreach ($courses as $course): ?>
                    <div class="bg-white rounded-lg shadow-sm border border-gray-200 hover:shadow-md transition-shadow duration-200">
                        <!-- Course Header -->
                        <div class="p-6 pb-4">
                            <div class="flex items-start justify-between mb-4">
                                <div class="flex-1">
                                    <h3 class="text-lg font-semibold text-gray-900 mb-1">
                                        <?= htmlspecialchars($course['course_code']) ?>
                                    </h3>
                                    <h4 class="text-sm font-medium text-gray-700 mb-2">
                                        <?= htmlspecialchars($course['course_name']) ?>
                                    </h4>
                                </div>
                                <span class="px-2 py-1 bg-green-100 text-green-800 text-xs font-medium rounded-full">
                                    <?= $course['status'] ?>
                                </span>
                            </div>
                            
                            <div class="text-sm text-gray-600 space-y-1">
                                <p><span class="font-medium">Department:</span> <?= htmlspecialchars($course['department_name']) ?></p>
                                <p><span class="font-medium">Faculty:</span> <?= htmlspecialchars($course['faculty_name']) ?></p>
                                <p><span class="font-medium">Credits:</span> <?= $course['credits'] ?></p>
                                <p><span class="font-medium">Level:</span> <?= $course['level'] ?></p>
                            </div>
                        </div>

                        <!-- Course Stats -->
                        <div class="px-6 py-4 bg-gray-50 border-t border-gray-100">
                            <div class="grid grid-cols-2 gap-4 text-sm">
                                <div class="text-center">
                                    <div class="font-semibold text-blue-600 text-lg">
                                        <?= $course['enrolled_count'] ?>
                                    </div>
                                    <div class="text-gray-600">Students</div>
                                </div>
                                <div class="text-center">
                                    <div class="font-semibold text-orange-600 text-lg">
                                        <?= $course['pending_grades'] ?>
                                    </div>
                                    <div class="text-gray-600">Pending Grades</div>
                                </div>
                            </div>
                        </div>

                        <!-- Course Actions -->
                        <div class="px-6 py-4 border-t border-gray-100">
                            <div class="flex space-x-3">
                                <a href="/faculty/courses/<?= $course['id'] ?>" 
                                   class="flex-1 bg-blue-600 hover:bg-blue-700 text-white text-center py-2 px-4 rounded-md text-sm font-medium transition-colors">
                                    Manage Course
                                </a>
                                <?php if ($course['enrolled_count'] > 0): ?>
                                    <a href="/faculty/courses/<?= $course['id'] ?>/students" 
                                       class="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-700 text-center py-2 px-4 rounded-md text-sm font-medium transition-colors">
                                        View Students
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <!-- Summary Stats -->
            <div class="mt-8 grid grid-cols-1 md:grid-cols-4 gap-6">
                <div class="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
                    <div class="text-center">
                        <div class="text-2xl font-bold text-blue-600">
                            <?= count($courses) ?>
                        </div>
                        <div class="text-sm text-gray-600 mt-1">Total Courses</div>
                    </div>
                </div>
                
                <div class="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
                    <div class="text-center">
                        <div class="text-2xl font-bold text-green-600">
                            <?= array_sum(array_column($courses, 'enrolled_count')) ?>
                        </div>
                        <div class="text-sm text-gray-600 mt-1">Total Students</div>
                    </div>
                </div>
                
                <div class="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
                    <div class="text-center">
                        <div class="text-2xl font-bold text-orange-600">
                            <?= array_sum(array_column($courses, 'pending_grades')) ?>
                        </div>
                        <div class="text-sm text-gray-600 mt-1">Pending Grades</div>
                    </div>
                </div>
                
                <div class="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
                    <div class="text-center">
                        <div class="text-2xl font-bold text-purple-600">
                            <?= array_sum(array_column($courses, 'credits')) ?>
                        </div>
                        <div class="text-sm text-gray-600 mt-1">Total Credits</div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php
$content = ob_get_clean();
include __DIR__ . '/../layouts/app.php';
?>