<?php
http_response_code(500);
include_once __DIR__ . '/../layouts/header.php';
?>

<div class="container">
    <h1>500 Internal Server Error</h1>
    <p>Oops! Something went wrong on our end. Please try again later.</p>
</div>

<?php
include_once __DIR__ . '/../layouts/footer.php';