<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Page Not Found - GEOD University</title>
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
</head>
<body class="bg-gray-50 min-h-screen flex items-center justify-center">
    <div class="max-w-md w-full text-center">
        <div class="bg-white p-8 rounded-lg shadow-md">
            <div class="text-6xl font-bold text-red-500 mb-4">404</div>
            <h1 class="text-2xl font-bold text-gray-900 mb-4">Page Not Found</h1>
            <p class="text-gray-600 mb-6">The page you are looking for does not exist or has been moved.</p>
            
            <div class="space-y-4">
                <a href="/" class="inline-block bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition-colors">
                    Go Home
                </a>
                <div class="text-sm text-gray-500">
                    <a href="/auth/login" class="text-green-600 hover:text-green-800">Login</a>
                    |
                    <a href="/auth/register" class="text-green-600 hover:text-green-800">Register</a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>