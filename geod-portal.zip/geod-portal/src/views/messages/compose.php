<?php
$userRole = Session::getUserRole();
$userName = Session::get('username');
?>


<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $title; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style></style>

<div class="min-h-screen bg-gray-50">
    <!-- Header -->
    <div class="bg-white shadow-sm border-b">
        <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center py-4">
                <div>
                    <h1 class="text-2xl font-bold text-gray-900">Compose Message</h1>
                    <p class="text-gray-600">Send a new message</p>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="/messages" class="text-gray-600 hover:text-gray-900">← Back to Messages</a>
                </div>
            </div>
        </div>
    </div>

    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        <div class="bg-white rounded-lg shadow-sm border">
            <form method="POST" action="/messages/send" class="p-6 space-y-6">
                <input type="hidden" name="csrf_token" value="<?php echo CSRF::getToken(); ?>">
                <input type="hidden" name="message_type" value="personal">
                
                <!-- Recipient Selection -->
                <div>
                    <label for="receiver_id" class="block text-sm font-medium text-gray-700 mb-2">
                        Send To *
                    </label>
                    <select name="receiver_id" id="receiver_id" required 
                            class="w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                        <option value="">Select recipient...</option>
                        <?php
                        $currentGroup = '';
                        foreach ($recipients as $recipient):
                            if ($currentGroup !== $recipient['role']):
                                if ($currentGroup !== '') echo '</optgroup>';
                                $currentGroup = $recipient['role'];
                                echo '<optgroup label="' . htmlspecialchars(ucfirst($recipient['role']) . 's') . '">';
                            endif;
                        ?>
                            <option value="<?php echo $recipient['id']; ?>" 
                                    <?php echo ($reply_to && $reply_to == $recipient['id']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($recipient['username']); ?>
                                (<?php echo ucfirst($recipient['role']); ?>)
                            </option>
                        <?php endforeach; ?>
                        <?php if ($currentGroup !== '') echo '</optgroup>'; ?>
                    </select>
                    <p class="mt-1 text-xs text-gray-500">
                        <?php if ($userRole === 'admin'): ?>
                            As an admin, you can message anyone.
                        <?php elseif ($userRole === 'faculty'): ?>
                            You can message students and administrators.
                        <?php else: ?>
                            You can message faculty members and administrators.
                        <?php endif; ?>
                    </p>
                </div>

                <!-- Subject -->
                <div>
                    <label for="subject" class="block text-sm font-medium text-gray-700 mb-2">
                        Subject *
                    </label>
                    <input type="text" name="subject" id="subject" required
                           class="w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                           placeholder="Enter message subject...">
                </div>

                <!-- Message Content -->
                <div>
                    <label for="message" class="block text-sm font-medium text-gray-700 mb-2">
                        Message *
                    </label>
                    <textarea name="message" id="message" rows="8" required
                              class="w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                              placeholder="Type your message here..."></textarea>
                    <p class="mt-1 text-xs text-gray-500">
                        Be clear and professional in your communication.
                    </p>
                </div>

                <!-- Message Options -->
                <div class="bg-gray-50 p-4 rounded-lg">
                    <h3 class="text-sm font-medium text-gray-900 mb-3">Message Options</h3>
                    <div class="flex items-center space-x-6">
                        <label class="flex items-center">
                            <input type="checkbox" id="urgent" class="rounded border-gray-300 text-blue-600 focus:ring-blue-500">
                            <span class="ml-2 text-sm text-gray-700">Mark as urgent</span>
                        </label>
                        
                        <label class="flex items-center">
                            <input type="checkbox" id="requestReceipt" class="rounded border-gray-300 text-blue-600 focus:ring-blue-500">
                            <span class="ml-2 text-sm text-gray-700">Request read receipt</span>
                        </label>
                    </div>
                </div>

                <!-- Actions -->
                <div class="flex items-center justify-between pt-6 border-t">
                    <div class="flex items-center space-x-4">
                        <button type="button" onclick="saveDraft()" 
                                class="text-gray-600 hover:text-gray-800 text-sm font-medium">
                            Save as Draft
                        </button>
                        
                        <button type="button" onclick="previewMessage()" 
                                class="text-blue-600 hover:text-blue-800 text-sm font-medium">
                            Preview
                        </button>
                    </div>
                    
                    <div class="flex items-center space-x-3">
                        <a href="/messages" 
                           class="bg-gray-300 text-gray-700 py-2 px-6 rounded-lg hover:bg-gray-400 transition-colors">
                            Cancel
                        </a>
                        
                        <button type="submit" 
                                class="bg-blue-600 text-white py-2 px-6 rounded-lg hover:bg-blue-700 transition-colors">
                            Send Message
                        </button>
                    </div>
                </div>
            </form>
        </div>

        <!-- Tips -->
        <div class="mt-8 bg-blue-50 border border-blue-200 rounded-lg p-6">
            <h3 class="text-lg font-medium text-blue-900 mb-3">Communication Tips</h3>
            <ul class="text-sm text-blue-800 space-y-2">
                <li>• Be clear and concise in your subject line</li>
                <li>• Use proper grammar and professional language</li>
                <li>• Include all necessary context in your message</li>
                <li>• Be respectful and courteous in your communication</li>
                <li>• Double-check recipient before sending important messages</li>
            </ul>
        </div>
    </div>
</div>

<!-- Preview Modal -->
<div id="previewModal" class="fixed inset-0 bg-black bg-opacity-50 hidden z-50">
    <div class="flex items-center justify-center min-h-screen p-4">
        <div class="bg-white rounded-lg max-w-2xl w-full max-h-96 overflow-y-auto">
            <div class="px-6 py-4 border-b">
                <div class="flex justify-between items-center">
                    <h3 class="text-lg font-medium text-gray-900">Message Preview</h3>
                    <button onclick="closePreview()" class="text-gray-400 hover:text-gray-600">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                        </svg>
                    </button>
                </div>
            </div>
            
            <div class="p-6">
                <div id="previewContent">
                    <!-- Preview content will be inserted here -->
                </div>
            </div>
            
            <div class="px-6 py-4 border-t bg-gray-50 flex justify-end space-x-3">
                <button onclick="closePreview()" class="bg-gray-300 text-gray-700 py-2 px-4 rounded-lg hover:bg-gray-400 transition-colors">
                    Edit Message
                </button>
                <button onclick="sendFromPreview()" class="bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors">
                    Send Message
                </button>
            </div>
        </div>
    </div>
</div>

<script>
function previewMessage() {
    const receiverId = document.getElementById('receiver_id').value;
    const subject = document.getElementById('subject').value;
    const message = document.getElementById('message').value;
    
    if (!receiverId || !subject || !message) {
        alert('Please fill in all required fields before previewing');
        return;
    }
    
    const receiverText = document.getElementById('receiver_id').options[document.getElementById('receiver_id').selectedIndex].text;
    
    const previewContent = `
        <div class="space-y-4">
            <div>
                <label class="block text-sm font-medium text-gray-700">To:</label>
                <p class="text-sm text-gray-900">${receiverText}</p>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700">From:</label>
                <p class="text-sm text-gray-900"><?php echo htmlspecialchars($userName); ?> (<?php echo ucfirst($userRole); ?>)</p>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700">Subject:</label>
                <p class="text-sm text-gray-900 font-medium">${subject}</p>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700">Message:</label>
                <div class="text-sm text-gray-900 bg-gray-50 p-3 rounded border whitespace-pre-wrap">${message}</div>
            </div>
        </div>
    `;
    
    document.getElementById('previewContent').innerHTML = previewContent;
    document.getElementById('previewModal').classList.remove('hidden');
}

function closePreview() {
    document.getElementById('previewModal').classList.add('hidden');
}

function sendFromPreview() {
    closePreview();
    document.querySelector('form').submit();
}

function saveDraft() {
    alert('Draft functionality will be implemented soon!');
}

// Auto-save draft every 2 minutes
let draftTimer;
function startAutoSave() {
    draftTimer = setInterval(() => {
        const subject = document.getElementById('subject').value;
        const message = document.getElementById('message').value;
        
        if (subject || message) {
            // Save draft logic here
            console.log('Auto-saving draft...');
        }
    }, 120000); // 2 minutes
}

// Character counter for message
document.getElementById('message').addEventListener('input', function() {
    const maxLength = 5000;
    const currentLength = this.value.length;
    
    // You can add a character counter here if needed
    if (currentLength > maxLength) {
        this.value = this.value.substring(0, maxLength);
    }
});

// Initialize auto-save when page loads
document.addEventListener('DOMContentLoaded', function() {
    startAutoSave();
    
    // Focus on recipient field
    document.getElementById('receiver_id').focus();
});

// Clean up timer when leaving page
window.addEventListener('beforeunload', function() {
    if (draftTimer) {
        clearInterval(draftTimer);
    }
});

// Close modal when clicking outside
document.getElementById('previewModal').addEventListener('click', function(e) {
    if (e.target === this) {
        closePreview();
    }
});
</script>