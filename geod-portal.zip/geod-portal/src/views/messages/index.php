<?php
$userRole = Session::getUserRole();
$userName = Session::get('username');
?>


<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $title; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style></style>
    
<div class="min-h-screen bg-gray-50">
    <!-- Header -->
    <div class="bg-white shadow-sm border-b">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center py-4">
                <div>
                    <h1 class="text-2xl font-bold text-gray-900">Messages</h1>
                    <p class="text-gray-600">Your messages and communications</p>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="/messages/compose" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors">
                        Compose Message
                    </a>
                    <?php if ($userRole === 'admin'): ?>
                        <a href="/messages/announcement" class="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors">
                            Send Announcement
                        </a>
                    <?php endif; ?>
                    <a href="/dashboard" class="text-gray-600 hover:text-gray-900">← Dashboard</a>
                </div>
            </div>
        </div>
    </div>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        <div class="grid grid-cols-1 lg:grid-cols-4 gap-8">
            <!-- Sidebar -->
            <div class="lg:col-span-1">
                <!-- Message Stats -->
                <div class="bg-white p-6 rounded-lg shadow-sm border mb-6">
                    <h3 class="text-lg font-medium text-gray-900 mb-4">Message Overview</h3>
                    <div class="space-y-3">
                        <div class="flex justify-between items-center">
                            <span class="text-sm text-gray-600">Unread</span>
                            <span class="bg-red-100 text-red-800 text-xs font-medium px-2 py-1 rounded-full">
                                <?php echo $unread_count; ?>
                            </span>
                        </div>
                        <div class="flex justify-between items-center">
                            <span class="text-sm text-gray-600">Personal</span>
                            <span class="text-sm font-medium text-gray-900"><?php echo $personal_count; ?></span>
                        </div>
                        <div class="flex justify-between items-center">
                            <span class="text-sm text-gray-600">Announcements</span>
                            <span class="text-sm font-medium text-gray-900"><?php echo $announcement_count; ?></span>
                        </div>
                        <div class="flex justify-between items-center">
                            <span class="text-sm text-gray-600">System</span>
                            <span class="text-sm font-medium text-gray-900"><?php echo $system_count; ?></span>
                        </div>
                    </div>
                </div>

                <!-- Message Filters -->
                <div class="bg-white p-6 rounded-lg shadow-sm border">
                    <h3 class="text-lg font-medium text-gray-900 mb-4">Filter Messages</h3>
                    <div class="space-y-2">
                        <a href="/messages" class="block w-full text-left px-3 py-2 rounded-lg text-sm <?php echo !$current_type ? 'bg-blue-100 text-blue-800' : 'text-gray-600 hover:bg-gray-100'; ?> transition-colors">
                            All Messages
                        </a>
                        <a href="/messages?type=personal" class="block w-full text-left px-3 py-2 rounded-lg text-sm <?php echo $current_type === 'personal' ? 'bg-blue-100 text-blue-800' : 'text-gray-600 hover:bg-gray-100'; ?> transition-colors">
                            Personal Messages
                        </a>
                        <a href="/messages?type=announcement" class="block w-full text-left px-3 py-2 rounded-lg text-sm <?php echo $current_type === 'announcement' ? 'bg-blue-100 text-blue-800' : 'text-gray-600 hover:bg-gray-100'; ?> transition-colors">
                            Announcements
                        </a>
                        <a href="/messages?type=system" class="block w-full text-left px-3 py-2 rounded-lg text-sm <?php echo $current_type === 'system' ? 'bg-blue-100 text-blue-800' : 'text-gray-600 hover:bg-gray-100'; ?> transition-colors">
                            System Messages
                        </a>
                    </div>
                </div>
            </div>

            <!-- Main Content -->
            <div class="lg:col-span-3">
                <!-- Search Bar -->
                <div class="bg-white p-4 rounded-lg shadow-sm border mb-6">
                    <div class="flex space-x-4">
                        <div class="flex-1">
                            <input type="text" id="messageSearch" placeholder="Search messages..." 
                                   class="w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                        </div>
                        <button onclick="searchMessages()" class="bg-blue-600 text-white px-4 py-2 rounded-md text-sm hover:bg-blue-700 transition-colors">
                            Search
                        </button>
                    </div>
                </div>

                <!-- Messages List -->
                <?php if (empty($messages)): ?>
                    <div class="bg-white rounded-lg shadow-sm border">
                        <div class="text-center py-12">
                            <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-4.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 009.586 13H7"></path>
                            </svg>
                            <h3 class="mt-2 text-sm font-medium text-gray-900">No messages</h3>
                            <p class="mt-1 text-sm text-gray-500">
                                <?php if ($current_type): ?>
                                    No <?php echo htmlspecialchars($current_type); ?> messages found.
                                <?php else: ?>
                                    You haven't received any messages yet.
                                <?php endif; ?>
                            </p>
                            <div class="mt-6">
                                <a href="/messages/compose" class="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700">
                                    Send Your First Message
                                </a>
                            </div>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="bg-white shadow-sm rounded-lg border">
                        <div class="divide-y divide-gray-200">
                            <?php foreach ($messages as $message): ?>
                                <div class="p-6 hover:bg-gray-50 transition-colors <?php echo !$message['read_status'] ? 'bg-blue-50 border-l-4 border-blue-500' : ''; ?>">
                                    <div class="flex items-start justify-between">
                                        <div class="flex-1 min-w-0">
                                            <div class="flex items-center space-x-3 mb-2">
                                                <div class="h-8 w-8 rounded-full bg-gray-200 flex items-center justify-center">
                                                    <span class="text-xs font-medium text-gray-600">
                                                        <?php echo strtoupper(substr($message['sender_name'], 0, 2)); ?>
                                                    </span>
                                                </div>
                                                <div>
                                                    <p class="text-sm font-medium text-gray-900">
                                                        <?php echo htmlspecialchars($message['sender_name']); ?>
                                                    </p>
                                                    <p class="text-xs text-gray-500">
                                                        <?php echo date('M j, Y g:i A', strtotime($message['created_at'])); ?>
                                                    </p>
                                                </div>
                                                <?php if ($message['message_type'] === 'announcement'): ?>
                                                    <span class="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800">
                                                        Announcement
                                                    </span>
                                                <?php elseif ($message['message_type'] === 'system'): ?>
                                                    <span class="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-gray-100 text-gray-800">
                                                        System
                                                    </span>
                                                <?php endif; ?>
                                                <?php if (!$message['read_status']): ?>
                                                    <span class="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-red-100 text-red-800">
                                                        New
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                            
                                            <h3 class="text-lg font-medium text-gray-900 mb-2">
                                                <a href="/messages/<?php echo $message['id']; ?>" class="hover:text-blue-600">
                                                    <?php echo htmlspecialchars($message['subject']); ?>
                                                </a>
                                            </h3>
                                            
                                            <p class="text-sm text-gray-600 line-clamp-2">
                                                <?php echo htmlspecialchars(substr($message['message'], 0, 150)); ?>
                                                <?php if (strlen($message['message']) > 150): ?>...<?php endif; ?>
                                            </p>
                                        </div>
                                        
                                        <div class="flex items-center space-x-2 ml-4">
                                            <a href="/messages/<?php echo $message['id']; ?>" 
                                               class="text-blue-600 hover:text-blue-800 text-sm font-medium">
                                                Read
                                            </a>
                                            
                                            <?php if ($message['sender_id'] != Session::getUserId()): ?>
                                                <a href="/messages/<?php echo $message['id']; ?>/reply" 
                                                   class="text-green-600 hover:text-green-800 text-sm font-medium">
                                                    Reply
                                                </a>
                                            <?php endif; ?>
                                            
                                            <button onclick="deleteMessage(<?php echo $message['id']; ?>)" 
                                                    class="text-red-600 hover:text-red-800 text-sm font-medium">
                                                Delete
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>

                <!-- Quick Actions -->
                <div class="mt-8 bg-white p-6 rounded-lg shadow-sm border">
                    <h3 class="text-lg font-medium text-gray-900 mb-4">Quick Actions</h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        <a href="/messages/compose" class="flex items-center p-4 border border-gray-200 rounded-lg hover:border-blue-300 hover:shadow-sm transition-all">
                            <div class="p-2 bg-blue-100 rounded-lg mr-3">
                                <svg class="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"></path>
                                </svg>
                            </div>
                            <div>
                                <p class="text-sm font-medium text-gray-900">New Message</p>
                                <p class="text-xs text-gray-500">Compose a new message</p>
                            </div>
                        </a>
                        
                        <?php if ($userRole === 'admin'): ?>
                        <a href="/messages/announcement" class="flex items-center p-4 border border-gray-200 rounded-lg hover:border-green-300 hover:shadow-sm transition-all">
                            <div class="p-2 bg-green-100 rounded-lg mr-3">
                                <svg class="w-5 h-5 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5.882V19.24a1.76 1.76 0 01-3.417.592l-2.147-6.15M18 13a3 3 0 100-6M5.436 13.683A4.001 4.001 0 017 6h1.832c4.1 0 7.625-1.234 9.168-3v14c-1.543-1.766-5.067-3-9.168-3H7a3.988 3.988 0 01-1.564-.317z"></path>
                                </svg>
                            </div>
                            <div>
                                <p class="text-sm font-medium text-gray-900">Announcement</p>
                                <p class="text-xs text-gray-500">Send to multiple users</p>
                            </div>
                        </a>
                        <?php endif; ?>
                        
                        <button onclick="markAllRead()" class="flex items-center p-4 border border-gray-200 rounded-lg hover:border-purple-300 hover:shadow-sm transition-all">
                            <div class="p-2 bg-purple-100 rounded-lg mr-3">
                                <svg class="w-5 h-5 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                </svg>
                            </div>
                            <div>
                                <p class="text-sm font-medium text-gray-900">Mark All Read</p>
                                <p class="text-xs text-gray-500">Clear unread notifications</p>
                            </div>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function deleteMessage(messageId) {
    if (!confirm('Are you sure you want to delete this message?')) {
        return;
    }
    
    const formData = new FormData();
    formData.append('csrf_token', '<?php echo CSRF::getToken(); ?>');
    
    fetch(`/messages/${messageId}/delete`, {
        method: 'POST',
        body: formData
    })
    .then(response => {
        if (response.ok) {
            location.reload();
        } else {
            alert('Failed to delete message');
        }
    })
    .catch(error => {
        console.error('Delete error:', error);
        alert('Failed to delete message');
    });
}

function searchMessages() {
    const query = document.getElementById('messageSearch').value.trim();
    if (query.length < 2) {
        alert('Please enter at least 2 characters to search');
        return;
    }
    
    fetch(`/messages/search?q=${encodeURIComponent(query)}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Display search results (you can implement this)
                console.log('Search results:', data.messages);
            } else {
                alert('Search failed: ' + data.message);
            }
        })
        .catch(error => {
            console.error('Search error:', error);
            alert('Search failed');
        });
}

function markAllRead() {
    if (!confirm('Mark all messages as read?')) {
        return;
    }
    
    // Implementation for marking all messages as read
    alert('Feature coming soon!');
}

// Auto-refresh unread count every 30 seconds
setInterval(() => {
    fetch('/messages/unread-count')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Update unread count in UI if needed
                console.log('Unread count:', data.count);
            }
        })
        .catch(error => console.error('Failed to get unread count'));
}, 30000);
</script>