<?php
$userRole = Session::getUserRole();
$userName = Session::get('username');
?>

<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $title; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style></style>

<div class="min-h-screen bg-gray-50">
    <!-- Header (Hidden on print) -->
    <div class="bg-white shadow-sm border-b print:hidden">
        <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center py-4">
                <div>
                    <h1 class="text-2xl font-bold text-gray-900">Official Transcript</h1>
                    <p class="text-gray-600">Complete academic record</p>
                </div>
                <div class="flex items-center space-x-4">
                    <button onclick="window.print()" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors">
                        Print Transcript
                    </button>
                    <a href="/student/grades" class="text-gray-600 hover:text-gray-900">← Back to Grades</a>
                </div>
            </div>
        </div>
    </div>

    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        <!-- Official Transcript Header -->
        <div class="bg-white rounded-lg shadow-sm border p-8 mb-8">
            <!-- University Header -->
            <div class="text-center mb-8">
                <h1 class="text-3xl font-bold text-gray-900 mb-2">GEOD UNIVERSITY</h1>
                <h2 class="text-xl text-gray-700 mb-1">Gateway Education & Organizational Development</h2>
                <p class="text-gray-600 mb-2">PMB 1234, University Road, Academic City</p>
                <p class="text-gray-600 mb-4">Email: registrar@geoduniversity.edu.ng | Phone: +234-XXX-XXX-XXXX</p>
                <div class="w-32 h-1 bg-green-600 mx-auto mb-6"></div>
                <h3 class="text-2xl font-bold text-gray-900">OFFICIAL TRANSCRIPT</h3>
            </div>

            <!-- Student Information -->
            <div class="border-2 border-gray-300 rounded-lg p-6 mb-8">
                <h4 class="text-lg font-bold text-gray-900 mb-4">STUDENT INFORMATION</h4>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div class="space-y-2">
                        <div class="flex">
                            <span class="w-32 font-medium text-gray-700">Name:</span>
                            <span class="text-gray-900 font-semibold">
                                <?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?>
                            </span>
                        </div>
                        <div class="flex">
                            <span class="w-32 font-medium text-gray-700">Student ID:</span>
                            <span class="text-gray-900 font-mono"><?php echo htmlspecialchars($student['student_id'] ?? 'N/A'); ?></span>
                        </div>
                        <div class="flex">
                            <span class="w-32 font-medium text-gray-700">Email:</span>
                            <span class="text-gray-900"><?php echo htmlspecialchars($user['email']); ?></span>
                        </div>
                        <div class="flex">
                            <span class="w-32 font-medium text-gray-700">Date of Birth:</span>
                            <span class="text-gray-900">
                                <?php echo $student['date_of_birth'] ? date('F j, Y', strtotime($student['date_of_birth'])) : 'N/A'; ?>
                            </span>
                        </div>
                    </div>
                    <div class="space-y-2">
                        <div class="flex">
                            <span class="w-32 font-medium text-gray-700">Program:</span>
                            <span class="text-gray-900 font-semibold"><?php echo htmlspecialchars($student['program'] ?? 'N/A'); ?></span>
                        </div>
                        <div class="flex">
                            <span class="w-32 font-medium text-gray-700">Level:</span>
                            <span class="text-gray-900"><?php echo htmlspecialchars($student['level'] ?? 'N/A'); ?> Level</span>
                        </div>
                        <div class="flex">
                            <span class="w-32 font-medium text-gray-700">Admission Year:</span>
                            <span class="text-gray-900"><?php echo htmlspecialchars($student['admission_year'] ?? 'N/A'); ?></span>
                        </div>
                        <div class="flex">
                            <span class="w-32 font-medium text-gray-700">Gender:</span>
                            <span class="text-gray-900 capitalize"><?php echo htmlspecialchars($student['gender'] ?? 'N/A'); ?></span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Academic Record -->
            <?php if (empty($academic_record)): ?>
                <div class="text-center py-8">
                    <p class="text-gray-600">No academic records available at this time.</p>
                </div>
            <?php else: ?>
                <!-- Group courses by academic year and semester -->
                <?php
                $grouped_record = [];
                foreach ($academic_record as $record) {
                    $key = $record['academic_year'] . '_' . $record['semester'];
                    $grouped_record[$key]['info'] = [
                        'year' => $record['academic_year'],
                        'semester' => ucfirst($record['semester']) . ' Semester'
                    ];
                    $grouped_record[$key]['courses'][] = $record;
                }
                ?>

                <div class="mb-8">
                    <h4 class="text-lg font-bold text-gray-900 mb-6">ACADEMIC RECORD</h4>
                    
                    <?php foreach ($grouped_record as $semester_data): ?>
                        <div class="mb-6">
                            <div class="bg-gray-100 px-4 py-2 rounded-t-lg">
                                <h5 class="font-bold text-gray-900">
                                    <?php echo $semester_data['info']['year']; ?> Academic Year - <?php echo $semester_data['info']['semester']; ?>
                                </h5>
                            </div>
                            
                            <div class="border border-gray-200 rounded-b-lg overflow-hidden">
                                <table class="min-w-full">
                                    <thead class="bg-gray-50">
                                        <tr>
                                            <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Course Code</th>
                                            <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Course Title</th>
                                            <th class="px-4 py-2 text-center text-xs font-medium text-gray-500 uppercase">Credits</th>
                                            <th class="px-4 py-2 text-center text-xs font-medium text-gray-500 uppercase">Grade</th>
                                            <th class="px-4 py-2 text-center text-xs font-medium text-gray-500 uppercase">Grade Point</th>
                                        </tr>
                                    </thead>
                                    <tbody class="divide-y divide-gray-200">
                                        <?php 
                                        $semester_credits = 0;
                                        $semester_points = 0;
                                        ?>
                                        <?php foreach ($semester_data['courses'] as $course): ?>
                                            <tr>
                                                <td class="px-4 py-2 text-sm font-medium text-gray-900">
                                                    <?php echo htmlspecialchars($course['course_code']); ?>
                                                </td>
                                                <td class="px-4 py-2 text-sm text-gray-900">
                                                    <?php echo htmlspecialchars($course['course_name']); ?>
                                                </td>
                                                <td class="px-4 py-2 text-sm text-center text-gray-900">
                                                    <?php echo $course['credits']; ?>
                                                </td>
                                                <td class="px-4 py-2 text-sm text-center font-semibold">
                                                    <?php if ($course['grade']): ?>
                                                        <span class="<?php echo $course['grade_point'] >= 3.5 ? 'text-green-600' : ($course['grade_point'] >= 2.5 ? 'text-yellow-600' : 'text-red-600'); ?>">
                                                            <?php echo htmlspecialchars($course['grade']); ?>
                                                        </span>
                                                    <?php else: ?>
                                                        <span class="text-gray-400">In Progress</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td class="px-4 py-2 text-sm text-center font-semibold">
                                                    <?php if ($course['grade_point']): ?>
                                                        <span class="<?php echo $course['grade_point'] >= 3.5 ? 'text-green-600' : ($course['grade_point'] >= 2.5 ? 'text-yellow-600' : 'text-red-600'); ?>">
                                                            <?php echo number_format($course['grade_point'], 2); ?>
                                                        </span>
                                                        <?php 
                                                        $semester_credits += $course['credits'];
                                                        $semester_points += $course['grade_point'] * $course['credits'];
                                                        ?>
                                                    <?php else: ?>
                                                        <span class="text-gray-400">-</span>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                        
                                        <!-- Semester Summary -->
                                        <tr class="bg-gray-50 font-semibold">
                                            <td colspan="2" class="px-4 py-2 text-sm text-gray-900">
                                                Semester Totals
                                            </td>
                                            <td class="px-4 py-2 text-sm text-center text-gray-900">
                                                <?php echo $semester_credits; ?>
                                            </td>
                                            <td class="px-4 py-2 text-sm text-center text-gray-900">
                                                GPA: <?php echo $semester_credits > 0 ? number_format($semester_points / $semester_credits, 2) : '0.00'; ?>
                                            </td>
                                            <td class="px-4 py-2 text-sm text-center text-gray-900">
                                                <?php echo number_format($semester_points, 2); ?>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <!-- Academic Summary -->
            <div class="border-2 border-gray-300 rounded-lg p-6 mb-8">
                <h4 class="text-lg font-bold text-gray-900 mb-4">ACADEMIC SUMMARY</h4>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div class="text-center">
                        <div class="text-2xl font-bold text-green-600"><?php echo $total_credits; ?></div>
                        <div class="text-sm text-gray-600">Total Credits Earned</div>
                    </div>
                    <div class="text-center">
                        <div class="text-2xl font-bold text-blue-600"><?php echo $cgpa; ?></div>
                        <div class="text-sm text-gray-600">Cumulative GPA</div>
                    </div>
                    <div class="text-center">
                        <div class="text-2xl font-bold text-purple-600">
                            <?php
                            $academic_status = 'Good Standing';
                            if ($cgpa >= 3.5) $academic_status = 'Excellent';
                            elseif ($cgpa >= 2.5) $academic_status = 'Good Standing';
                            elseif ($cgpa >= 2.0) $academic_status = 'Probation';
                            else $academic_status = 'Academic Warning';
                            echo $academic_status;
                            ?>
                        </div>
                        <div class="text-sm text-gray-600">Academic Status</div>
                    </div>
                </div>
            </div>

            <!-- Grading Scale -->
            <div class="mb-8">
                <h4 class="text-lg font-bold text-gray-900 mb-4">GRADING SCALE</h4>
                <div class="grid grid-cols-4 md:grid-cols-7 gap-2 text-xs">
                    <div class="text-center border border-gray-300 p-2">
                        <div class="font-bold">A</div>
                        <div>5.00</div>
                        <div class="text-gray-500">70-100%</div>
                    </div>
                    <div class="text-center border border-gray-300 p-2">
                        <div class="font-bold">B</div>
                        <div>4.00</div>
                        <div class="text-gray-500">60-69%</div>
                    </div>
                    <div class="text-center border border-gray-300 p-2">
                        <div class="font-bold">C</div>
                        <div>3.00</div>
                        <div class="text-gray-500">50-59%</div>
                    </div>
                    <div class="text-center border border-gray-300 p-2">
                        <div class="font-bold">D</div>
                        <div>2.00</div>
                        <div class="text-gray-500">45-49%</div>
                    </div>
                    <div class="text-center border border-gray-300 p-2">
                        <div class="font-bold">E</div>
                        <div>1.00</div>
                        <div class="text-gray-500">40-44%</div>
                    </div>
                    <div class="text-center border border-gray-300 p-2">
                        <div class="font-bold">F</div>
                        <div>0.00</div>
                        <div class="text-gray-500">0-39%</div>
                    </div>
                    <div class="text-center border border-gray-300 p-2">
                        <div class="font-bold">ABS</div>
                        <div>0.00</div>
                        <div class="text-gray-500">Absent</div>
                    </div>
                </div>
            </div>

            <!-- Official Footer -->
            <div class="text-center border-t pt-6">
                <div class="mb-4">
                    <p class="text-sm text-gray-600">This is an official transcript issued by GEOD University</p>
                    <p class="text-sm text-gray-600">Generated on <?php echo date('F j, Y \a\t g:i A'); ?></p>
                </div>
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-8 mt-8">
                    <div class="text-center">
                        <div class="border-t border-gray-400 w-48 mx-auto mb-2"></div>
                        <p class="text-sm font-medium">Registrar</p>
                        <p class="text-xs text-gray-500">GEOD University</p>
                    </div>
                    <div class="text-center">
                        <div class="border-t border-gray-400 w-48 mx-auto mb-2"></div>
                        <p class="text-sm font-medium">Official Seal</p>
                        <p class="text-xs text-gray-500">Date: <?php echo date('F j, Y'); ?></p>
                    </div>
                </div>
                
                <div class="mt-6 text-xs text-gray-500">
                    <p>This document is confidential and should be transmitted directly to the intended recipient.</p>
                    <p>Any unauthorized reproduction or alteration of this document is strictly prohibited.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<style media="print">
    @page {
        margin: 0.5in;
        size: A4;
    }
    
    body {
        background: white !important;
        font-size: 12px !important;
    }
    
    .print\\:hidden {
        display: none !important;
    }
    
    .bg-gray-50 {
        background: white !important;
    }
    
    .shadow-sm {
        box-shadow: none !important;
    }
    
    .border {
        border: 1px solid #000 !important;
    }
    
    .text-green-600, .text-blue-600, .text-purple-600, .text-yellow-600, .text-red-600 {
        color: #000 !important;
    }
    
    .bg-gray-100, .bg-gray-50 {
        background: #f5f5f5 !important;
    }
    
    /* Ensure proper page breaks */
    .break-inside-avoid {
        break-inside: avoid;
        page-break-inside: avoid;
    }
</style>