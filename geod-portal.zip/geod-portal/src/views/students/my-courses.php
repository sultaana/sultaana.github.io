<?php
$userRole = Session::getUserRole();
$userName = Session::get('username');
?>

<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $title; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style></style>

<div class="min-h-screen bg-gray-50">
    <!-- Header -->
    <div class="bg-white shadow-sm border-b">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center py-4">
                <div>
                    <h1 class="text-2xl font-bold text-gray-900">My Courses</h1>
                    <p class="text-gray-600">Your enrolled courses and academic progress</p>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="/courses" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors">
                        Browse Courses
                    </a>
                    <a href="/student/grades" class="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors">
                        View Grades
                    </a>
                    <a href="/dashboard" class="text-gray-600 hover:text-gray-900">← Dashboard</a>
                </div>
            </div>
        </div>
    </div>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        <!-- Student Overview -->
        <div class="bg-white p-6 rounded-lg shadow-sm border mb-8">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
                <div class="text-center">
                    <div class="text-2xl font-bold text-gray-900"><?php echo $student['student_id'] ?? 'N/A'; ?></div>
                    <div class="text-sm text-gray-600">Student ID</div>
                </div>
                <div class="text-center">
                    <div class="text-2xl font-bold text-gray-900"><?php echo $student['level'] ?? 'N/A'; ?></div>
                    <div class="text-sm text-gray-600">Current Level</div>
                </div>
                <div class="text-center">
                    <div class="text-2xl font-bold text-green-600"><?php echo $gpa; ?></div>
                    <div class="text-sm text-gray-600">Current GPA</div>
                </div>
                <div class="text-center">
                    <div class="text-2xl font-bold text-blue-600"><?php echo count($grouped_courses); ?></div>
                    <div class="text-sm text-gray-600">Total Semesters</div>
                </div>
            </div>
        </div>

        <!-- Courses by Semester -->
        <?php if (empty($grouped_courses)): ?>
            <div class="text-center py-12">
                <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.746 0 3.332.477 4.5 1.253v13C19.832 18.477 18.246 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"></path>
                </svg>
                <h3 class="mt-2 text-sm font-medium text-gray-900">No courses enrolled</h3>
                <p class="mt-1 text-sm text-gray-500">You haven't enrolled in any courses yet.</p>
                <div class="mt-6">
                    <a href="/courses" class="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700">
                        Browse Available Courses
                    </a>
                </div>
            </div>
        <?php else: ?>
            <?php foreach ($grouped_courses as $semester => $courses): ?>
                <div class="bg-white rounded-lg shadow-sm border mb-8">
                    <div class="px-6 py-4 border-b bg-gray-50">
                        <h3 class="text-lg font-medium text-gray-900"><?php echo htmlspecialchars($semester); ?></h3>
                        <p class="text-sm text-gray-600"><?php echo count($courses); ?> course(s) enrolled</p>
                    </div>
                    
                    <div class="p-6">
                        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                            <?php foreach ($courses as $course): ?>
                                <div class="border border-gray-200 rounded-lg p-4 hover:border-gray-300 transition-colors">
                                    <div class="flex items-start justify-between mb-3">
                                        <h4 class="font-medium text-gray-900">
                                            <?php echo htmlspecialchars($course['course_code']); ?>
                                        </h4>
                                        <span class="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-blue-100 text-blue-800">
                                            <?php echo $course['credits']; ?> Credits
                                        </span>
                                    </div>
                                    
                                    <h5 class="text-sm font-medium text-gray-700 mb-2">
                                        <?php echo htmlspecialchars($course['course_name']); ?>
                                    </h5>
                                    
                                    <div class="text-xs text-gray-500 mb-3">
                                        <?php echo htmlspecialchars($course['department_name']); ?>
                                    </div>
                                    
                                    <div class="flex items-center justify-between">
                                        <div class="text-xs">
                                            <?php
                                            $statusColors = [
                                                'enrolled' => 'text-blue-600',
                                                'completed' => 'text-green-600',
                                                'dropped' => 'text-red-600'
                                            ];
                                            $statusColor = $statusColors[$course['enrollment_status']] ?? 'text-gray-600';
                                            ?>
                                            <span class="<?php echo $statusColor; ?> font-medium">
                                                <?php echo ucfirst($course['enrollment_status']); ?>
                                            </span>
                                        </div>
                                        
                                        <?php if (!empty($course['grade'])): ?>
                                            <div class="text-right">
                                                <div class="text-lg font-bold <?php echo $course['grade_point'] >= 3.5 ? 'text-green-600' : ($course['grade_point'] >= 2.5 ? 'text-yellow-600' : 'text-red-600'); ?>">
                                                    <?php echo $course['grade']; ?>
                                                </div>
                                                <div class="text-xs text-gray-500">
                                                    <?php echo $course['grade_point']; ?> GP
                                                </div>
                                            </div>
                                        <?php else: ?>
                                            <div class="text-xs text-gray-400">
                                                No grade yet
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <div class="mt-3 pt-3 border-t border-gray-100">
                                        <a href="/courses/<?php echo $course['id']; ?>" class="text-sm text-blue-600 hover:text-blue-800">
                                            View Course Details →
                                        </a>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
        
        <!-- Academic Summary -->
        <div class="bg-white rounded-lg shadow-sm border p-6">
            <h3 class="text-lg font-medium text-gray-900 mb-4">Academic Summary</h3>
            
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <div class="text-center p-4 bg-blue-50 rounded-lg">
                    <div class="text-2xl font-bold text-blue-600">
                        <?php
                        $totalEnrolled = 0;
                        foreach ($grouped_courses as $courses) {
                            $totalEnrolled += count($courses);
                        }
                        echo $totalEnrolled;
                        ?>
                    </div>
                    <div class="text-sm text-gray-600">Total Courses</div>
                </div>
                
                <div class="text-center p-4 bg-green-50 rounded-lg">
                    <div class="text-2xl font-bold text-green-600">
                        <?php
                        $completedCourses = 0;
                        foreach ($grouped_courses as $courses) {
                            foreach ($courses as $course) {
                                if ($course['enrollment_status'] === 'completed') {
                                    $completedCourses++;
                                }
                            }
                        }
                        echo $completedCourses;
                        ?>
                    </div>
                    <div class="text-sm text-gray-600">Completed</div>
                </div>
                
                <div class="text-center p-4 bg-yellow-50 rounded-lg">
                    <div class="text-2xl font-bold text-yellow-600">
                        <?php
                        $totalCredits = 0;
                        foreach ($grouped_courses as $courses) {
                            foreach ($courses as $course) {
                                if ($course['enrollment_status'] === 'completed') {
                                    $totalCredits += $course['credits'];
                                }
                            }
                        }
                        echo $totalCredits;
                        ?>
                    </div>
                    <div class="text-sm text-gray-600">Credits Earned</div>
                </div>
                
                <div class="text-center p-4 bg-purple-50 rounded-lg">
                    <div class="text-2xl font-bold text-purple-600"><?php echo $gpa; ?></div>
                    <div class="text-sm text-gray-600">Current GPA</div>
                </div>
            </div>
            
            <div class="mt-6 flex justify-center space-x-4">
                <a href="/student/transcript" class="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 transition-colors">
                    Generate Transcript
                </a>
                <a href="/student/grades" class="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors">
                    View Academic Records
                </a>
            </div>
        </div>
    </div>
</div>