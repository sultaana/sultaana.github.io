<?php
$userRole = Session::getUserRole();
$userName = Session::get('username');
?>


<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $title; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style></style>

    
<div class="min-h-screen bg-gray-50">
    <!-- Header -->
    <div class="bg-white shadow-sm border-b">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center py-4">
                <div>
                    <h1 class="text-2xl font-bold text-gray-900">Academic Records</h1>
                    <p class="text-gray-600">Your grades and academic performance</p>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="/student/transcript" class="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors">
                        Generate Transcript
                    </a>
                    <button onclick="window.print()" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors print:hidden">
                        Print Records
                    </button>
                    <a href="/dashboard" class="text-gray-600 hover:text-gray-900 print:hidden">← Dashboard</a>
                </div>
            </div>
        </div>
    </div>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        <!-- Student Information -->
        <div class="bg-white p-6 rounded-lg shadow-sm border mb-8">
            <h3 class="text-lg font-medium text-gray-900 mb-4">Student Information</h3>
            <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
                <div>
                    <div class="text-sm text-gray-600">Student ID</div>
                    <div class="font-medium"><?php echo htmlspecialchars($student['student_id'] ?? 'N/A'); ?></div>
                </div>
                <div>
                    <div class="text-sm text-gray-600">Name</div>
                    <div class="font-medium"><?php echo htmlspecialchars($userName); ?></div>
                </div>
                <div>
                    <div class="text-sm text-gray-600">Program</div>
                    <div class="font-medium"><?php echo htmlspecialchars($student['program'] ?? 'N/A'); ?></div>
                </div>
                <div>
                    <div class="text-sm text-gray-600">Current Level</div>
                    <div class="font-medium"><?php echo htmlspecialchars($student['level'] ?? 'N/A'); ?> Level</div>
                </div>
            </div>
        </div>

        <!-- GPA Summary -->
        <div class="bg-white p-6 rounded-lg shadow-sm border mb-8">
            <h3 class="text-lg font-medium text-gray-900 mb-4">Academic Summary</h3>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <div class="text-center p-4 bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg">
                    <div class="text-3xl font-bold text-blue-600"><?php echo $cgpa; ?></div>
                    <div class="text-sm text-gray-600">Cumulative GPA</div>
                </div>
                <div class="text-center p-4 bg-gradient-to-br from-green-50 to-green-100 rounded-lg">
                    <div class="text-3xl font-bold text-green-600"><?php echo count($grades); ?></div>
                    <div class="text-sm text-gray-600">Completed Courses</div>
                </div>
                <div class="text-center p-4 bg-gradient-to-br from-yellow-50 to-yellow-100 rounded-lg">
                    <div class="text-3xl font-bold text-yellow-600">
                        <?php echo array_sum(array_column($grades, 'credits')); ?>
                    </div>
                    <div class="text-sm text-gray-600">Total Credits</div>
                </div>
                <div class="text-center p-4 bg-gradient-to-br from-purple-50 to-purple-100 rounded-lg">
                    <div class="text-3xl font-bold text-purple-600"><?php echo count($semester_stats); ?></div>
                    <div class="text-sm text-gray-600">Semesters</div>
                </div>
            </div>
        </div>

        <!-- Semester Performance -->
        <?php if (!empty($semester_stats)): ?>
        <div class="bg-white rounded-lg shadow-sm border mb-8">
            <div class="px-6 py-4 border-b">
                <h3 class="text-lg font-medium text-gray-900">Semester Performance</h3>
            </div>
            <div class="p-6">
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <?php foreach ($semester_stats as $stats): ?>
                        <div class="border border-gray-200 rounded-lg p-4">
                            <div class="flex justify-between items-start mb-2">
                                <div>
                                    <h4 class="font-medium text-gray-900">
                                        <?php echo htmlspecialchars($stats['year']); ?>
                                    </h4>
                                    <p class="text-sm text-gray-600">
                                        <?php echo ucfirst($stats['semester']); ?> Semester
                                    </p>
                                </div>
                                <div class="text-right">
                                    <div class="text-xl font-bold <?php echo $stats['gpa'] >= 3.5 ? 'text-green-600' : ($stats['gpa'] >= 2.5 ? 'text-yellow-600' : 'text-red-600'); ?>">
                                        <?php echo $stats['gpa']; ?>
                                    </div>
                                    <div class="text-xs text-gray-500">GPA</div>
                                </div>
                            </div>
                            <div class="flex justify-between text-sm text-gray-600">
                                <span><?php echo $stats['courses']; ?> courses</span>
                                <span><?php echo $stats['total_credits']; ?> credits</span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Grade Details -->
        <?php if (empty($grades)): ?>
            <div class="text-center py-12">
                <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"></path>
                </svg>
                <h3 class="mt-2 text-sm font-medium text-gray-900">No grades available</h3>
                <p class="mt-1 text-sm text-gray-500">Your grades will appear here once they are published.</p>
            </div>
        <?php else: ?>
            <div class="bg-white shadow-sm rounded-lg border">
                <div class="px-6 py-4 border-b">
                    <h3 class="text-lg font-medium text-gray-900">Course Grades</h3>
                </div>
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Course</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Course Name</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Credits</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Grade</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Grade Point</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Semester</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Session</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php foreach ($grades as $grade): ?>
                                <tr class="hover:bg-gray-50">
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm font-medium text-gray-900">
                                            <?php echo htmlspecialchars($grade['course_code']); ?>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4">
                                        <div class="text-sm text-gray-900">
                                            <?php echo htmlspecialchars($grade['course_name']); ?>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm text-gray-900"><?php echo $grade['credits']; ?></div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <?php
                                        $gradeColor = '';
                                        if ($grade['grade_point'] >= 3.5) $gradeColor = 'text-green-600 bg-green-100';
                                        elseif ($grade['grade_point'] >= 2.5) $gradeColor = 'text-yellow-600 bg-yellow-100';
                                        else $gradeColor = 'text-red-600 bg-red-100';
                                        ?>
                                        <span class="inline-flex px-2 py-1 text-xs font-semibold rounded-full <?php echo $gradeColor; ?>">
                                            <?php echo htmlspecialchars($grade['grade']); ?>
                                        </span>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm font-medium text-gray-900"><?php echo $grade['grade_point']; ?></div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm text-gray-500 capitalize"><?php echo $grade['semester']; ?></div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm text-gray-500"><?php echo htmlspecialchars($grade['academic_year']); ?></div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>

        <!-- GPA Scale Reference -->
        <div class="mt-8 bg-white rounded-lg shadow-sm border p-6">
            <h3 class="text-lg font-medium text-gray-900 mb-4">GPA Scale Reference</h3>
            <div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4 text-sm">
                <div class="text-center p-3 bg-green-50 border border-green-200 rounded">
                    <div class="font-bold text-green-800">A</div>
                    <div class="text-green-600">5.00</div>
                    <div class="text-xs text-gray-500">70-100%</div>
                </div>
                <div class="text-center p-3 bg-green-50 border border-green-200 rounded">
                    <div class="font-bold text-green-700">B</div>
                    <div class="text-green-600">4.00</div>
                    <div class="text-xs text-gray-500">60-69%</div>
                </div>
                <div class="text-center p-3 bg-yellow-50 border border-yellow-200 rounded">
                    <div class="font-bold text-yellow-700">C</div>
                    <div class="text-yellow-600">3.00</div>
                    <div class="text-xs text-gray-500">50-59%</div>
                </div>
                <div class="text-center p-3 bg-orange-50 border border-orange-200 rounded">
                    <div class="font-bold text-orange-700">D</div>
                    <div class="text-orange-600">2.00</div>
                    <div class="text-xs text-gray-500">45-49%</div>
                </div>
                <div class="text-center p-3 bg-red-50 border border-red-200 rounded">
                    <div class="font-bold text-red-700">E</div>
                    <div class="text-red-600">1.00</div>
                    <div class="text-xs text-gray-500">40-44%</div>
                </div>
                <div class="text-center p-3 bg-red-50 border border-red-200 rounded">
                    <div class="font-bold text-red-700">F</div>
                    <div class="text-red-600">0.00</div>
                    <div class="text-xs text-gray-500">0-39%</div>
                </div>
                <div class="text-center p-3 bg-gray-50 border border-gray-200 rounded">
                    <div class="font-bold text-gray-700">ABS</div>
                    <div class="text-gray-600">0.00</div>
                    <div class="text-xs text-gray-500">Absent</div>
                </div>
            </div>
        </div>
    </div>
</div>

<style media="print">
    @page {
        margin: 0.5in;
    }
    
    body {
        background: white !important;
    }
    
    .print\\:hidden {
        display: none !important;
    }
    
    .bg-gray-50 {
        background: white !important;
    }
    
    .shadow-sm {
        box-shadow: none !important;
    }
    
    .border {
        border: 1px solid #e5e7eb !important;
    }
</style>