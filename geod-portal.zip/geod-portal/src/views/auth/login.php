<?php
// Get flash messages once to avoid consuming them multiple times
$errorMessage = Session::flash('error');
$successMessage = Session::flash('success');
$oldInput = Session::flash('old_input') ?? [];
$errors = Session::flash('errors') ?? [];

$additionalStyles = '
<style>
    .error-field { border-color: #ef4444; background-color: #fef2f2; }
    .error-field:focus { border-color: #dc2626; box-shadow: 0 0 0 3px rgba(239, 68, 68, 0.1); }
</style>';

ob_start();
?>

<div class="min-h-screen py-8 px-4 sm:px-6 lg:px-8 flex items-center justify-center">
    <div class="max-w-md w-full space-y-6">
        <!-- Header -->
        <div class="text-center">
            <div class="mx-auto h-16 w-16 bg-blue-600 rounded-full flex items-center justify-center mb-4 shadow-lg">
                <svg class="h-8 w-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path>
                </svg>
            </div>
            <h2 class="text-3xl font-bold text-gray-900 mb-2">Welcome Back</h2>
            <p class="text-gray-600">Sign in to your GEOD University Portal</p>
        </div>

        <!-- Flash Messages -->
        <?php if ($errorMessage): ?>
            <div class="bg-red-50 border-l-4 border-red-400 p-4 rounded-r-lg">
                <div class="flex">
                    <div class="flex-shrink-0">
                        <svg class="h-5 w-5 text-red-400" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"></path>
                        </svg>
                    </div>
                    <div class="ml-3">
                        <h3 class="text-sm font-medium text-red-800"><?php echo htmlspecialchars($errorMessage); ?></h3>
                        <?php if (!empty($errors)): ?>
                            <ul class="mt-2 text-sm text-red-700 space-y-1">
                                <?php foreach ($errors as $field => $fieldErrors): ?>
                                    <?php foreach ($fieldErrors as $error): ?>
                                        <li class="flex items-center">
                                            <span class="w-1 h-1 bg-red-400 rounded-full mr-2"></span>
                                            <?php echo htmlspecialchars($error); ?>
                                        </li>
                                    <?php endforeach; ?>
                                <?php endforeach; ?>
                            </ul>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <?php if ($successMessage): ?>
            <div class="bg-green-50 border-l-4 border-green-400 p-4 rounded-r-lg">
                <div class="flex">
                    <div class="flex-shrink-0">
                        <svg class="h-5 w-5 text-green-400" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path>
                        </svg>
                    </div>
                    <div class="ml-3">
                        <p class="text-sm font-medium text-green-800"><?php echo htmlspecialchars($successMessage); ?></p>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <!-- Login Form -->
        <div class="bg-white py-8 px-6 shadow-lg rounded-lg border border-gray-200">
            <form method="POST" action="/auth/login" class="space-y-6">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                
                <div>
                    <label for="login" class="block text-sm font-medium text-gray-700 mb-2">
                        Email or Student ID <span class="text-red-500">*</span>
                    </label>
                    <input 
                        type="text" 
                        id="login" 
                        name="login" 
                        required 
                        class="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 <?php echo isset($errors['login']) ? 'error-field' : 'border-gray-300'; ?>"
                        placeholder="your.email@example.com or CSC/2024/001"
                        value="<?php echo htmlspecialchars($oldInput['login'] ?? ''); ?>"
                    >
                    <?php if (isset($errors['login'])): ?>
                        <div class="mt-1 flex items-center text-sm text-red-600">
                            <svg class="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clip-rule="evenodd"></path>
                            </svg>
                            <?php echo htmlspecialchars($errors['login'][0]); ?>
                        </div>
                    <?php endif; ?>
                </div>

                <div>
                    <label for="password" class="block text-sm font-medium text-gray-700 mb-2">
                        Password <span class="text-red-500">*</span>
                    </label>
                    <input 
                        type="password" 
                        id="password" 
                        name="password" 
                        required 
                        class="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 <?php echo isset($errors['password']) ? 'error-field' : 'border-gray-300'; ?>"
                        placeholder="Enter your password"
                    >
                    <?php if (isset($errors['password'])): ?>
                        <div class="mt-1 flex items-center text-sm text-red-600">
                            <svg class="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clip-rule="evenodd"></path>
                            </svg>
                            <?php echo htmlspecialchars($errors['password'][0]); ?>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="flex items-center justify-between">
                    <div class="flex items-center">
                        <input 
                            id="remember" 
                            name="remember" 
                            type="checkbox" 
                            class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                        >
                        <label for="remember" class="ml-2 block text-sm text-gray-700">
                            Remember me
                        </label>
                    </div>

                    <div class="text-sm">
                        <a href="/auth/forgot-password" class="text-blue-600 hover:text-blue-800 transition-colors">
                            Forgot password?
                        </a>
                    </div>
                </div>

                <button 
                    type="submit" 
                    class="w-full bg-blue-600 text-white py-3 px-4 rounded-lg hover:bg-blue-700 focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors font-medium"
                >
                    Sign In
                </button>
            </form>
        </div>

        <!-- Register Link -->
        <div class="text-center mt-6">
            <p class="text-gray-600">
                Don't have an account? 
                <a href="/auth/register" class="text-blue-600 hover:text-blue-800 font-medium transition-colors">
                    Apply Now
                </a>
            </p>
            <p class="mt-2">
                <a href="/" class="text-gray-500 hover:text-gray-700 text-sm transition-colors">
                    ← Back to Homepage
                </a>
            </p>
        </div>
    </div>
</div>

<?php
$content = ob_get_clean();
include __DIR__ . '/../layouts/app.php';
?>