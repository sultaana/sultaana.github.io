<?php
$oldInput = Session::flash('old_input') ?? [];
$errors = Session::flash('errors') ?? [];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $title; ?></title>
    <!-- <script src="https://cdn.tailwindcss.com"></script> -->
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
    <style>
        body { font-family: 'Inter', sans-serif; }
    </style>
</head>
<body class="bg-gradient-to-br from-green-50 via-white to-blue-50 min-h-screen">
    <div class="min-h-screen py-12 px-4 sm:px-6 lg:px-8">
        <div class="max-w-2xl mx-auto">
            <!-- Header -->
            <div class="text-center mb-8">
                <div class="mx-auto h-16 w-16 bg-green-600 rounded-full flex items-center justify-center mb-4">
                    <svg class="h-8 w-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z"></path>
                    </svg>
                </div>
                <h2 class="text-3xl font-bold text-gray-900 mb-2">Create Your Account</h2>
                <p class="text-gray-600">Join GEOD University - Start your application process</p>
            </div>

            <!-- Flash Messages -->
            <?php if (Session::flash('error')): ?>
                <div class="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-6">
                    <div class="flex">
                        <svg class="h-5 w-5 text-red-400 mr-2" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"></path>
                        </svg>
                        <?php echo Session::flash('error'); ?>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Registration Form -->
            <div class="bg-white py-8 px-6 shadow-lg rounded-lg border border-gray-200">
                <form method="POST" action="/auth/register" class="space-y-6">
                    <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                    
                    <!-- Account Information -->
                    <div class="border-b border-gray-200 pb-6">
                        <h3 class="text-lg font-medium text-gray-900 mb-4">Account Information</h3>
                        
                        <div class="grid grid-cols-1 gap-4">
                            <div>
                                <label for="email" class="block text-sm font-medium text-gray-700 mb-2">
                                    Email Address *
                                </label>
                                <input 
                                    type="email" 
                                    id="email" 
                                    name="email" 
                                    required 
                                    class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-colors"
                                    placeholder="your.email@example.com"
                                    value="<?php echo htmlspecialchars($oldInput['email'] ?? ''); ?>"
                                >
                                <p class="mt-1 text-xs text-gray-500">This will be your login email</p>
                                <?php if ($errors['email'] ?? null): ?>
                                    <p class="mt-1 text-sm text-red-600"><?php echo $errors['email'][0]; ?></p>
                                <?php endif; ?>
                            </div>

                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div>
                                    <label for="password" class="block text-sm font-medium text-gray-700 mb-2">
                                        Password *
                                    </label>
                                    <input 
                                        type="password" 
                                        id="password" 
                                        name="password" 
                                        required 
                                        class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-colors"
                                        placeholder="Minimum 6 characters"
                                    >
                                    <?php if ($errors['password'] ?? null): ?>
                                        <p class="mt-1 text-sm text-red-600"><?php echo $errors['password'][0]; ?></p>
                                    <?php endif; ?>
                                </div>

                                <div>
                                    <label for="password_confirmation" class="block text-sm font-medium text-gray-700 mb-2">
                                        Confirm Password *
                                    </label>
                                    <input 
                                        type="password" 
                                        id="password_confirmation" 
                                        name="password_confirmation" 
                                        required 
                                        class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-colors"
                                        placeholder="Confirm your password"
                                    >
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Personal Information -->
                    <div class="border-b border-gray-200 pb-6">
                        <h3 class="text-lg font-medium text-gray-900 mb-4">Personal Information</h3>
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label for="first_name" class="block text-sm font-medium text-gray-700 mb-2">
                                    First Name *
                                </label>
                                <input 
                                    type="text" 
                                    id="first_name" 
                                    name="first_name" 
                                    required 
                                    class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-colors"
                                    placeholder="Enter your first name"
                                    value="<?php echo htmlspecialchars($oldInput['first_name'] ?? ''); ?>"
                                >
                                <?php if ($errors['first_name'] ?? null): ?>
                                    <p class="mt-1 text-sm text-red-600"><?php echo $errors['first_name'][0]; ?></p>
                                <?php endif; ?>
                            </div>

                            <div>
                                <label for="last_name" class="block text-sm font-medium text-gray-700 mb-2">
                                    Last Name *
                                </label>
                                <input 
                                    type="text" 
                                    id="last_name" 
                                    name="last_name" 
                                    required 
                                    class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-colors"
                                    placeholder="Enter your last name"
                                    value="<?php echo htmlspecialchars($oldInput['last_name'] ?? ''); ?>"
                                >
                                <?php if ($errors['last_name'] ?? null): ?>
                                    <p class="mt-1 text-sm text-red-600"><?php echo $errors['last_name'][0]; ?></p>
                                <?php endif; ?>
                            </div>

                            <div>
                                <label for="phone" class="block text-sm font-medium text-gray-700 mb-2">
                                    Phone Number *
                                </label>
                                <input 
                                    type="tel" 
                                    id="phone" 
                                    name="phone" 
                                    required 
                                    class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-colors"
                                    placeholder="08012345678"
                                    value="<?php echo htmlspecialchars($oldInput['phone'] ?? ''); ?>"
                                >
                                <?php if ($errors['phone'] ?? null): ?>
                                    <p class="mt-1 text-sm text-red-600"><?php echo $errors['phone'][0]; ?></p>
                                <?php endif; ?>
                            </div>

                            <div>
                                <label for="gender" class="block text-sm font-medium text-gray-700 mb-2">
                                    Gender *
                                </label>
                                <select 
                                    id="gender" 
                                    name="gender" 
                                    required 
                                    class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-colors"
                                >
                                    <option value="">Select Gender</option>
                                    <option value="Male" <?php echo ($oldInput['gender'] ?? '') === 'Male' ? 'selected' : ''; ?>>Male</option>
                                    <option value="Female" <?php echo ($oldInput['gender'] ?? '') === 'Female' ? 'selected' : ''; ?>>Female</option>
                                </select>
                                <?php if ($errors['gender'] ?? null): ?>
                                    <p class="mt-1 text-sm text-red-600"><?php echo $errors['gender'][0]; ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <!-- Nigerian Location Information -->
                    <div class="pb-6">
                        <h3 class="text-lg font-medium text-gray-900 mb-4">Location Information</h3>
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label for="state_of_origin" class="block text-sm font-medium text-gray-700 mb-2">
                                    State of Origin *
                                </label>
                                <select 
                                    id="state_of_origin" 
                                    name="state_of_origin" 
                                    required 
                                    class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-colors"
                                    onchange="loadLGAs(this.value)"
                                >
                                    <option value="">Select State</option>
                                    <?php foreach ($states as $state): ?>
                                        <option 
                                            value="<?php echo htmlspecialchars($state['name']); ?>" 
                                            data-id="<?php echo $state['id']; ?>"
                                            <?php echo ($oldInput['state_of_origin'] ?? '') === $state['name'] ? 'selected' : ''; ?>
                                        >
                                            <?php echo htmlspecialchars($state['name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <?php if ($errors['state_of_origin'] ?? null): ?>
                                    <p class="mt-1 text-sm text-red-600"><?php echo $errors['state_of_origin'][0]; ?></p>
                                <?php endif; ?>
                            </div>

                            <div>
                                <label for="lga" class="block text-sm font-medium text-gray-700 mb-2">
                                    Local Government Area *
                                </label>
                                <select 
                                    id="lga" 
                                    name="lga" 
                                    required 
                                    class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-colors"
                                    disabled
                                >
                                    <option value="">Select LGA</option>
                                </select>
                                <?php if ($errors['lga'] ?? null): ?>
                                    <p class="mt-1 text-sm text-red-600"><?php echo $errors['lga'][0]; ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <!-- Terms and Conditions -->
                    <div class="pb-6">
                        <div class="flex items-start">
                            <div class="flex items-center h-5">
                                <input 
                                    id="terms" 
                                    name="terms" 
                                    type="checkbox" 
                                    required
                                    class="h-4 w-4 text-green-600 focus:ring-green-500 border-gray-300 rounded"
                                >
                            </div>
                            <div class="ml-3 text-sm">
                                <label for="terms" class="text-gray-700">
                                    I agree to GEOD University's 
                                    <a href="#" class="text-green-600 hover:text-green-800">Terms of Service</a> 
                                    and 
                                    <a href="#" class="text-green-600 hover:text-green-800">Privacy Policy</a> *
                                </label>
                            </div>
                        </div>
                    </div>

                    <!-- Submit Button -->
                    <button 
                        type="submit" 
                        class="w-full bg-green-600 text-white py-3 px-4 rounded-lg hover:bg-green-700 focus:ring-2 focus:ring-green-500 focus:ring-offset-2 transition-colors font-medium text-lg"
                    >
                        Create Account & Continue to Application
                    </button>
                </form>
            </div>

            <!-- Login Link -->
            <div class="text-center">
                <p class="text-gray-600">
                    Already have an account? 
                    <a href="/auth/login" class="text-green-600 hover:text-green-800 font-medium transition-colors">
                        Sign In
                    </a>
                </p>
                <p class="mt-2">
                    <a href="/" class="text-gray-500 hover:text-gray-700 text-sm transition-colors">
                        ← Back to Homepage
                    </a>
                </p>
            </div>
        </div>
    </div>

    <!-- JavaScript for Dynamic LGA Loading -->
    <script>
        function loadLGAs(stateName) {
            const lgaSelect = document.getElementById('lga');
            const stateSelect = document.getElementById('state_of_origin');
            
            // Reset LGA dropdown
            lgaSelect.innerHTML = '<option value="">Loading...</option>';
            lgaSelect.disabled = true;
            
            if (!stateName) {
                lgaSelect.innerHTML = '<option value="">Select LGA</option>';
                return;
            }
            
            // Get state ID
            const selectedOption = stateSelect.querySelector(`option[value="${stateName}"]`);
            const stateId = selectedOption?.getAttribute('data-id');
            
            if (!stateId) {
                lgaSelect.innerHTML = '<option value="">Select LGA</option>';
                return;
            }
            
            // Fetch LGAs
            fetch(`/api/lgas/${stateId}`)
                .then(response => response.json())
                .then(data => {
                    lgaSelect.innerHTML = '<option value="">Select LGA</option>';
                    
                    if (data.lgas && data.lgas.length > 0) {
                        data.lgas.forEach(lga => {
                            const option = document.createElement('option');
                            option.value = lga.name;
                            option.textContent = lga.name;
                            lgaSelect.appendChild(option);
                        });
                        lgaSelect.disabled = false;
                    } else {
                        lgaSelect.innerHTML = '<option value="">No LGAs available</option>';
                    }
                })
                .catch(error => {
                    console.error('Error loading LGAs:', error);
                    lgaSelect.innerHTML = '<option value="">Error loading LGAs</option>';
                });
        }

        // Auto-select LGA if there's old input
        document.addEventListener('DOMContentLoaded', function() {
            const stateSelect = document.getElementById('state_of_origin');
            const selectedState = stateSelect.value;
            const oldLGA = '<?php echo htmlspecialchars($oldInput['lga'] ?? ''); ?>';
            
            if (selectedState) {
                loadLGAs(selectedState);
                
                // Set the old LGA value after LGAs are loaded
                if (oldLGA) {
                    setTimeout(() => {
                        const lgaSelect = document.getElementById('lga');
                        lgaSelect.value = oldLGA;
                    }, 500);
                }
            }
        });
    </script>
</body>
</html>