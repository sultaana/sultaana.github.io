<?php
$userRole = Session::getUserRole();
$userName = Session::get('username');
$userEmail = Session::get('user_email');

if (!isset($payment) || !$payment) {
    header('Location: /payments');
    exit;
}
?>

<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $title; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style></style>

<div class="min-h-screen bg-gray-50">
    <!-- Header -->
    <div class="bg-white shadow-sm border-b">
        <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center py-4">
                <div>
                    <h1 class="text-2xl font-bold text-gray-900">Payment Receipt</h1>
                    <p class="text-gray-600">Transaction details and payment confirmation</p>
                </div>
                <div class="flex items-center space-x-4">
                    <button onclick="window.print()" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors print:hidden">
                        Print Receipt
                    </button>
                    <a href="/payments" class="text-gray-600 hover:text-gray-900 print:hidden">← Back to Payments</a>
                </div>
            </div>
        </div>
    </div>

    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        <!-- Receipt Header -->
        <div class="bg-white rounded-lg shadow-sm border mb-8 p-8">
            <div class="text-center mb-8">
                <h2 class="text-3xl font-bold text-gray-900 mb-2">GEOD University</h2>
                <p class="text-lg text-gray-600 mb-1">Gateway Education & Organizational Development</p>
                <p class="text-sm text-gray-500">Official Payment Receipt</p>
                <div class="w-24 h-1 bg-green-600 mx-auto mt-4"></div>
            </div>

            <!-- Receipt Status -->
            <div class="text-center mb-8">
                <?php if ($payment['status'] === 'completed'): ?>
                    <div class="inline-flex items-center px-6 py-3 bg-green-100 text-green-800 rounded-full text-lg font-medium">
                        <svg class="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                        </svg>
                        Payment Successful
                    </div>
                <?php else: ?>
                    <div class="inline-flex items-center px-6 py-3 bg-yellow-100 text-yellow-800 rounded-full text-lg font-medium">
                        <svg class="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                        </svg>
                        Payment <?php echo ucfirst($payment['status']); ?>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Payment Details -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
                <div>
                    <h3 class="text-lg font-medium text-gray-900 mb-4">Payment Information</h3>
                    <div class="space-y-3">
                        <div class="flex justify-between">
                            <span class="text-gray-600">Receipt No:</span>
                            <span class="font-mono font-medium"><?php echo strtoupper($payment['reference']); ?></span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-gray-600">Payment Type:</span>
                            <span class="font-medium"><?php echo ucwords(str_replace('_', ' ', $payment['payment_type'])); ?></span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-gray-600">Amount:</span>
                            <span class="font-bold text-lg">₦<?php echo number_format($payment['amount'], 2); ?></span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-gray-600">Payment Date:</span>
                            <span class="font-medium"><?php echo date('F j, Y g:i A', strtotime($payment['created_at'])); ?></span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-gray-600">Status:</span>
                            <span class="font-medium capitalize <?php echo $payment['status'] === 'completed' ? 'text-green-600' : 'text-yellow-600'; ?>">
                                <?php echo $payment['status']; ?>
                            </span>
                        </div>
                    </div>
                </div>

                <div>
                    <h3 class="text-lg font-medium text-gray-900 mb-4">Student Information</h3>
                    <div class="space-y-3">
                        <div class="flex justify-between">
                            <span class="text-gray-600">Name:</span>
                            <span class="font-medium"><?php echo htmlspecialchars($userName); ?></span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-gray-600">Email:</span>
                            <span class="font-medium"><?php echo htmlspecialchars($userEmail); ?></span>
                        </div>
                        <?php if (isset($student) && $student): ?>
                            <div class="flex justify-between">
                                <span class="text-gray-600">Student ID:</span>
                                <span class="font-mono font-medium"><?php echo $student['student_id']; ?></span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-gray-600">Level:</span>
                                <span class="font-medium"><?php echo $student['level']; ?> Level</span>
                            </div>
                            <?php if ($student['department']): ?>
                                <div class="flex justify-between">
                                    <span class="text-gray-600">Department:</span>
                                    <span class="font-medium"><?php echo htmlspecialchars($student['department']); ?></span>
                                </div>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Payment Method Details -->
            <?php if ($payment['status'] === 'completed' && isset($payment['gateway_response'])): ?>
                <?php $gatewayData = json_decode($payment['gateway_response'], true); ?>
                <div class="border-t pt-6">
                    <h3 class="text-lg font-medium text-gray-900 mb-4">Payment Method</h3>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <?php if (isset($gatewayData['channel'])): ?>
                            <div class="text-center">
                                <div class="text-sm text-gray-600">Payment Channel</div>
                                <div class="font-medium capitalize"><?php echo htmlspecialchars($gatewayData['channel']); ?></div>
                            </div>
                        <?php endif; ?>
                        
                        <?php if (isset($gatewayData['bank'])): ?>
                            <div class="text-center">
                                <div class="text-sm text-gray-600">Bank</div>
                                <div class="font-medium"><?php echo htmlspecialchars($gatewayData['bank']); ?></div>
                            </div>
                        <?php endif; ?>
                        
                        <?php if (isset($gatewayData['card_type'])): ?>
                            <div class="text-center">
                                <div class="text-sm text-gray-600">Card Type</div>
                                <div class="font-medium"><?php echo htmlspecialchars($gatewayData['card_type']); ?></div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Important Notes -->
            <div class="border-t pt-6 mt-6">
                <h3 class="text-lg font-medium text-gray-900 mb-3">Important Notes</h3>
                <div class="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <ul class="text-sm text-blue-800 space-y-2">
                        <li>• This is an official receipt for your payment to GEOD University</li>
                        <li>• Please keep this receipt for your records</li>
                        <li>• This receipt serves as proof of payment for all university purposes</li>
                        <li>• Contact the finance office if you have any questions about this payment</li>
                        <?php if ($payment['payment_type'] === 'application_fee'): ?>
                            <li>• Your application has been submitted and is under review</li>
                        <?php elseif ($payment['payment_type'] === 'school_fees'): ?>
                            <li>• You are now eligible for course registration for this academic session</li>
                        <?php elseif ($payment['payment_type'] === 'acceptance_fee'): ?>
                            <li>• Your admission has been secured. Proceed with registration</li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>

            <!-- Footer -->
            <div class="border-t pt-6 mt-8 text-center">
                <div class="text-sm text-gray-600 mb-2">
                    Generated on <?php echo date('F j, Y \a\t g:i A'); ?>
                </div>
                <div class="text-xs text-gray-500">
                    This is a computer-generated receipt and does not require a signature.
                </div>
                <div class="mt-4 text-sm text-gray-600">
                    <p>For inquiries, contact:</p>
                    <p>Finance Office: <a href="mailto:finance@geoduniversity.edu.ng" class="text-blue-600">finance@geoduniversity.edu.ng</a> | +234-XXX-XXX-XXXX</p>
                </div>
            </div>
        </div>

        <!-- Action Buttons -->
        <div class="text-center space-x-4 print:hidden">
            <button onclick="window.print()" class="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors">
                <svg class="w-5 h-5 inline mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"></path>
                </svg>
                Print Receipt
            </button>
            <a href="/payments" class="bg-gray-600 text-white px-6 py-3 rounded-lg hover:bg-gray-700 transition-colors inline-block">
                Back to Payments
            </a>
            <a href="/dashboard" class="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition-colors inline-block">
                Go to Dashboard
            </a>
        </div>
    </div>
</div>

<style media="print">
    @page {
        margin: 0.5in;
    }
    
    body {
        background: white !important;
    }
    
    .print\\:hidden {
        display: none !important;
    }
    
    .bg-gray-50 {
        background: white !important;
    }
    
    .shadow-sm {
        box-shadow: none !important;
    }
    
    .border {
        border: 1px solid #e5e7eb !important;
    }
</style>

<script>
// Auto-print functionality if print parameter is present
document.addEventListener('DOMContentLoaded', function() {
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('print') === '1') {
        setTimeout(function() {
            window.print();
        }, 500);
    }
});
</script>