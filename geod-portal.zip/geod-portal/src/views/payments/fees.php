<?php
$userRole = Session::getUserRole();
$userName = Session::get('username');
$userEmail = Session::get('user_email');
?>

<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $title; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style></style>

<div class="min-h-screen bg-gray-50">
    <!-- Header -->
    <div class="bg-white shadow-sm border-b">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center py-4">
                <div>
                    <h1 class="text-2xl font-bold text-gray-900">Fee Structure</h1>
                    <p class="text-gray-600">GEOD University fee schedule and payment options</p>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="/payments" class="text-gray-600 hover:text-gray-900">← Payment History</a>
                </div>
            </div>
        </div>
    </div>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        <!-- Fee Categories -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
            
            <!-- Application Fees -->
            <div class="bg-white rounded-lg shadow-sm border">
                <div class="px-6 py-4 border-b">
                    <h3 class="text-lg font-medium text-gray-900">Application Fees</h3>
                    <p class="text-sm text-gray-600">One-time application processing fees</p>
                </div>
                <div class="p-6">
                    <div class="space-y-4">
                        <div class="flex justify-between items-center p-4 bg-gray-50 rounded-lg">
                            <div>
                                <h4 class="font-medium text-gray-900">Application Fee</h4>
                                <p class="text-sm text-gray-600">For all programs</p>
                            </div>
                            <div class="text-right">
                                <span class="text-xl font-bold text-gray-900">₦<?php echo number_format($fee_structure['application_fee'], 2); ?></span>
                                <p class="text-xs text-gray-500">Non-refundable</p>
                            </div>
                        </div>

                        <?php
                        $hasApplicationPayment = false;
                        foreach ($paid_fees as $fee) {
                            if ($fee['payment_type'] === 'application_fee' && $fee['status'] === 'completed') {
                                $hasApplicationPayment = true;
                                break;
                            }
                        }
                        ?>

                        <?php if (!$hasApplicationPayment): ?>
                            <button onclick="initiatePayment('application_fee', <?php echo $fee_structure['application_fee']; ?>)" 
                                    class="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors">
                                Pay Application Fee
                            </button>
                        <?php else: ?>
                            <div class="w-full bg-green-100 text-green-800 py-2 px-4 rounded-lg text-center">
                                ✓ Application Fee Paid
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Admission Fees -->
            <div class="bg-white rounded-lg shadow-sm border">
                <div class="px-6 py-4 border-b">
                    <h3 class="text-lg font-medium text-gray-900">Admission Fees</h3>
                    <p class="text-sm text-gray-600">Required after admission offer</p>
                </div>
                <div class="p-6">
                    <div class="space-y-4">
                        <div class="flex justify-between items-center p-4 bg-gray-50 rounded-lg">
                            <div>
                                <h4 class="font-medium text-gray-900">Acceptance Fee</h4>
                                <p class="text-sm text-gray-600">To secure admission</p>
                            </div>
                            <div class="text-right">
                                <span class="text-xl font-bold text-gray-900">₦<?php echo number_format($fee_structure['acceptance_fee'], 2); ?></span>
                                <p class="text-xs text-gray-500">Due within 2 weeks</p>
                            </div>
                        </div>

                        <?php
                        $hasAcceptancePayment = false;
                        foreach ($paid_fees as $fee) {
                            if ($fee['payment_type'] === 'acceptance_fee' && $fee['status'] === 'completed') {
                                $hasAcceptancePayment = true;
                                break;
                            }
                        }
                        ?>

                        <?php if ($user_role === 'student' && !$hasAcceptancePayment): ?>
                            <button onclick="initiatePayment('acceptance_fee', <?php echo $fee_structure['acceptance_fee']; ?>)" 
                                    class="w-full bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700 transition-colors">
                                Pay Acceptance Fee
                            </button>
                        <?php elseif ($hasAcceptancePayment): ?>
                            <div class="w-full bg-green-100 text-green-800 py-2 px-4 rounded-lg text-center">
                                ✓ Acceptance Fee Paid
                            </div>
                        <?php else: ?>
                            <div class="w-full bg-gray-100 text-gray-600 py-2 px-4 rounded-lg text-center">
                                Available after admission
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Academic Fees -->
        <div class="bg-white rounded-lg shadow-sm border mb-8">
            <div class="px-6 py-4 border-b">
                <h3 class="text-lg font-medium text-gray-900">Academic Fees</h3>
                <p class="text-sm text-gray-600">Semester and session fees for students</p>
            </div>
            <div class="p-6">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    
                    <!-- School Fees -->
                    <div class="border border-gray-200 rounded-lg p-4">
                        <div class="flex justify-between items-start mb-4">
                            <div>
                                <h4 class="font-medium text-gray-900">School Fees (Per Session)</h4>
                                <p class="text-sm text-gray-600">Tuition and academic services</p>
                            </div>
                            <span class="text-xl font-bold text-gray-900">₦<?php echo number_format($fee_structure['school_fees'], 2); ?></span>
                        </div>
                        
                        <div class="text-sm text-gray-600 mb-4">
                            <p>Includes:</p>
                            <ul class="list-disc list-inside ml-2 mt-1 space-y-1">
                                <li>Tuition fees</li>
                                <li>Library access</li>
                                <li>Laboratory fees</li>
                                <li>Student services</li>
                                <li>Examination fees</li>
                            </ul>
                        </div>

                        <?php
                        $hasSchoolFeesPayment = false;
                        foreach ($paid_fees as $fee) {
                            if ($fee['payment_type'] === 'school_fees' && $fee['status'] === 'completed') {
                                $hasSchoolFeesPayment = true;
                                break;
                            }
                        }
                        ?>

                        <?php if ($user_role === 'student' && !$hasSchoolFeesPayment): ?>
                            <button onclick="initiatePayment('school_fees', <?php echo $fee_structure['school_fees']; ?>)" 
                                    class="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors">
                                Pay School Fees
                            </button>
                        <?php elseif ($hasSchoolFeesPayment): ?>
                            <div class="w-full bg-green-100 text-green-800 py-2 px-4 rounded-lg text-center text-sm">
                                ✓ School Fees Paid for Current Session
                            </div>
                        <?php else: ?>
                            <div class="w-full bg-gray-100 text-gray-600 py-2 px-4 rounded-lg text-center text-sm">
                                Available for registered students
                            </div>
                        <?php endif; ?>
                    </div>

                    <!-- Course Registration Fee -->
                    <div class="border border-gray-200 rounded-lg p-4">
                        <div class="flex justify-between items-start mb-4">
                            <div>
                                <h4 class="font-medium text-gray-900">Course Registration</h4>
                                <p class="text-sm text-gray-600">Per semester registration</p>
                            </div>
                            <span class="text-xl font-bold text-gray-900">₦<?php echo number_format($fee_structure['course_registration'], 2); ?></span>
                        </div>
                        
                        <div class="text-sm text-gray-600 mb-4">
                            <p>Covers:</p>
                            <ul class="list-disc list-inside ml-2 mt-1 space-y-1">
                                <li>Course registration processing</li>
                                <li>Academic record maintenance</li>
                                <li>Timetable access</li>
                                <li>Online portal access</li>
                            </ul>
                        </div>

                        <?php
                        $hasCourseRegPayment = false;
                        foreach ($paid_fees as $fee) {
                            if ($fee['payment_type'] === 'course_registration' && $fee['status'] === 'completed') {
                                $hasCourseRegPayment = true;
                                break;
                            }
                        }
                        ?>

                        <?php if ($user_role === 'student' && !$hasCourseRegPayment): ?>
                            <button onclick="initiatePayment('course_registration', <?php echo $fee_structure['course_registration']; ?>)" 
                                    class="w-full bg-purple-600 text-white py-2 px-4 rounded-lg hover:bg-purple-700 transition-colors">
                                Pay Registration Fee
                            </button>
                        <?php elseif ($hasCourseRegPayment): ?>
                            <div class="w-full bg-green-100 text-green-800 py-2 px-4 rounded-lg text-center text-sm">
                                ✓ Registration Fee Paid
                            </div>
                        <?php else: ?>
                            <div class="w-full bg-gray-100 text-gray-600 py-2 px-4 rounded-lg text-center text-sm">
                                Available during registration period
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Payment Information -->
        <div class="bg-blue-50 border border-blue-200 rounded-lg p-6">
            <h3 class="text-lg font-medium text-blue-900 mb-3">Payment Information</h3>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 text-sm text-blue-800">
                <div>
                    <h4 class="font-medium mb-2">Accepted Payment Methods</h4>
                    <ul class="space-y-1">
                        <li>• Debit/Credit Cards (Visa, MasterCard, Verve)</li>
                        <li>• Bank Transfer</li>
                        <li>• USSD Banking</li>
                        <li>• Mobile Money (Paystack supported)</li>
                    </ul>
                </div>
                <div>
                    <h4 class="font-medium mb-2">Important Notes</h4>
                    <ul class="space-y-1">
                        <li>• All payments are processed securely via Paystack</li>
                        <li>• Payment receipts are sent via email</li>
                        <li>• Late payment may incur additional charges</li>
                        <li>• Contact finance office for payment issues</li>
                    </ul>
                </div>
            </div>
        </div>

        <!-- Contact Information -->
        <div class="mt-8 text-center">
            <p class="text-gray-600">
                Questions about fees? Contact the Finance Office at 
                <a href="mailto:finance@geoduniversity.edu.ng" class="text-blue-600 hover:text-blue-800">finance@geoduniversity.edu.ng</a> 
                or call <a href="tel:+234-XXX-XXX-XXXX" class="text-blue-600 hover:text-blue-800">+234-XXX-XXX-XXXX</a>
            </p>
        </div>
    </div>
</div>

<!-- Payment Modal -->
<div id="paymentModal" class="fixed inset-0 bg-black bg-opacity-50 hidden z-50">
    <div class="flex items-center justify-center min-h-screen p-4">
        <div class="bg-white rounded-lg max-w-md w-full p-6">
            <div class="flex justify-between items-center mb-4">
                <h3 class="text-lg font-medium text-gray-900">Confirm Payment</h3>
                <button onclick="closePaymentModal()" class="text-gray-400 hover:text-gray-600">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                    </svg>
                </button>
            </div>
            
            <div id="paymentDetails" class="mb-6">
                <!-- Payment details will be inserted here -->
            </div>
            
            <div class="flex space-x-3">
                <button onclick="closePaymentModal()" class="flex-1 bg-gray-300 text-gray-700 py-2 px-4 rounded-lg hover:bg-gray-400 transition-colors">
                    Cancel
                </button>
                <button onclick="processPayment()" class="flex-1 bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700 transition-colors">
                    Proceed to Pay
                </button>
            </div>
        </div>
    </div>
</div>

<script>
let currentPayment = {};

function initiatePayment(paymentType, amount) {
    currentPayment = {
        payment_type: paymentType,
        amount: amount
    };
    
    const paymentTypeNames = {
        'application_fee': 'Application Fee',
        'acceptance_fee': 'Acceptance Fee',
        'school_fees': 'School Fees',
        'course_registration': 'Course Registration Fee'
    };
    
    document.getElementById('paymentDetails').innerHTML = `
        <div class="text-center">
            <div class="p-4 bg-gray-50 rounded-lg mb-4">
                <h4 class="text-lg font-medium text-gray-900 mb-2">${paymentTypeNames[paymentType]}</h4>
                <p class="text-2xl font-bold text-green-600">₦${amount.toLocaleString()}</p>
            </div>
            <p class="text-sm text-gray-600">You will be redirected to Paystack for secure payment processing.</p>
        </div>
    `;
    
    document.getElementById('paymentModal').classList.remove('hidden');
}

function closePaymentModal() {
    document.getElementById('paymentModal').classList.add('hidden');
    currentPayment = {};
}

function processPayment() {
    // Show loading
    document.querySelector('#paymentModal button[onclick="processPayment()"]').innerHTML = 'Processing...';
    document.querySelector('#paymentModal button[onclick="processPayment()"]').disabled = true;
    
    // Create form data
    const formData = new FormData();
    formData.append('payment_type', currentPayment.payment_type);
    formData.append('amount', currentPayment.amount);
    formData.append('csrf_token', '<?php echo CSRF::getToken(); ?>');
    
    // Send payment request
    fetch('/payments/initiate', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Redirect to Paystack
            window.location.href = data.authorization_url;
        } else {
            alert('Payment initiation failed: ' + data.error);
            closePaymentModal();
        }
    })
    .catch(error => {
        console.error('Payment error:', error);
        alert('Payment initiation failed. Please try again.');
        closePaymentModal();
    });
}

// Close modal when clicking outside
document.getElementById('paymentModal').addEventListener('click', function(e) {
    if (e.target === this) {
        closePaymentModal();
    }
});
</script>