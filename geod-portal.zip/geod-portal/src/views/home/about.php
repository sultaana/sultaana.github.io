<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - GEOD University</title>
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
</head>
<body class="bg-white">
    <!-- Header -->
    <header class="bg-white shadow-sm">
        <div class="container mx-auto px-4 py-4">
            <div class="flex items-center justify-between">
                <div class="flex items-center space-x-2">
                    <div class="w-8 h-8 bg-gray-800 rounded flex items-center justify-center">
                        <span class="text-white text-sm font-bold">★</span>
                    </div>
                    <span class="text-xl font-bold text-gray-800">GEOD</span>
                </div>
                
                <nav class="hidden md:flex items-center space-x-8">
                    <a href="/" class="text-gray-600 hover:text-gray-800">Home</a>
                    <a href="/about" class="text-red-600 font-medium">About</a>
                    <a href="/admissions" class="text-gray-600 hover:text-gray-800">Admissions</a>
                    <a href="/contact" class="text-gray-600 hover:text-gray-800">Contact</a>
                    <a href="/programmes" class="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700">View Programmes</a>
                </nav>
            </div>
        </div>
    </header>

    <!-- Hero Section -->
    <section class="bg-gray-50 py-16">
        <div class="container mx-auto px-4">
            <div class="max-w-4xl mx-auto text-center">
                <h1 class="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">About GEOD University</h1>
                <p class="text-xl text-gray-600 leading-relaxed">
                    Empowering minds, shaping futures, and building tomorrow's leaders through innovative education and research excellence.
                </p>
            </div>
        </div>
    </section>

    <!-- Mission & Vision -->
    <section class="bg-white py-16">
        <div class="container mx-auto px-4">
            <div class="grid lg:grid-cols-2 gap-12 items-center">
                <div>
                    <img src="https://images.unsplash.com/photo-1562774053-701939374585?w=600&h=400&fit=crop" 
                         alt="University campus building" 
                         class="rounded-2xl w-full h-96 object-cover">
                </div>
                <div>
                    <h2 class="text-3xl font-bold text-gray-900 mb-6">Our Mission</h2>
                    <p class="text-gray-600 mb-6 leading-relaxed">
                        At GEOD University, we are committed to providing world-class education that prepares students 
                        for successful careers in an ever-evolving global landscape. We foster innovation, critical thinking, 
                        and ethical leadership through our comprehensive academic programs.
                    </p>
                    <p class="text-gray-600 leading-relaxed">
                        Our mission is to create an inclusive learning environment where students from diverse backgrounds 
                        can thrive, collaborate, and develop the skills necessary to make meaningful contributions to society.
                    </p>
                </div>
            </div>
        </div>
    </section>

    <!-- Stats Section -->
    <section class="bg-red-600 py-16">
        <div class="container mx-auto px-4">
            <div class="grid md:grid-cols-4 gap-8 text-center text-white">
                <div>
                    <div class="text-4xl font-bold mb-2">15,000+</div>
                    <div class="text-red-100">Students Enrolled</div>
                </div>
                <div>
                    <div class="text-4xl font-bold mb-2">500+</div>
                    <div class="text-red-100">Faculty Members</div>
                </div>
                <div>
                    <div class="text-4xl font-bold mb-2">50+</div>
                    <div class="text-red-100">Degree Programs</div>
                </div>
                <div>
                    <div class="text-4xl font-bold mb-2">95%</div>
                    <div class="text-red-100">Graduate Employment Rate</div>
                </div>
            </div>
        </div>
    </section>

    <!-- Values Section -->
    <section class="bg-white py-16">
        <div class="container mx-auto px-4">
            <div class="text-center mb-12">
                <h2 class="text-3xl font-bold text-gray-900 mb-4">Our Core Values</h2>
                <p class="text-gray-600 max-w-2xl mx-auto">
                    These fundamental principles guide everything we do at GEOD University.
                </p>
            </div>
            
            <div class="grid md:grid-cols-3 gap-8">
                <div class="text-center p-6">
                    <div class="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <div class="w-8 h-8 bg-red-600 rounded-full"></div>
                    </div>
                    <h3 class="text-xl font-bold text-gray-900 mb-4">Excellence</h3>
                    <p class="text-gray-600">
                        We strive for the highest standards in education, research, and service to our community.
                    </p>
                </div>
                
                <div class="text-center p-6">
                    <div class="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <div class="w-8 h-8 bg-red-600 rounded-full"></div>
                    </div>
                    <h3 class="text-xl font-bold text-gray-900 mb-4">Innovation</h3>
                    <p class="text-gray-600">
                        We embrace new ideas, technologies, and approaches to solve complex global challenges.
                    </p>
                </div>
                
                <div class="text-center p-6">
                    <div class="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <div class="w-8 h-8 bg-red-600 rounded-full"></div>
                    </div>
                    <h3 class="text-xl font-bold text-gray-900 mb-4">Integrity</h3>
                    <p class="text-gray-600">
                        We uphold the highest ethical standards in all our academic and professional endeavors.
                    </p>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-white border-t py-12">
        <div class="container mx-auto px-4">
            <div class="grid md:grid-cols-4 gap-8">
                <div>
                    <div class="flex items-center space-x-2 mb-4">
                        <div class="w-8 h-8 bg-gray-800 rounded flex items-center justify-center">
                            <span class="text-white text-sm font-bold">★</span>
                        </div>
                        <span class="text-xl font-bold text-gray-800">GEOD</span>
                    </div>
                    <p class="text-gray-600 text-sm">
                        Join us today to shape the leaders and visionaries of tomorrow.
                    </p>
                </div>
                
                <div>
                    <h4 class="font-semibold text-gray-900 mb-4">Quick Links</h4>
                    <ul class="space-y-2 text-sm text-gray-600">
                        <li><a href="/" class="hover:text-gray-900">Home</a></li>
                        <li><a href="/about" class="hover:text-gray-900">About</a></li>
                        <li><a href="/programmes" class="hover:text-gray-900">Programmes</a></li>
                        <li><a href="/contact" class="hover:text-gray-900">Contact</a></li>
                    </ul>
                </div>
                
                <div>
                    <h4 class="font-semibold text-gray-900 mb-4">Admissions</h4>
                    <ul class="space-y-2 text-sm text-gray-600">
                        <li><a href="/auth/register" class="hover:text-gray-900">Apply Now</a></li>
                        <li><a href="/requirements" class="hover:text-gray-900">Requirements</a></li>
                        <li><a href="/scholarships" class="hover:text-gray-900">Scholarships</a></li>
                        <li><a href="/tuition" class="hover:text-gray-900">Tuition & Fees</a></li>
                    </ul>
                </div>
                
                <div>
                    <h4 class="font-semibold text-gray-900 mb-4">Contact Info</h4>
                    <div class="space-y-2 text-sm text-gray-600">
                        <p>123 University Avenue</p>
                        <p>Education City, EC 12345</p>
                        <p>Phone: (555) 123-4567</p>
                        <p>Email: info@geod.edu</p>
                    </div>
                </div>
            </div>
            
            <div class="border-t mt-8 pt-8 text-center text-sm text-gray-600">
                <p>© 2025 GEOD University. All rights reserved.</p>
            </div>
        </div>
    </footer>
</body>
</html>
