<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Academic Programmes - GEOD University</title>
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
</head>
<body class="bg-white">
    <!-- Header -->
    <header class="bg-white shadow-sm">
        <div class="container mx-auto px-4 py-4">
            <div class="flex items-center justify-between">
                <div class="flex items-center space-x-2">
                    <div class="w-8 h-8 bg-gray-800 rounded flex items-center justify-center">
                        <span class="text-white text-sm font-bold">★</span>
                    </div>
                    <span class="text-xl font-bold text-gray-800">GEOD</span>
                </div>
                
                <nav class="hidden md:flex items-center space-x-8">
                    <a href="/" class="text-gray-600 hover:text-gray-800">Home</a>
                    <a href="/about" class="text-gray-600 hover:text-gray-800">About</a>
                    <a href="/admissions" class="text-gray-600 hover:text-gray-800">Admissions</a>
                    <a href="/contact" class="text-gray-600 hover:text-gray-800">Contact</a>
                    <a href="/programmes" class="bg-red-600 text-white px-4 py-2 rounded">View Programmes</a>
                </nav>
            </div>
        </div>
    </header>

    <!-- Hero Section -->
    <section class="bg-gray-50 py-16">
        <div class="container mx-auto px-4">
            <div class="max-w-4xl mx-auto text-center">
                <h1 class="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">Academic Programmes</h1>
                <p class="text-xl text-gray-600 leading-relaxed">
                    Discover our comprehensive range of undergraduate and graduate programs designed to prepare you for success in your chosen field.
                </p>
            </div>
        </div>
    </section>

    <!-- Programme Categories -->
    <section class="bg-white py-16">
        <div class="container mx-auto px-4">
            <div class="text-center mb-12">
                <h2 class="text-3xl font-bold text-gray-900 mb-4">Schools & Faculties</h2>
                <p class="text-gray-600 max-w-2xl mx-auto">
                    Choose from our diverse academic schools, each offering specialized programs with industry-relevant curriculum.
                </p>
            </div>
            
            <div class="grid lg:grid-cols-2 gap-8">
                <!-- School of Management and Social Sciences -->
                <div class="bg-gray-50 rounded-2xl p-8">
                    <div class="mb-6">
                        <img src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=500&h=300&fit=crop" 
                             alt="Business students in discussion" 
                             class="w-full h-48 object-cover rounded-lg">
                    </div>
                    <h3 class="text-2xl font-bold text-gray-900 mb-4">School of Management and Social Sciences</h3>
                    <p class="text-gray-600 mb-6">
                        Develop leadership skills and business acumen through our comprehensive management and social science programs.
                    </p>
                    
                    <div class="space-y-4">
                        <h4 class="font-semibold text-gray-900">Undergraduate Programs:</h4>
                        <ul class="space-y-2 text-gray-600">
                            <li>• Bachelor of Business Administration (BBA)</li>
                            <li>• Bachelor of Economics</li>
                            <li>• Bachelor of Psychology</li>
                            <li>• Bachelor of Sociology</li>
                            <li>• Bachelor of Political Science</li>
                        </ul>
                        
                        <h4 class="font-semibold text-gray-900 mt-6">Graduate Programs:</h4>
                        <ul class="space-y-2 text-gray-600">
                            <li>• Master of Business Administration (MBA)</li>
                            <li>• Master of Public Administration (MPA)</li>
                            <li>• Master of Social Work (MSW)</li>
                        </ul>
                    </div>
                    
                    <div class="mt-6">
                        <a href="/auth/register" class="bg-red-600 text-white px-6 py-3 rounded font-medium hover:bg-red-700 inline-block">
                            Apply Now
                        </a>
                    </div>
                </div>
                
                <!-- School of Applied Health Sciences -->
                <div class="bg-gray-50 rounded-2xl p-8">
                    <div class="mb-6">
                        <img src="https://images.unsplash.com/photo-1559757148-5c350d0d3c56?w=500&h=300&fit=crop" 
                             alt="Medical students in laboratory" 
                             class="w-full h-48 object-cover rounded-lg">
                    </div>
                    <h3 class="text-2xl font-bold text-gray-900 mb-4">School of Applied Health Sciences</h3>
                    <p class="text-gray-600 mb-6">
                        Prepare for a rewarding career in healthcare with our cutting-edge health science programs and clinical training.
                    </p>
                    
                    <div class="space-y-4">
                        <h4 class="font-semibold text-gray-900">Undergraduate Programs:</h4>
                        <ul class="space-y-2 text-gray-600">
                            <li>• Bachelor of Nursing (BSN)</li>
                            <li>• Bachelor of Public Health</li>
                            <li>• Bachelor of Health Information Management</li>
                            <li>• Bachelor of Medical Laboratory Science</li>
                            <li>• Bachelor of Physiotherapy</li>
                        </ul>
                        
                        <h4 class="font-semibold text-gray-900 mt-6">Graduate Programs:</h4>
                        <ul class="space-y-2 text-gray-600">
                            <li>• Master of Public Health (MPH)</li>
                            <li>• Master of Health Administration (MHA)</li>
                            <li>• Master of Nursing (MSN)</li>
                        </ul>
                    </div>
                    
                    <div class="mt-6">
                        <a href="/apply" class="bg-red-600 text-white px-6 py-3 rounded font-medium hover:bg-red-700 inline-block">
                            Apply Now
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Programme Features -->
    <section class="bg-gray-50 py-16">
        <div class="container mx-auto px-4">
            <div class="text-center mb-12">
                <h2 class="text-3xl font-bold text-gray-900 mb-4">Why Choose Our Programs?</h2>
                <p class="text-gray-600 max-w-2xl mx-auto">
                    Our academic programs are designed with your success in mind, offering practical experience and industry connections.
                </p>
            </div>
            
            <div class="grid md:grid-cols-3 gap-8">
                <div class="text-center">
                    <div class="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <div class="w-8 h-8 bg-red-600 rounded-full"></div>
                    </div>
                    <h3 class="text-xl font-bold text-gray-900 mb-4">Industry-Relevant Curriculum</h3>
                    <p class="text-gray-600">
                        Our programs are regularly updated to reflect current industry trends and employer needs, ensuring you graduate with relevant skills.
                    </p>
                </div>
                
                <div class="text-center">
                    <div class="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <div class="w-8 h-8 bg-red-600 rounded-full"></div>
                    </div>
                    <h3 class="text-xl font-bold text-gray-900 mb-4">Experienced Faculty</h3>
                    <p class="text-gray-600">
                        Learn from industry professionals with real-world experience who are dedicated to your success.
                    </p>
                    <p class="text-gray-600">
                        Our faculty members are committed to providing personalized support and mentorship throughout your academic journey.
                    </p>
                    <p class="text-gray-600">
                        With small class sizes, you'll receive individualized attention and guidance to help you succeed.
                    </p>
                </div>
            </div>
        </div>
    </section>

    <div class="border-t mt-8 pt-8 flex flex-col md:flex-row justify-between items-center text-sm text-gray-600">
                <p>© 2025 Geod University. All rights reserved.</p>
                <div class="flex space-x-6 mt-4 md:mt-0">
                    <a href="/privacy" class="hover:text-gray-900">Privacy Policy</a>
                    <a href="/terms" class="hover:text-gray-900">Terms of Service</a>
                    <a href="/cookies" class="hover:text-gray-900">Cookie Settings</a>
                </div>
            </div>
    </div>
</body>
</html>
