<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us - GEOD University</title>
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
</head>
<body class="bg-white">
    <!-- Header -->
    <header class="bg-white shadow-sm">
        <div class="container mx-auto px-4 py-4">
            <div class="flex items-center justify-between">
                <div class="flex items-center space-x-2">
                    <div class="w-8 h-8 bg-gray-800 rounded flex items-center justify-center">
                        <span class="text-white text-sm font-bold">★</span>
                    </div>
                    <span class="text-xl font-bold text-gray-800">GEOD</span>
                </div>
                
                <nav class="hidden md:flex items-center space-x-8">
                    <a href="/" class="text-gray-600 hover:text-gray-800">Home</a>
                    <a href="/about" class="text-gray-600 hover:text-gray-800">About</a>
                    <a href="/admissions" class="text-gray-600 hover:text-gray-800">Admissions</a>
                    <a href="/contact" class="text-red-600 font-medium">Contact</a>
                    <a href="/programmes" class="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700">View Programmes</a>
                </nav>
            </div>
        </div>
    </header>

    <!-- Hero Section -->
    <section class="bg-gray-50 py-16">
        <div class="container mx-auto px-4">
            <div class="max-w-4xl mx-auto text-center">
                <h1 class="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">Contact Us</h1>
                <p class="text-xl text-gray-600 leading-relaxed">
                    Get in touch with our admissions team or find the information you need to start your journey at GEOD University.
                </p>
            </div>
        </div>
    </section>

    <!-- Contact Form & Info -->
    <section class="bg-white py-16">
        <div class="container mx-auto px-4">
            <div class="grid lg:grid-cols-2 gap-12">
                <!-- Contact Form -->
                <div>
                    <h2 class="text-3xl font-bold text-gray-900 mb-6">Send us a Message</h2>
                    <form class="space-y-6">
                        <div class="grid md:grid-cols-2 gap-6">
                            <div>
                                <label for="first_name" class="block text-sm font-medium text-gray-700 mb-2">First Name</label>
                                <input type="text" id="first_name" name="first_name" 
                                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500">
                            </div>
                            <div>
                                <label for="last_name" class="block text-sm font-medium text-gray-700 mb-2">Last Name</label>
                                <input type="text" id="last_name" name="last_name" 
                                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500">
                            </div>
                        </div>
                        
                        <div>
                            <label for="email" class="block text-sm font-medium text-gray-700 mb-2">Email Address</label>
                            <input type="email" id="email" name="email" 
                                   class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500">
                        </div>
                        
                        <div>
                            <label for="phone" class="block text-sm font-medium text-gray-700 mb-2">Phone Number</label>
                            <input type="tel" id="phone" name="phone" 
                                   class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500">
                        </div>
                        
                        <div>
                            <label for="inquiry_type" class="block text-sm font-medium text-gray-700 mb-2">Inquiry Type</label>
                            <select id="inquiry_type" name="inquiry_type" 
                                    class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500">
                                <option value="">Select an option</option>
                                <option value="admissions">Admissions</option>
                                <option value="programs">Academic Programs</option>
                                <option value="financial_aid">Financial Aid</option>
                                <option value="campus_life">Campus Life</option>
                                <option value="other">Other</option>
                            </select>
                        </div>
                        
                        <div>
                            <label for="message" class="block text-sm font-medium text-gray-700 mb-2">Message</label>
                            <textarea id="message" name="message" rows="5" 
                                      class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
                                      placeholder="Tell us how we can help you..."></textarea>
                        </div>
                        
                        <button type="submit" 
                                class="w-full bg-red-600 text-white py-3 px-6 rounded-lg font-medium hover:bg-red-700 transition-colors">
                            Send Message
                        </button>
                    </form>
                </div>
                
                <!-- Contact Information -->
                <div>
                    <h2 class="text-3xl font-bold text-gray-900 mb-6">Get in Touch</h2>
                    
                    <div class="space-y-8">
                        <div>
                            <h3 class="text-lg font-semibold text-gray-900 mb-3">Campus Address</h3>
                            <p class="text-gray-600">
                                123 University Avenue<br>
                                Education City, EC 12345<br>
                                United States
                            </p>
                        </div>
                        
                        <div>
                            <h3 class="text-lg font-semibold text-gray-900 mb-3">Contact Information</h3>
                            <div class="space-y-2 text-gray-600">
                                <p><strong>Phone:</strong> (555) 123-4567</p>
                                <p><strong>Email:</strong> info@geod.edu</p>
                                <p><strong>Admissions:</strong> admissions@geod.edu</p>
                                <p><strong>Financial Aid:</strong> finaid@geod.edu</p>
                            </div>
                        </div>
                        
                        <div>
                            <h3 class="text-lg font-semibold text-gray-900 mb-3">Office Hours</h3>
                            <div class="space-y-1 text-gray-600">
                                <p><strong>Monday - Friday:</strong> 8:00 AM - 6:00 PM</p>
                                <p><strong>Saturday:</strong> 9:00 AM - 4:00 PM</p>
                                <p><strong>Sunday:</strong> Closed</p>
                            </div>
                        </div>
                        
                        <div>
                            <h3 class="text-lg font-semibold text-gray-900 mb-3">Follow Us</h3>
                            <div class="flex space-x-4">
                                <a href="#" class="w-10 h-10 bg-red-600 text-white rounded-full flex items-center justify-center hover:bg-red-700">
                                    <span class="sr-only">Facebook</span>
                                    <span class="text-sm">f</span>
                                </a>
                                <a href="#" class="w-10 h-10 bg-red-600 text-white rounded-full flex items-center justify-center hover:bg-red-700">
                                    <span class="sr-only">Twitter</span>
                                    <span class="text-sm">t</span>
                                </a>
                                <a href="#" class="w-10 h-10 bg-red-600 text-white rounded-full flex items-center justify-center hover:bg-red-700">
                                    <span class="sr-only">Instagram</span>
                                    <span class="text-sm">i</span>
                                </a>
                                <a href="#" class="w-10 h-10 bg-red-600 text-white rounded-full flex items-center justify-center hover:bg-red-700">
                                    <span class="sr-only">LinkedIn</span>
                                    <span class="text-sm">in</span>
                                </a>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mt-8">
                        <img src="https://images.unsplash.com/photo-1541339907198-e08756dedf3f?w=500&h=300&fit=crop" 
                             alt="University campus aerial view" 
                             class="rounded-lg w-full h-64 object-cover">
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-white border-t py-12">
        <div class="container mx-auto px-4">
            <div class="grid md:grid-cols-4 gap-8">
                <div>
                    <div class="flex items-center space-x-2 mb-4">
                        <div class="w-8 h-8 bg-gray-800 rounded flex items-center justify-center">
                            <span class="text-white text-sm font-bold">★</span>
                        </div>
                        <span class="text-xl font-bold text-gray-800">GEOD</span>
                    </div>
                    <p class="text-gray-600 text-sm">
                        Join us today to shape the leaders and visionaries of tomorrow.
                    </p>
                </div>
                
                <div>
                    <h4 class="font-semibold text-gray-900 mb-4">Quick Links</h4>
                    <ul class="space-y-2 text-sm text-gray-600">
                        <li><a href="/" class="hover:text-gray-900">Home</a></li>
                        <li><a href="/about" class="hover:text-gray-900">About</a></li>
                        <li><a href="/programmes" class="hover:text-gray-900">Programmes</a></li>
                        <li><a href="/contact" class="hover:text-gray-900">Contact</a></li>
                    </ul>
                </div>
                
                <div>
                    <h4 class="font-semibold text-gray-900 mb-4">Admissions</h4>
                    <ul class="space-y-2 text-sm text-gray-600">
                        <li><a href="/auth/register" class="hover:text-gray-900">Apply Now</a></li>
                        <li><a href="/requirements" class="hover:text-gray-900">Requirements</a></li>
                        <li><a href="/scholarships" class="hover:text-gray-900">Scholarships</a></li>
                        <li><a href="/tuition" class="hover:text-gray-900">Tuition & Fees</a></li>
                    </ul>
                </div>
                
                <div>
                    <h4 class="font-semibold text-gray-900 mb-4">Contact Info</h4>
                    <div class="space-y-2 text-sm text-gray-600">
                        <p>123 University Avenue</p>
                        <p>Education City, EC 12345</p>
                        <p>Phone: (555) 123-4567</p>
                        <p>Email: info@geod.edu</p>
                    </div>
                </div>
            </div>
            
            <div class="border-t mt-8 pt-8 text-center text-sm text-gray-600">
                <p>© 2025 GEOD University. All rights reserved.</p>
            </div>
        </div>
    </footer>
</body>
</html>
