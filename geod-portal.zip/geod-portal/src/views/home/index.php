<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GEOD University - Study a degree that secures your career</title>
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
</head>
<body class="bg-white">
    <!-- Header -->
    <header class="bg-white shadow-sm">
        <div class="container mx-auto px-4 py-4">
            <div class="flex items-center justify-between">
                <div class="flex items-center space-x-2">
                    <div class="w-8 h-8 bg-gray-800 rounded flex items-center justify-center">
                        <span class="text-white text-sm font-bold">★</span>
                    </div>
                    <span class="text-xl font-bold text-gray-800">GEOD</span>
                </div>
                
                <nav class="hidden md:flex items-center space-x-8">
                    <a href="/about" class="text-gray-600 hover:text-gray-800">About</a>
                    <a href="/admissions" class="text-gray-600 hover:text-gray-800">Admissions</a>
                    <a href="/contact" class="text-gray-600 hover:text-gray-800">Contact</a>
                    <a href="/programmes" class="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700">View Programmes</a>
                </nav>
            </div>
        </div>
    </header>

    <!-- Hero Section -->
    <section class="bg-white py-16">
        <div class="container mx-auto px-4">
            <div class="grid lg:grid-cols-2 gap-12 items-center">
                <div>
                    <p class="text-red-600 text-sm font-medium mb-4">GEOD UNIVERSITY</p>
                    <h1 class="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
                        Study a degree that secures your career
                    </h1>
                    <p class="text-gray-600 text-lg mb-8 leading-relaxed">
                        A vibrant space at Geod University, designed to inspire productivity, 
                        collaboration, and innovation - where students connect, focus flourish, 
                        and learning thrives.
                    </p>
                    <div class="flex flex-col sm:flex-row gap-4">
                        <a href="/auth/register" class="bg-red-600 text-white px-6 py-3 rounded font-medium hover:bg-red-700">
                            Apply Now
                        </a>
                        <a href="/programmes" class="border border-gray-300 text-gray-700 px-6 py-3 rounded font-medium hover:bg-gray-50">
                            View Programmes
                        </a>
                    </div>
                </div>
                
                <div class="relative">
                    <!-- Replaced placeholder with actual Unsplash images -->
                    <div class="grid grid-cols-3 gap-4 h-96">
                        <img src="https://images.unsplash.com/photo-1523240795612-9a054b0db644?w=200&h=300&fit=crop&crop=faces" 
                             alt="University students studying" 
                             class="w-full h-full object-cover rounded-2xl">
                        <img src="https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=200&h=350&fit=crop&crop=faces" 
                             alt="University campus life" 
                             class="w-full h-full object-cover rounded-2xl mt-8">
                        <img src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=200&h=320&fit=crop&crop=faces" 
                             alt="Students collaborating" 
                             class="w-full h-full object-cover rounded-2xl mt-4">
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section class="bg-gray-50 py-16">
        <div class="container mx-auto px-4">
            <div class="text-center mb-12">
                <p class="text-red-600 text-sm font-medium mb-4">ABOUT GEOD</p>
                <h2 class="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
                    Earn a career-ready degree from your home.
                </h2>
                <p class="text-gray-600 max-w-2xl mx-auto">
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros 
                    elementum tristique. Duis cursus, mi quis viverra ornare.
                </p>
            </div>
            
            <div class="grid md:grid-cols-3 gap-8">
                <div class="text-center">
                    <div class="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <div class="w-8 h-8 bg-red-600 rounded-full"></div>
                    </div>
                    <h3 class="text-xl font-bold text-gray-900 mb-4">No Application Fee</h3>
                    <p class="text-gray-600">
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. 
                        Suspendisse varius enim in eros elementum tristique. 
                        Duis cursus, mi quis viverra ornare.
                    </p>
                </div>
                
                <div class="text-center">
                    <div class="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <div class="w-8 h-8 bg-red-600 rounded-full"></div>
                    </div>
                    <h3 class="text-xl font-bold text-gray-900 mb-4">Value Two</h3>
                    <p class="text-gray-600">
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. 
                        Suspendisse varius enim in eros elementum tristique. 
                        Duis cursus, mi quis viverra ornare.
                    </p>
                </div>
                
                <div class="text-center">
                    <div class="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <div class="w-8 h-8 bg-red-600 rounded-full"></div>
                    </div>
                    <h3 class="text-xl font-bold text-gray-900 mb-4">Value Three</h3>
                    <p class="text-gray-600">
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. 
                        Suspendisse varius enim in eros elementum tristique. 
                        Duis cursus, mi quis viverra ornare.
                    </p>
                </div>
            </div>
        </div>
    </section>

    <!-- Admission Process -->
    <section class="bg-white py-16">
        <div class="container mx-auto px-4">
            <div class="grid lg:grid-cols-2 gap-12">
                <div>
                    <p class="text-red-600 text-sm font-medium mb-4">Admission Process</p>
                    <h2 class="text-3xl font-bold text-gray-900 mb-8">Start Learning with Geod</h2>
                    
                    <div class="space-y-8">
                        <div class="flex items-start space-x-4">
                            <div class="w-8 h-8 bg-red-600 text-white rounded-full flex items-center justify-center text-sm font-bold">1</div>
                            <div>
                                <h3 class="text-lg font-semibold text-gray-900 mb-2">Apply for a Degree</h3>
                                <p class="text-gray-600">Submit your application requirements depending on your course of study.</p>
                            </div>
                        </div>
                        
                        <div class="flex items-start space-x-4">
                            <div class="w-8 h-8 bg-red-600 text-white rounded-full flex items-center justify-center text-sm font-bold">2</div>
                            <div>
                                <h3 class="text-lg font-semibold text-gray-900 mb-2">Gain Admission</h3>
                                <p class="text-gray-600">The school team reviews your application and grants admission if eligible.</p>
                            </div>
                        </div>
                        
                        <div class="flex items-start space-x-4">
                            <div class="w-8 h-8 bg-red-600 text-white rounded-full flex items-center justify-center text-sm font-bold">3</div>
                            <div>
                                <h3 class="text-lg font-semibold text-gray-900 mb-2">Kick off</h3>
                                <p class="text-gray-600">Receive information about orientation and course enrollment, so you can get started with your classes.</p>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="lg:pl-8">
                    <div class="bg-gray-100 rounded-2xl p-8 h-full flex items-center justify-center">
                        <!-- Replaced placeholder with Unsplash image -->
                        <img src="https://images.unsplash.com/photo-1607013251379-e6eecfffe234?w=400&h=500&fit=crop&crop=faces" 
                             alt="Happy university student with backpack" 
                             class="rounded-lg max-w-full h-auto">
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="bg-gray-900 py-16">
        <div class="container mx-auto px-4 text-center">
            <p class="text-red-400 text-sm font-medium mb-4">2025 SEPTEMBER ADMISSIONS</p>
            <h2 class="text-3xl lg:text-4xl font-bold text-white mb-6">Apply for Admission</h2>
            <p class="text-gray-300 mb-8 max-w-2xl mx-auto">
                Ready to take the next step towards a future filled with limitless opportunities? Apply for admission today!
            </p>
            <a href="/auth/register" class="bg-red-600 text-white px-8 py-3 rounded font-medium hover:bg-red-700 inline-block">
                Apply
            </a>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-white border-t py-12">
        <div class="container mx-auto px-4">
            <div class="grid md:grid-cols-4 gap-8">
                <div>
                    <div class="flex items-center space-x-2 mb-4">
                        <div class="w-8 h-8 bg-gray-800 rounded flex items-center justify-center">
                            <span class="text-white text-sm font-bold">★</span>
                        </div>
                        <span class="text-xl font-bold text-gray-800">GEOD</span>
                    </div>
                    <p class="text-gray-600 text-sm">
                        Join us today to shape the leaders and visionaries of tomorrow.
                    </p>
                </div>
                
                <div>
                    <h4 class="font-semibold text-gray-900 mb-4">The University</h4>
                    <ul class="space-y-2 text-sm text-gray-600">
                        <li><a href="/about" class="hover:text-gray-900">About</a></li>
                        <li><a href="/admissions" class="hover:text-gray-900">School of Management and Social Sciences</a></li>
                        <li><a href="/programmes" class="hover:text-gray-900">School of Applied Health Sciences</a></li>
                        <li><a href="/services" class="hover:text-gray-900">Services</a></li>
                    </ul>
                </div>
                
                <div>
                    <h4 class="font-semibold text-gray-900 mb-4">Studying</h4>
                    <ul class="space-y-2 text-sm text-gray-600">
                        <li><a href="/programmes" class="hover:text-gray-900">School of Management and Social Sciences</a></li>
                        <li><a href="/programmes" class="hover:text-gray-900">School of Applied Health Sciences</a></li>
                        <li><a href="/services" class="hover:text-gray-900">Services</a></li>
                        <li><a href="/business" class="hover:text-gray-900">Work Business School</a></li>
                    </ul>
                </div>
                
                <div>
                    <h4 class="font-semibold text-gray-900 mb-4">Follow Us</h4>
                    <div class="flex space-x-4">
                        <a href="#" class="text-gray-400 hover:text-gray-600">
                            <span class="sr-only">Facebook</span>
                            <div class="w-6 h-6 bg-gray-400 rounded"></div>
                        </a>
                        <a href="#" class="text-gray-400 hover:text-gray-600">
                            <span class="sr-only">Instagram</span>
                            <div class="w-6 h-6 bg-gray-400 rounded"></div>
                        </a>
                        <a href="#" class="text-gray-400 hover:text-gray-600">
                            <span class="sr-only">LinkedIn</span>
                            <div class="w-6 h-6 bg-gray-400 rounded"></div>
                        </a>
                        <a href="#" class="text-gray-400 hover:text-gray-600">
                            <span class="sr-only">Twitter</span>
                            <div class="w-6 h-6 bg-gray-400 rounded"></div>
                        </a>
                    </div>
                </div>
            </div>
            
            <div class="border-t mt-8 pt-8 flex flex-col md:flex-row justify-between items-center text-sm text-gray-600">
                <p>© 2025 Geod University. All rights reserved.</p>
                <div class="flex space-x-6 mt-4 md:mt-0">
                    <a href="/privacy" class="hover:text-gray-900">Privacy Policy</a>
                    <a href="/terms" class="hover:text-gray-900">Terms of Service</a>
                    <a href="/cookies" class="hover:text-gray-900">Cookie Settings</a>
                </div>
            </div>
        </div>
    </footer>
</body>
</html>
