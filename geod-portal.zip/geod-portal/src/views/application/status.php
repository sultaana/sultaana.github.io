<?php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $title; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        body { font-family: 'Inter', sans-serif; }
    </style>
</head>
<body class="bg-gray-50">
    <!-- Navigation -->
    <nav class="bg-white shadow-sm border-b">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center h-16">
                <div class="flex items-center">
                    <span class="text-xl font-bold text-gray-900">GEOD UNIVERSITY</span>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="/dashboard" class="text-gray-700 hover:text-gray-900">Dashboard</a>
                    <a href="/auth/logout" class="text-red-600 hover:text-red-800">Logout</a>
                </div>
            </div>
        </div>
    </nav>

    <div class="max-w-4xl mx-auto py-8 px-4">
        <!-- Flash Messages -->
        <?php if (Session::flash('success')): ?>
            <div class="bg-green-50 border border-green-200 text-green-700 px-6 py-4 rounded-lg mb-6">
                <div class="flex">
                    <svg class="h-5 w-5 text-green-400 mr-2" fill="currentColor" viewBox="0 0 20 20">
                        <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path>
                    </svg>
                    <?php echo Session::flash('success'); ?>
                </div>
            </div>
        <?php endif; ?>

        <!-- Application Status Header -->
        <div class="bg-white rounded-lg shadow-lg overflow-hidden mb-6">
            <div class="bg-red-600 text-white px-6 py-4">
                <h1 class="text-2xl font-bold">Application Status</h1>
                <p class="text-red-100">Track your admission application progress</p>
            </div>

            <div class="p-6">
                <!-- Application Overview -->
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                    <div class="text-center">
                        <div class="text-3xl font-bold text-gray-900">GU-APP-<?php echo $application['id']; ?></div>
                        <div class="text-sm text-gray-600">Application ID</div>
                    </div>
                    <div class="text-center">
                        <div class="text-3xl font-bold text-blue-600"><?php echo ucfirst($application['status']); ?></div>
                        <div class="text-sm text-gray-600">Current Status</div>
                    </div>
                    <div class="text-center">
                        <div class="text-3xl font-bold text-green-600"><?php echo $application['aggregate_score']; ?>%</div>
                        <div class="text-sm text-gray-600">Aggregate Score</div>
                    </div>
                </div>

                <!-- Status Progress -->
                <div class="mb-8">
                    <h3 class="text-lg font-semibold text-gray-900 mb-4">Application Progress</h3>
                    <div class="flex items-center justify-between">
                        <!-- Step 1: Submitted -->
                        <div class="flex flex-col items-center">
                            <div class="w-10 h-10 bg-green-500 rounded-full flex items-center justify-center text-white font-bold mb-2">
                                ✓
                            </div>
                            <span class="text-sm font-medium text-gray-900">Submitted</span>
                            <span class="text-xs text-gray-500"><?php echo date('M j, Y', strtotime($application['submitted_at'])); ?></span>
                        </div>
                        
                        <!-- Progress Line -->
                        <div class="flex-1 h-1 mx-4 <?php echo in_array($application['status'], ['screening', 'approved', 'rejected']) ? 'bg-green-500' : 'bg-gray-300'; ?>"></div>
                        
                        <!-- Step 2: Under Review -->
                        <div class="flex flex-col items-center">
                            <div class="w-10 h-10 <?php echo in_array($application['status'], ['screening', 'approved', 'rejected']) ? 'bg-green-500' : ($application['status'] === 'pending' ? 'bg-yellow-500' : 'bg-gray-300'); ?> rounded-full flex items-center justify-center text-white font-bold mb-2">
                                <?php echo in_array($application['status'], ['screening', 'approved', 'rejected']) ? '✓' : '2'; ?>
                            </div>
                            <span class="text-sm font-medium text-gray-900">Under Review</span>
                            <span class="text-xs text-gray-500">In Progress</span>
                        </div>
                        
                        <!-- Progress Line -->
                        <div class="flex-1 h-1 mx-4 <?php echo in_array($application['status'], ['approved', 'rejected']) ? 'bg-green-500' : 'bg-gray-300'; ?>"></div>
                        
                        <!-- Step 3: Decision -->
                        <div class="flex flex-col items-center">
                            <div class="w-10 h-10 <?php echo $application['status'] === 'approved' ? 'bg-green-500' : ($application['status'] === 'rejected' ? 'bg-red-500' : 'bg-gray-300'); ?> rounded-full flex items-center justify-center text-white font-bold mb-2">
                                <?php echo $application['status'] === 'approved' ? '✓' : ($application['status'] === 'rejected' ? '✗' : '3'); ?>
                            </div>
                            <span class="text-sm font-medium text-gray-900">Decision</span>
                            <span class="text-xs text-gray-500">
                                <?php echo $application['status'] === 'approved' ? 'Approved' : ($application['status'] === 'rejected' ? 'Rejected' : 'Pending'); ?>
                            </span>
                        </div>
                    </div>
                </div>

                <!-- Application Details -->
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <h3 class="text-lg font-semibold text-gray-900 mb-4">Application Details</h3>
                        <div class="space-y-3">
                            <div class="flex justify-between">
                                <span class="text-gray-600">Programme:</span>
                                <span class="font-medium"><?php echo htmlspecialchars($application['program']); ?></span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-gray-600">Faculty:</span>
                                <span class="font-medium"><?php echo htmlspecialchars($application['faculty_name'] ?? 'N/A'); ?></span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-gray-600">JAMB Reg No:</span>
                                <span class="font-medium"><?php echo htmlspecialchars($application['jamb_reg_no']); ?></span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-gray-600">JAMB Score:</span>
                                <span class="font-medium"><?php echo $application['jamb_score']; ?>/400</span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-gray-600">WAEC Grade:</span>
                                <span class="font-medium"><?php echo htmlspecialchars($application['waec_grade']); ?></span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-gray-600">Post-UTME Score:</span>
                                <span class="font-medium"><?php echo $application['post_utme_score']; ?>/100</span>
                            </div>
                        </div>
                    </div>

                    <div>
                        <h3 class="text-lg font-semibold text-gray-900 mb-4">Payment Status</h3>
                        <?php if ($payment): ?>
                            <div class="space-y-3">
                                <div class="flex justify-between">
                                    <span class="text-gray-600">Application Fee:</span>
                                    <span class="font-medium <?php echo $payment['status'] === 'completed' ? 'text-green-600' : 'text-yellow-600'; ?>">
                                        ₦<?php echo number_format($payment['amount'], 2); ?> 
                                        (<?php echo ucfirst($payment['status']); ?>)
                                    </span>
                                </div>
                                <div class="flex justify-between">
                                    <span class="text-gray-600">Reference:</span>
                                    <span class="font-medium text-sm"><?php echo htmlspecialchars($payment['reference']); ?></span>
                                </div>
                                <?php if ($payment['paid_at']): ?>
                                    <div class="flex justify-between">
                                        <span class="text-gray-600">Paid On:</span>
                                        <span class="font-medium"><?php echo date('M j, Y g:i A', strtotime($payment['paid_at'])); ?></span>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php else: ?>
                            <p class="text-gray-600">No payment records found.</p>
                        <?php endif; ?>

                        <?php if ($payment && $payment['status'] === 'pending'): ?>
                            <div class="mt-4">
                                <a 
                                    href="/payments/fees" 
                                    class="w-full bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700 focus:ring-2 focus:ring-green-500 focus:ring-offset-2 transition-colors font-medium text-center block"
                                >
                                    Pay Application Fee
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Status-specific Messages -->
        <?php if ($application['status'] === 'pending'): ?>
            <div class="bg-yellow-50 border border-yellow-200 rounded-lg p-6">
                <div class="flex">
                    <svg class="h-6 w-6 text-yellow-400 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L4.082 15.5c-.77.833.192 2.5 1.732 2.5z"></path>
                    </svg>
                    <div>
                        <h3 class="text-lg font-medium text-yellow-800 mb-2">Application Under Review</h3>
                        <p class="text-yellow-700">
                            Your application is currently being reviewed by our admissions team. 
                            Please ensure you have completed payment of your application fee. 
                            You will be notified via email once a decision has been made.
                        </p>
                    </div>
                </div>
            </div>
        <?php elseif ($application['status'] === 'approved'): ?>
            <div class="bg-green-50 border border-green-200 rounded-lg p-6">
                <div class="flex">
                    <svg class="h-6 w-6 text-green-400 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                    </svg>
                    <div>
                        <h3 class="text-lg font-medium text-green-800 mb-2">🎉 Congratulations! You've been admitted!</h3>
                        <p class="text-green-700 mb-4">
                            Your application has been approved. You are now a GEOD University student! 
                            Please proceed with the next steps to complete your enrollment.
                        </p>
                        <div class="space-y-2">
                            <a href="/payments/fees" class="inline-block bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors">
                                Pay Acceptance Fee
                            </a>
                            <a href="/courses" class="inline-block bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors ml-2">
                                Register for Courses
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        <?php elseif ($application['status'] === 'rejected'): ?>
            <div class="bg-red-50 border border-red-200 rounded-lg p-6">
                <div class="flex">
                    <svg class="h-6 w-6 text-red-400 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L4.082 15.5c-.77.833.192 2.5 1.732 2.5z"></path>
                    </svg>
                    <div>
                        <h3 class="text-lg font-medium text-red-800 mb-2">Application Not Successful</h3>
                        <p class="text-red-700 mb-4">
                            Unfortunately, your application was not successful for this academic session. 
                            We encourage you to consider applying for other programs or reapply for the next session.
                        </p>
                        <?php if ($application['notes']): ?>
                            <div class="bg-red-100 p-3 rounded border border-red-200 mb-4">
                                <p class="text-red-800 text-sm"><strong>Notes:</strong> <?php echo htmlspecialchars($application['notes']); ?></p>
                            </div>
                        <?php endif; ?>
                        <a href="/contact" class="inline-block bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors">
                            Contact Admissions Office
                        </a>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <!-- Quick Links -->
        <div class="mt-8 grid grid-cols-1 md:grid-cols-3 gap-4">
            <a href="/dashboard" class="bg-white p-4 rounded-lg shadow border hover:shadow-md transition-shadow">
                <div class="text-center">
                    <svg class="h-8 w-8 text-blue-600 mx-auto mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2H5a2 2 0 00-2-2z"></path>
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3a2 2 0 012-2h4a2 2 0 012 2v4m-6 4l2 2 4-4"></path>
                    </svg>
                    <h3 class="font-medium text-gray-900">Dashboard</h3>
                    <p class="text-sm text-gray-600">Go to main dashboard</p>
                </div>
            </a>
            
            <a href="/payments" class="bg-white p-4 rounded-lg shadow border hover:shadow-md transition-shadow">
                <div class="text-center">
                    <svg class="h-8 w-8 text-green-600 mx-auto mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z"></path>
                    </svg>
                    <h3 class="font-medium text-gray-900">Payments</h3>
                    <p class="text-sm text-gray-600">View payment history</p>
                </div>
            </a>
            
            <a href="/messages" class="bg-white p-4 rounded-lg shadow border hover:shadow-md transition-shadow">
                <div class="text-center">
                    <svg class="h-8 w-8 text-purple-600 mx-auto mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"></path>
                    </svg>
                    <h3 class="font-medium text-gray-900">Messages</h3>
                    <p class="text-sm text-gray-600">Check messages</p>
                </div>
            </a>
        </div>
    </div>
</body>
</html>