<?php
$oldInput = Session::flash('old_input') ?? [];
$errors = Session::flash('errors') ?? [];
$errorMessage = Session::flash('error');

// Pre-populate from user profile
$fullName = trim(($profile['first_name'] ?? '') . ' ' . ($profile['last_name'] ?? ''));
$phone = $profile['phone'] ?? '';
$email = $profile['email'] ?? '';
$address = $profile['address'] !== 'To be updated during application' ? $profile['address'] : '';
$stateOfOrigin = $profile['state_of_origin'] ?? '';
$lga = $profile['lga'] ?? '';
$gender = $profile['gender'] ?? '';

$additionalStyles = '
<style>
    .form-section {
        background: white;
        border-radius: 12px;
        box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1);
        margin-bottom: 2rem;
    }
    .form-input {
        transition: all 0.2s ease;
        border: 1.5px solid #e5e7eb;
    }
    .form-input:focus {
        border-color: #3b82f6;
        box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        outline: none;
    }
    .form-input.error {
        border-color: #ef4444;
        background-color: #fef2f2;
    }
    .section-header {
        border-left: 4px solid #3b82f6;
        padding-left: 1rem;
    }
    .upload-area {
        border: 2px dashed #d1d5db;
        border-radius: 8px;
        padding: 24px;
        text-align: center;
        transition: all 0.3s ease;
        cursor: pointer;
    }
    .upload-area:hover, .upload-area.dragover {
        border-color: #3b82f6;
        background-color: #f8fafc;
    }
    .submit-btn {
        background: linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%);
        transition: all 0.3s ease;
    }
    .submit-btn:hover {
        transform: translateY(-1px);
        box-shadow: 0 10px 25px rgba(59, 130, 246, 0.3);
    }
</style>';

$additionalScripts = '
<script>
function loadDepartments(facultyId) {
    const departmentSelect = document.getElementById("department_select");
    departmentSelect.innerHTML = "<option value=\"\">Loading...</option>";
    departmentSelect.disabled = true;
    
    if (!facultyId) {
        departmentSelect.innerHTML = "<option value=\"\">Select Programme</option>";
        return;
    }
    
    fetch(`/api/application/departments/${facultyId}`)
        .then(response => response.json())
        .then(data => {
            departmentSelect.innerHTML = "<option value=\"\">Select Programme</option>";
            
            if (data.departments && data.departments.length > 0) {
                data.departments.forEach(dept => {
                    const option = document.createElement("option");
                    option.value = dept.id;
                    option.textContent = dept.name;
                    departmentSelect.appendChild(option);
                });
                departmentSelect.disabled = false;
            } else {
                departmentSelect.innerHTML = "<option value=\"\">No programmes available</option>";
            }
        })
        .catch(error => {
            console.error("Error loading departments:", error);
            departmentSelect.innerHTML = "<option value=\"\">Error loading programmes</option>";
        });
}

function loadLGAs(stateId) {
    const lgaSelect = document.getElementById("lga_select");
    lgaSelect.innerHTML = "<option value=\"\">Loading...</option>";
    lgaSelect.disabled = true;
    
    if (!stateId) {
        lgaSelect.innerHTML = "<option value=\"\">Select LGA</option>";
        return;
    }
    
    fetch(`/api/application/lgas/${stateId}`)
        .then(response => response.json())
        .then(data => {
            lgaSelect.innerHTML = "<option value=\"\">Select LGA</option>";
            
            if (data.lgas && data.lgas.length > 0) {
                data.lgas.forEach(lga => {
                    const option = document.createElement("option");
                    option.value = lga.name;
                    option.textContent = lga.name;
                    lgaSelect.appendChild(option);
                });
                lgaSelect.disabled = false;
            } else {
                lgaSelect.innerHTML = "<option value=\"\">No LGAs available</option>";
            }
        })
        .catch(error => {
            console.error("Error loading LGAs:", error);
            lgaSelect.innerHTML = "<option value=\"\">Error loading LGAs</option>";
        });
}

// File upload handlers
function setupFileUpload(inputId, previewId) {
    const input = document.getElementById(inputId);
    const preview = document.getElementById(previewId);
    
    input.addEventListener("change", function(e) {
        const file = e.target.files[0];
        if (file) {
            const fileName = file.name;
            const fileSize = (file.size / 1024 / 1024).toFixed(2);
            preview.innerHTML = `
                <div class="flex items-center justify-between p-3 bg-green-50 border border-green-200 rounded-lg">
                    <div>
                        <p class="font-medium text-green-800">${fileName}</p>
                        <p class="text-sm text-green-600">${fileSize} MB</p>
                    </div>
                    <svg class="w-5 h-5 text-green-500" fill="currentColor" viewBox="0 0 20 20">
                        <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path>
                    </svg>
                </div>
            `;
        }
    });
}

document.addEventListener("DOMContentLoaded", function() {
    setupFileUpload("olevel_certificate", "olevel_preview");
    setupFileUpload("jamb_result", "jamb_preview");
    setupFileUpload("birth_certificate", "birth_preview");
    setupFileUpload("passport_photo", "passport_preview");
});
</script>';

ob_start();
?>

<!-- Navigation -->
<nav class="bg-white shadow-sm border-b">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex justify-between items-center h-16">
            <div class="flex items-center">
                <div class="flex-shrink-0">
                    <span class="text-xl font-bold text-gray-900">GEOD UNIVERSITY</span>
                </div>
            </div>
            <div class="flex items-center space-x-8">
                <a href="/dashboard" class="text-gray-700 hover:text-gray-900 transition-colors">Dashboard</a>
                <a href="/application/status" class="text-gray-700 hover:text-gray-900 transition-colors">Application Status</a>
                <a href="/auth/logout" class="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors">Logout</a>
            </div>
        </div>
    </div>
</nav>

<!-- Header Section -->
<div class="bg-white border-b">
    <div class="max-w-4xl mx-auto py-12 px-4 text-center">
        <h1 class="text-4xl font-bold text-gray-900 mb-4">University Application</h1>
        <p class="text-lg text-gray-600">Complete your application to GEOD University. All fields are required.</p>
    </div>
</div>

<!-- Main Content -->
<div class="max-w-4xl mx-auto py-8 px-4">
    
    <!-- Error Messages -->
    <?php if ($errorMessage): ?>
        <div class="bg-red-50 border-l-4 border-red-400 p-4 rounded-r-lg mb-6">
            <div class="flex">
                <div class="flex-shrink-0">
                    <svg class="h-5 w-5 text-red-400" fill="currentColor" viewBox="0 0 20 20">
                        <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"></path>
                    </svg>
                </div>
                <div class="ml-3">
                    <h3 class="text-sm font-medium text-red-800"><?php echo htmlspecialchars($errorMessage); ?></h3>
                    <?php if (!empty($errors)): ?>
                        <ul class="mt-2 text-sm text-red-700 space-y-1">
                            <?php foreach ($errors as $field => $fieldErrors): ?>
                                <?php foreach ($fieldErrors as $error): ?>
                                    <li class="flex items-center">
                                        <span class="w-1 h-1 bg-red-400 rounded-full mr-2"></span>
                                        <?php echo htmlspecialchars($error); ?>
                                    </li>
                                <?php endforeach; ?>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <form method="POST" action="/application" enctype="multipart/form-data" class="space-y-8">
        <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
        
        <!-- Personal Information -->
        <div class="form-section p-8">
            <div class="section-header mb-6">
                <h2 class="text-2xl font-semibold text-gray-900">Personal Information</h2>
                <p class="text-gray-600 mt-1">Please provide your personal details</p>
            </div>
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <!-- Full Name -->
                <div class="md:col-span-2">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Full Name *</label>
                    <input 
                        type="text" 
                        name="full_name" 
                        value="<?php echo htmlspecialchars($oldInput['full_name'] ?? $fullName); ?>"
                        class="form-input w-full px-4 py-3 rounded-lg <?php echo isset($errors['full_name']) ? 'error' : ''; ?>"
                        placeholder="Enter your full name"
                        required
                    >
                    <?php if (isset($errors['full_name'])): ?>
                        <p class="mt-1 text-sm text-red-600"><?php echo $errors['full_name'][0]; ?></p>
                    <?php endif; ?>
                </div>

                <!-- Email -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Email Address *</label>
                    <input 
                        type="email" 
                        name="email"
                        value="<?php echo htmlspecialchars($oldInput['email'] ?? $email); ?>"
                        class="form-input w-full px-4 py-3 rounded-lg <?php echo isset($errors['email']) ? 'error' : ''; ?>"
                        placeholder="your.email@example.com"
                        required
                    >
                    <?php if (isset($errors['email'])): ?>
                        <p class="mt-1 text-sm text-red-600"><?php echo $errors['email'][0]; ?></p>
                    <?php endif; ?>
                </div>

                <!-- Phone -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Phone Number *</label>
                    <div class="flex">
                        <span class="inline-flex items-center px-3 rounded-l-lg border border-r-0 border-gray-300 bg-gray-50 text-gray-500 text-sm">
                            +234
                        </span>
                        <input 
                            type="tel" 
                            name="phone"
                            value="<?php echo htmlspecialchars($oldInput['phone'] ?? $phone); ?>"
                            class="form-input flex-1 px-4 py-3 rounded-r-lg <?php echo isset($errors['phone']) ? 'error' : ''; ?>"
                            placeholder="8012345678"
                            required
                        >
                    </div>
                    <?php if (isset($errors['phone'])): ?>
                        <p class="mt-1 text-sm text-red-600"><?php echo $errors['phone'][0]; ?></p>
                    <?php endif; ?>
                </div>

                <!-- Date of Birth -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Date of Birth *</label>
                    <input 
                        type="date" 
                        name="date_of_birth"
                        value="<?php echo htmlspecialchars($oldInput['date_of_birth'] ?? ''); ?>"
                        class="form-input w-full px-4 py-3 rounded-lg <?php echo isset($errors['date_of_birth']) ? 'error' : ''; ?>"
                        required
                    >
                    <?php if (isset($errors['date_of_birth'])): ?>
                        <p class="mt-1 text-sm text-red-600"><?php echo $errors['date_of_birth'][0]; ?></p>
                    <?php endif; ?>
                </div>

                <!-- Gender -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Gender *</label>
                    <select 
                        name="gender"
                        class="form-input w-full px-4 py-3 rounded-lg <?php echo isset($errors['gender']) ? 'error' : ''; ?>"
                        required
                    >
                        <option value="">Select Gender</option>
                        <option value="Male" <?php echo ($oldInput['gender'] ?? $gender) === 'Male' ? 'selected' : ''; ?>>Male</option>
                        <option value="Female" <?php echo ($oldInput['gender'] ?? $gender) === 'Female' ? 'selected' : ''; ?>>Female</option>
                    </select>
                    <?php if (isset($errors['gender'])): ?>
                        <p class="mt-1 text-sm text-red-600"><?php echo $errors['gender'][0]; ?></p>
                    <?php endif; ?>
                </div>

                <!-- Nationality -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Nationality *</label>
                    <select 
                        name="nationality"
                        class="form-input w-full px-4 py-3 rounded-lg"
                        required
                    >
                        <option value="Nigerian" selected>Nigerian</option>
                        <option value="Other">Other</option>
                    </select>
                </div>
            </div>
        </div>

        <!-- Contact Information -->
        <div class="form-section p-8">
            <div class="section-header mb-6">
                <h2 class="text-2xl font-semibold text-gray-900">Contact Information</h2>
                <p class="text-gray-600 mt-1">Your current address and origin details</p>
            </div>
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <!-- Address -->
                <div class="md:col-span-2">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Current Address *</label>
                    <textarea 
                        name="address"
                        rows="3"
                        class="form-input w-full px-4 py-3 rounded-lg <?php echo isset($errors['address']) ? 'error' : ''; ?>"
                        placeholder="Enter your full current address"
                        required
                    ><?php echo htmlspecialchars($oldInput['address'] ?? $address); ?></textarea>
                    <?php if (isset($errors['address'])): ?>
                        <p class="mt-1 text-sm text-red-600"><?php echo $errors['address'][0]; ?></p>
                    <?php endif; ?>
                </div>

                <!-- State of Origin -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">State of Origin *</label>
                    <select 
                        name="state_of_origin"
                        id="state_select"
                        class="form-input w-full px-4 py-3 rounded-lg <?php echo isset($errors['state_of_origin']) ? 'error' : ''; ?>"
                        onchange="loadLGAs(this.options[this.selectedIndex].dataset.id)"
                        required
                    >
                        <option value="">Select State</option>
                        <?php foreach ($states as $state): ?>
                            <option 
                                value="<?php echo htmlspecialchars($state['name']); ?>"
                                data-id="<?php echo $state['id']; ?>"
                                <?php echo ($oldInput['state_of_origin'] ?? $stateOfOrigin) === $state['name'] ? 'selected' : ''; ?>
                            >
                                <?php echo htmlspecialchars($state['name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <?php if (isset($errors['state_of_origin'])): ?>
                        <p class="mt-1 text-sm text-red-600"><?php echo $errors['state_of_origin'][0]; ?></p>
                    <?php endif; ?>
                </div>

                <!-- LGA -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Local Government Area *</label>
                    <select 
                        name="lga"
                        id="lga_select"
                        class="form-input w-full px-4 py-3 rounded-lg <?php echo isset($errors['lga']) ? 'error' : ''; ?>"
                        required
                        disabled
                    >
                        <option value="">Select LGA</option>
                    </select>
                    <?php if (isset($errors['lga'])): ?>
                        <p class="mt-1 text-sm text-red-600"><?php echo $errors['lga'][0]; ?></p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Academic Information -->
        <div class="form-section p-8">
            <div class="section-header mb-6">
                <h2 class="text-2xl font-semibold text-gray-900">Academic Information</h2>
                <p class="text-gray-600 mt-1">Your educational background and programme choice</p>
            </div>
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <!-- Faculty -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Faculty *</label>
                    <select 
                        name="faculty_id" 
                        id="faculty_select"
                        class="form-input w-full px-4 py-3 rounded-lg <?php echo isset($errors['faculty_id']) ? 'error' : ''; ?>"
                        onchange="loadDepartments(this.value)"
                        required
                    >
                        <option value="">Select Faculty</option>
                        <?php foreach ($faculties as $faculty): ?>
                            <option 
                                value="<?php echo $faculty['id']; ?>"
                                <?php echo ($oldInput['faculty_id'] ?? '') == $faculty['id'] ? 'selected' : ''; ?>
                            >
                                <?php echo htmlspecialchars($faculty['name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <?php if (isset($errors['faculty_id'])): ?>
                        <p class="mt-1 text-sm text-red-600"><?php echo $errors['faculty_id'][0]; ?></p>
                    <?php endif; ?>
                </div>

                <!-- Department -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Programme *</label>
                    <select 
                        name="department_id" 
                        id="department_select"
                        class="form-input w-full px-4 py-3 rounded-lg <?php echo isset($errors['department_id']) ? 'error' : ''; ?>"
                        required
                        disabled
                    >
                        <option value="">Select Programme</option>
                    </select>
                    <?php if (isset($errors['department_id'])): ?>
                        <p class="mt-1 text-sm text-red-600"><?php echo $errors['department_id'][0]; ?></p>
                    <?php endif; ?>
                </div>

                <!-- JAMB Registration -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">JAMB Registration Number *</label>
                    <input 
                        type="text" 
                        name="jamb_reg_no"
                        value="<?php echo htmlspecialchars($oldInput['jamb_reg_no'] ?? ''); ?>"
                        class="form-input w-full px-4 py-3 rounded-lg <?php echo isset($errors['jamb_reg_no']) ? 'error' : ''; ?>"
                        placeholder="e.g., 12345678AB"
                        required
                    >
                    <?php if (isset($errors['jamb_reg_no'])): ?>
                        <p class="mt-1 text-sm text-red-600"><?php echo $errors['jamb_reg_no'][0]; ?></p>
                    <?php endif; ?>
                </div>

                <!-- JAMB Score -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">JAMB Score *</label>
                    <input 
                        type="number" 
                        name="jamb_score"
                        min="160"
                        max="400"
                        value="<?php echo htmlspecialchars($oldInput['jamb_score'] ?? ''); ?>"
                        class="form-input w-full px-4 py-3 rounded-lg <?php echo isset($errors['jamb_score']) ? 'error' : ''; ?>"
                        placeholder="e.g., 280"
                        required
                    >
                    <?php if (isset($errors['jamb_score'])): ?>
                        <p class="mt-1 text-sm text-red-600"><?php echo $errors['jamb_score'][0]; ?></p>
                    <?php endif; ?>
                </div>

                <!-- WAEC Year -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">WAEC Year *</label>
                    <input 
                        type="number" 
                        name="waec_year"
                        min="<?php echo date('Y') - 10; ?>"
                        max="<?php echo date('Y'); ?>"
                        value="<?php echo htmlspecialchars($oldInput['waec_year'] ?? ''); ?>"
                        class="form-input w-full px-4 py-3 rounded-lg <?php echo isset($errors['waec_year']) ? 'error' : ''; ?>"
                        placeholder="e.g., <?php echo date('Y'); ?>"
                        required
                    >
                    <?php if (isset($errors['waec_year'])): ?>
                        <p class="mt-1 text-sm text-red-600"><?php echo $errors['waec_year'][0]; ?></p>
                    <?php endif; ?>
                </div>

                <!-- WAEC Results -->
                <div class="md:col-span-2">
                    <label class="block text-sm font-medium text-gray-700 mb-3">WAEC/NECO Results *</label>
                    <div class="bg-gray-50 p-4 rounded-lg">
                        <p class="text-sm text-gray-600 mb-4">Please enter your O-Level results for at least 5 subjects including English Language and Mathematics</p>
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <!-- English Language (Required) -->
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">English Language *</label>
                                <select name="waec_english" class="form-input w-full px-3 py-2 rounded-lg" required>
                                    <option value="">Select Grade</option>
                                    <option value="A1" <?php echo ($oldInput['waec_english'] ?? '') === 'A1' ? 'selected' : ''; ?>>A1 (Excellent)</option>
                                    <option value="B2" <?php echo ($oldInput['waec_english'] ?? '') === 'B2' ? 'selected' : ''; ?>>B2 (Very Good)</option>
                                    <option value="B3" <?php echo ($oldInput['waec_english'] ?? '') === 'B3' ? 'selected' : ''; ?>>B3 (Good)</option>
                                    <option value="C4" <?php echo ($oldInput['waec_english'] ?? '') === 'C4' ? 'selected' : ''; ?>>C4 (Credit)</option>
                                    <option value="C5" <?php echo ($oldInput['waec_english'] ?? '') === 'C5' ? 'selected' : ''; ?>>C5 (Credit)</option>
                                    <option value="C6" <?php echo ($oldInput['waec_english'] ?? '') === 'C6' ? 'selected' : ''; ?>>C6 (Credit)</option>
                                    <option value="D7" <?php echo ($oldInput['waec_english'] ?? '') === 'D7' ? 'selected' : ''; ?>>D7 (Pass)</option>
                                    <option value="E8" <?php echo ($oldInput['waec_english'] ?? '') === 'E8' ? 'selected' : ''; ?>>E8 (Pass)</option>
                                    <option value="F9" <?php echo ($oldInput['waec_english'] ?? '') === 'F9' ? 'selected' : ''; ?>>F9 (Fail)</option>
                                </select>
                            </div>

                            <!-- Mathematics (Required) -->
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">Mathematics *</label>
                                <select name="waec_mathematics" class="form-input w-full px-3 py-2 rounded-lg" required>
                                    <option value="">Select Grade</option>
                                    <option value="A1" <?php echo ($oldInput['waec_mathematics'] ?? '') === 'A1' ? 'selected' : ''; ?>>A1 (Excellent)</option>
                                    <option value="B2" <?php echo ($oldInput['waec_mathematics'] ?? '') === 'B2' ? 'selected' : ''; ?>>B2 (Very Good)</option>
                                    <option value="B3" <?php echo ($oldInput['waec_mathematics'] ?? '') === 'B3' ? 'selected' : ''; ?>>B3 (Good)</option>
                                    <option value="C4" <?php echo ($oldInput['waec_mathematics'] ?? '') === 'C4' ? 'selected' : ''; ?>>C4 (Credit)</option>
                                    <option value="C5" <?php echo ($oldInput['waec_mathematics'] ?? '') === 'C5' ? 'selected' : ''; ?>>C5 (Credit)</option>
                                    <option value="C6" <?php echo ($oldInput['waec_mathematics'] ?? '') === 'C6' ? 'selected' : ''; ?>>C6 (Credit)</option>
                                    <option value="D7" <?php echo ($oldInput['waec_mathematics'] ?? '') === 'D7' ? 'selected' : ''; ?>>D7 (Pass)</option>
                                    <option value="E8" <?php echo ($oldInput['waec_mathematics'] ?? '') === 'E8' ? 'selected' : ''; ?>>E8 (Pass)</option>
                                    <option value="F9" <?php echo ($oldInput['waec_mathematics'] ?? '') === 'F9' ? 'selected' : ''; ?>>F9 (Fail)</option>
                                </select>
                            </div>

                            <!-- Subject 3 -->
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">Subject 3 *</label>
                                <div class="flex space-x-2">
                                    <input 
                                        type="text" 
                                        name="waec_subject3" 
                                        placeholder="Subject name"
                                        value="<?php echo htmlspecialchars($oldInput['waec_subject3'] ?? ''); ?>"
                                        class="form-input flex-1 px-3 py-2 rounded-lg" 
                                        required
                                    >
                                    <select name="waec_grade3" class="form-input w-20 px-2 py-2 rounded-lg" required>
                                        <option value="">Grade</option>
                                        <option value="A1" <?php echo ($oldInput['waec_grade3'] ?? '') === 'A1' ? 'selected' : ''; ?>>A1</option>
                                        <option value="B2" <?php echo ($oldInput['waec_grade3'] ?? '') === 'B2' ? 'selected' : ''; ?>>B2</option>
                                        <option value="B3" <?php echo ($oldInput['waec_grade3'] ?? '') === 'B3' ? 'selected' : ''; ?>>B3</option>
                                        <option value="C4" <?php echo ($oldInput['waec_grade3'] ?? '') === 'C4' ? 'selected' : ''; ?>>C4</option>
                                        <option value="C5" <?php echo ($oldInput['waec_grade3'] ?? '') === 'C5' ? 'selected' : ''; ?>>C5</option>
                                        <option value="C6" <?php echo ($oldInput['waec_grade3'] ?? '') === 'C6' ? 'selected' : ''; ?>>C6</option>
                                        <option value="D7" <?php echo ($oldInput['waec_grade3'] ?? '') === 'D7' ? 'selected' : ''; ?>>D7</option>
                                        <option value="E8" <?php echo ($oldInput['waec_grade3'] ?? '') === 'E8' ? 'selected' : ''; ?>>E8</option>
                                        <option value="F9" <?php echo ($oldInput['waec_grade3'] ?? '') === 'F9' ? 'selected' : ''; ?>>F9</option>
                                    </select>
                                </div>
                            </div>

                            <!-- Subject 4 -->
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">Subject 4 *</label>
                                <div class="flex space-x-2">
                                    <input 
                                        type="text" 
                                        name="waec_subject4" 
                                        placeholder="Subject name"
                                        value="<?php echo htmlspecialchars($oldInput['waec_subject4'] ?? ''); ?>"
                                        class="form-input flex-1 px-3 py-2 rounded-lg" 
                                        required
                                    >
                                    <select name="waec_grade4" class="form-input w-20 px-2 py-2 rounded-lg" required>
                                        <option value="">Grade</option>
                                        <option value="A1" <?php echo ($oldInput['waec_grade4'] ?? '') === 'A1' ? 'selected' : ''; ?>>A1</option>
                                        <option value="B2" <?php echo ($oldInput['waec_grade4'] ?? '') === 'B2' ? 'selected' : ''; ?>>B2</option>
                                        <option value="B3" <?php echo ($oldInput['waec_grade4'] ?? '') === 'B3' ? 'selected' : ''; ?>>B3</option>
                                        <option value="C4" <?php echo ($oldInput['waec_grade4'] ?? '') === 'C4' ? 'selected' : ''; ?>>C4</option>
                                        <option value="C5" <?php echo ($oldInput['waec_grade4'] ?? '') === 'C5' ? 'selected' : ''; ?>>C5</option>
                                        <option value="C6" <?php echo ($oldInput['waec_grade4'] ?? '') === 'C6' ? 'selected' : ''; ?>>C6</option>
                                        <option value="D7" <?php echo ($oldInput['waec_grade4'] ?? '') === 'D7' ? 'selected' : ''; ?>>D7</option>
                                        <option value="E8" <?php echo ($oldInput['waec_grade4'] ?? '') === 'E8' ? 'selected' : ''; ?>>E8</option>
                                        <option value="F9" <?php echo ($oldInput['waec_grade4'] ?? '') === 'F9' ? 'selected' : ''; ?>>F9</option>
                                    </select>
                                </div>
                            </div>

                            <!-- Subject 5 -->
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">Subject 5 *</label>
                                <div class="flex space-x-2">
                                    <input 
                                        type="text" 
                                        name="waec_subject5" 
                                        placeholder="Subject name"
                                        value="<?php echo htmlspecialchars($oldInput['waec_subject5'] ?? ''); ?>"
                                        class="form-input flex-1 px-3 py-2 rounded-lg" 
                                        required
                                    >
                                    <select name="waec_grade5" class="form-input w-20 px-2 py-2 rounded-lg" required>
                                        <option value="">Grade</option>
                                        <option value="A1" <?php echo ($oldInput['waec_grade5'] ?? '') === 'A1' ? 'selected' : ''; ?>>A1</option>
                                        <option value="B2" <?php echo ($oldInput['waec_grade5'] ?? '') === 'B2' ? 'selected' : ''; ?>>B2</option>
                                        <option value="B3" <?php echo ($oldInput['waec_grade5'] ?? '') === 'B3' ? 'selected' : ''; ?>>B3</option>
                                        <option value="C4" <?php echo ($oldInput['waec_grade5'] ?? '') === 'C4' ? 'selected' : ''; ?>>C4</option>
                                        <option value="C5" <?php echo ($oldInput['waec_grade5'] ?? '') === 'C5' ? 'selected' : ''; ?>>C5</option>
                                        <option value="C6" <?php echo ($oldInput['waec_grade5'] ?? '') === 'C6' ? 'selected' : ''; ?>>C6</option>
                                        <option value="D7" <?php echo ($oldInput['waec_grade5'] ?? '') === 'D7' ? 'selected' : ''; ?>>D7</option>
                                        <option value="E8" <?php echo ($oldInput['waec_grade5'] ?? '') === 'E8' ? 'selected' : ''; ?>>E8</option>
                                        <option value="F9" <?php echo ($oldInput['waec_grade5'] ?? '') === 'F9' ? 'selected' : ''; ?>>F9</option>
                                    </select>
                                </div>
                            </div>

                            <!-- Optional Subject 6 -->
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">Subject 6 (Optional)</label>
                                <div class="flex space-x-2">
                                    <input 
                                        type="text" 
                                        name="waec_subject6" 
                                        placeholder="Subject name"
                                        value="<?php echo htmlspecialchars($oldInput['waec_subject6'] ?? ''); ?>"
                                        class="form-input flex-1 px-3 py-2 rounded-lg"
                                    >
                                    <select name="waec_grade6" class="form-input w-20 px-2 py-2 rounded-lg">
                                        <option value="">Grade</option>
                                        <option value="A1" <?php echo ($oldInput['waec_grade6'] ?? '') === 'A1' ? 'selected' : ''; ?>>A1</option>
                                        <option value="B2" <?php echo ($oldInput['waec_grade6'] ?? '') === 'B2' ? 'selected' : ''; ?>>B2</option>
                                        <option value="B3" <?php echo ($oldInput['waec_grade6'] ?? '') === 'B3' ? 'selected' : ''; ?>>B3</option>
                                        <option value="C4" <?php echo ($oldInput['waec_grade6'] ?? '') === 'C4' ? 'selected' : ''; ?>>C4</option>
                                        <option value="C5" <?php echo ($oldInput['waec_grade6'] ?? '') === 'C5' ? 'selected' : ''; ?>>C5</option>
                                        <option value="C6" <?php echo ($oldInput['waec_grade6'] ?? '') === 'C6' ? 'selected' : ''; ?>>C6</option>
                                        <option value="D7" <?php echo ($oldInput['waec_grade6'] ?? '') === 'D7' ? 'selected' : ''; ?>>D7</option>
                                        <option value="E8" <?php echo ($oldInput['waec_grade6'] ?? '') === 'E8' ? 'selected' : ''; ?>>E8</option>
                                        <option value="F9" <?php echo ($oldInput['waec_grade6'] ?? '') === 'F9' ? 'selected' : ''; ?>>F9</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        
                        <div class="mt-3 text-xs text-gray-500">
                            <p>Note: A1-C6 are credit grades. You need at least 5 credits including English and Mathematics.</p>
                        </div>
                    </div>
                    <?php if (isset($errors['waec_results'])): ?>
                        <p class="mt-1 text-sm text-red-600"><?php echo $errors['waec_results'][0]; ?></p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Document Upload -->
        <div class="form-section p-8">
            <div class="section-header mb-6">
                <h2 class="text-2xl font-semibold text-gray-900">Required Documents</h2>
                <p class="text-gray-600 mt-1">Upload clear copies of the following documents (PDF, JPG, or PNG format, max 5MB each)</p>
            </div>
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <!-- O-Level Certificate -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">O-Level Certificate (WAEC/NECO) *</label>
                    <div class="upload-area" onclick="document.getElementById('olevel_certificate').click()">
                        <svg class="mx-auto h-12 w-12 text-gray-400" stroke="currentColor" fill="none" viewBox="0 0 48 48">
                            <path d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8m-12 4h.02" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                        </svg>
                        <p class="mt-2 text-sm text-gray-600">Click to upload O-Level Certificate</p>
                    </div>
                    <input type="file" id="olevel_certificate" name="olevel_certificate" class="hidden" accept=".pdf,.jpg,.jpeg,.png" required>
                    <div id="olevel_preview" class="mt-2"></div>
                </div>

                <!-- JAMB Result -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">JAMB Result Slip *</label>
                    <div class="upload-area" onclick="document.getElementById('jamb_result').click()">
                        <svg class="mx-auto h-12 w-12 text-gray-400" stroke="currentColor" fill="none" viewBox="0 0 48 48">
                            <path d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8m-12 4h.02" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                        </svg>
                        <p class="mt-2 text-sm text-gray-600">Click to upload JAMB Result</p>
                    </div>
                    <input type="file" id="jamb_result" name="jamb_result" class="hidden" accept=".pdf,.jpg,.jpeg,.png" required>
                    <div id="jamb_preview" class="mt-2"></div>
                </div>

                <!-- Birth Certificate -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Birth Certificate *</label>
                    <div class="upload-area" onclick="document.getElementById('birth_certificate').click()">
                        <svg class="mx-auto h-12 w-12 text-gray-400" stroke="currentColor" fill="none" viewBox="0 0 48 48">
                            <path d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8m-12 4h.02" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                        </svg>
                        <p class="mt-2 text-sm text-gray-600">Click to upload Birth Certificate</p>
                    </div>
                    <input type="file" id="birth_certificate" name="birth_certificate" class="hidden" accept=".pdf,.jpg,.jpeg,.png" required>
                    <div id="birth_preview" class="mt-2"></div>
                </div>

                <!-- Passport Photo -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Passport Photograph *</label>
                    <div class="upload-area" onclick="document.getElementById('passport_photo').click()">
                        <svg class="mx-auto h-12 w-12 text-gray-400" stroke="currentColor" fill="none" viewBox="0 0 48 48">
                            <path d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8m-12 4h.02" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                        </svg>
                        <p class="mt-2 text-sm text-gray-600">Click to upload Passport Photo</p>
                    </div>
                    <input type="file" id="passport_photo" name="passport_photo" class="hidden" accept=".jpg,.jpeg,.png" required>
                    <div id="passport_preview" class="mt-2"></div>
                </div>
            </div>
        </div>

        <!-- Submit Button -->
        <div class="text-center">
            <button 
                type="submit" 
                class="submit-btn inline-flex items-center px-8 py-4 text-lg font-medium text-white rounded-lg focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
                <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                </svg>
                Submit Application
            </button>
            <p class="mt-4 text-sm text-gray-600">
                By submitting this application, you agree to our terms and conditions.
            </p>
        </div>
    </form>
</div>

<?php
$content = ob_get_clean();
include __DIR__ . '/../layouts/app.php';
?>